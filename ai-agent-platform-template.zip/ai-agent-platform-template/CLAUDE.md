# CLAUDE.md

## Project Overview

AI agent platform template. FastAPI backend, Next.js frontend, PostgreSQL + Redis. Python 3.12+, strict MyPy + Pyright. **Vertical slice architecture** — features live under `backend/app/{feature}/`.

Copier template (`copier.yml`) generates new project instances. The `backend/` and `frontend/` directories contain the reference implementation.

## Essential Commands

```bash
make dev             # Backend (:8891) + frontend (:3000)
make dev-be          # Backend only (uvicorn with reload)
make dev-fe          # Frontend only (Next.js dev)
make check           # All checks (lint + types + tests)
make test            # Backend unit tests
make lint            # Format + lint (ruff)
make types           # mypy + pyright
make check-fe        # Frontend type-check + unit tests
make db-migrate      # Run pending migrations
make db-revision     # Create new auto-migration
make scaffold-feature # Scaffold a new feature vertical slice
make scaffold-agent  # Scaffold a new AI agent
```

## Development Guidelines

**Feature file order:** schemas -> models -> repository -> service -> exceptions -> routes -> tests

**Layers:** Routes (thin HTTP) -> Service (business logic) -> Repository (DB only). Exceptions inherit `AppError`.

**Key imports:**
- `get_logger` from `app.core.logging` — structured logging
- `get_db` from `app.core.database` — async DB session dependency
- `TimestampMixin` from `app.shared.models` — created_at / updated_at
- `escape_like` from `app.shared.utils` — safe SQL LIKE patterns

**Config:** Nested Pydantic settings, `env_nested_delimiter="__"` (e.g. `DATABASE__URL`, `AI__PROVIDER`).

**Roles:** admin, developer, viewer.

## Architecture

**Backend** (`backend/app/`):
- `core/` — config, database, logging, exceptions, security, middleware
- `shared/` — base models, mixins, utilities shared across features
- `ai/` — agent engine, prompts, blueprint state machine, skills
- `projects/` — project management, design systems
- `plugins/` — plugin manifest discovery, sandbox execution, lifecycle manager (when enabled)

**Frontend** (`frontend/src/`):
- `app/` — Next.js app router pages
- `components/` — UI components
- `hooks/` — React hooks (SWR data fetching, auth, state)
- `lib/` — utilities, API client, auth helpers
- `types/` — TypeScript type definitions

**AI Engine:** Agents follow a prompt -> LLM -> structured output -> post-process pipeline. Blueprint engine orchestrates agents as a state machine. Each agent has a prompt, schema, judge, and SKILL.md.

**Database:** Alembic migrations in `backend/alembic/`. CLI scaffolding via `backend/cli.py`.

## Testing Rules

- Use `@pytest.mark.integration` for tests requiring real database
- Use `AsyncMock` for database sessions in unit tests
- Use factory functions (`make_item`, `make_user`) for test data
- Save/restore `app.dependency_overrides` in fixtures
- Clear auth cache between tests
- Disable rate limiter in route tests

## Backend Rules

- All functions MUST have complete type annotations
- Use `from app.core.logging import get_logger` for structured logging
- Log events: `domain.action_state` pattern (e.g., `items.create_completed`)
- Use `AppError` hierarchy from `app.core.exceptions` — never raise bare `Exception`
- Use nested config: `settings.database.url`, `settings.auth.jwt_secret_key`
- Repository layer: database operations ONLY (no business logic)
- Service layer: business logic, validation, logging
- Routes: thin — delegate to service, handle HTTP concerns only

## Frontend Rules

- Use semantic Tailwind tokens — NEVER primitive colors (`text-gray-500`, `bg-blue-600`)
- Use `authFetch` for API calls, SWR hooks for data fetching
- React 19: no setState in useEffect, no component defs inside components
- Dialog for detail views (not Sheet). Widths: detail=28rem, forms=32rem

## Security Rules

- NEVER hardcode secrets, API keys, or passwords in source code
- NEVER commit `.env` files or credentials
- Use `escape_like()` for SQL LIKE/ILIKE patterns
- Use bcrypt for password hashing (never MD5/SHA)
- HTTPBearer with `auto_error=False` for auth dependencies
- Generic error messages for auth failures
- Rate limit all public endpoints
- Validate and sanitize all user input
