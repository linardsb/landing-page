# AI Agent Platform Template

A production-grade, domain-agnostic template for building AI agentic products. Extracted from a battle-tested platform with 9 AI agents, blueprint state machine orchestration, real-time collaboration, plugin system, and comprehensive eval framework.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (Next.js 16)                    │
│  ┌──────────┐ ┌──────────┐ ┌───────────┐ ┌──────────────────┐  │
│  │ Workspace │ │ Builder  │ │ Collab    │ │ Ecosystem Panel  │  │
│  │ Editor   │ │ (DnD)    │ │ (Yjs WS)  │ │ (Plugins/Flows)  │  │
│  └──────────┘ └──────────┘ └───────────┘ └──────────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ SWR Data Layer + authFetch + API Proxy (/api/v1/*)      │   │
│  └──────────────────────────────────────────────────────────┘   │
└───────────────────────────┬─────────────────────────────────────┘
                            │ REST + WebSocket
┌───────────────────────────┴─────────────────────────────────────┐
│                     BACKEND (FastAPI + async)                    │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Core: Config | DB | Auth | Logging | Middleware | RateLimit│ │
│  └────────────────────────────────────────────────────────────┘ │
│  ┌────────────┐ ┌──────────────┐ ┌──────────────────────────┐  │
│  │ AI Engine  │ │ Blueprint    │ │ Feature Slices           │  │
│  │ • Agents   │ │ State Machine│ │ • Projects               │  │
│  │ • Skills   │ │ • Nodes      │ │ • Knowledge (RAG)        │  │
│  │ • Evals    │ │ • Edges      │ │ • Connectors             │  │
│  │ • Routing  │ │ • QA Gate    │ │ • Plugins                │  │
│  │ • Fallback │ │ • Recovery   │ │ • Workflows              │  │
│  └────────────┘ └──────────────┘ │ • Rendering              │  │
│  ┌────────────┐ ┌──────────────┐ │ • Reporting              │  │
│  │ MCP Server │ │ Streaming    │ │ • Approval               │  │
│  │ (17 tools) │ │ WS + CRDT   │ └──────────────────────────┘  │
│  └────────────┘ └──────────────┘                                │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Data: PostgreSQL (async) + Redis (cache/pubsub/ratelimit) │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Stack

| Layer | Technology |
|-------|-----------|
| Backend | FastAPI, Python 3.12+, async SQLAlchemy, Pydantic v2 |
| Frontend | Next.js 16, React 19, Tailwind v4, SWR, TypeScript |
| Database | PostgreSQL (async) + Redis |
| AI | Multi-provider (OpenAI, Anthropic, Ollama, vLLM, LiteLLM) |
| Real-time | Yjs CRDT + WebSocket + Redis pub/sub |
| Orchestration | Blueprint state machine + optional Kestra workflows |
| Plugins | Manifest-based discovery, sandbox execution, lifecycle |
| MCP | FastMCP tool server (streamable HTTP + stdio) |
| Auth | JWT + refresh tokens + role-based access |
| Reports | Typst PDF generation + Redis caching |

## Quick Start

```bash
make dev             # Backend (:8891) + frontend (:3000)
make check           # All checks (lint + types + tests + security)
make test            # Backend unit tests
make lint            # Format + lint (ruff)
make types           # mypy + pyright
make check-fe        # Frontend type-check + unit tests
make db-migrate      # Run migrations
make eval-full       # Full eval pipeline (requires LLM)
make eval-golden     # CI golden test (deterministic, no LLM)
```

## Documentation

- [Backend Architecture](docs/01-backend-architecture.md)
- [AI Agent Framework](docs/02-ai-agent-framework.md)
- [Blueprint Engine](docs/03-blueprint-engine.md)
- [Frontend Architecture](docs/04-frontend-architecture.md)
- [Plugin System](docs/05-plugin-system.md)
- [Streaming & Collaboration](docs/06-streaming-collaboration.md)
- [Security Patterns](docs/07-security-patterns.md)
- [Subsystems Reference](docs/08-subsystems.md)
