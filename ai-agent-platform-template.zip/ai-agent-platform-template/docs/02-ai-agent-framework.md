# AI Agent Framework

## Overview

A protocol-driven, multi-agent framework with:
- **BaseAgentService** — unified pipeline (prompt → LLM → post-process → QA → response)
- **Provider Registry** — factory-based, multi-provider LLM access with circuit breakers
- **Model Routing** — tier-based resolution with adaptive adjustment + fallback chains
- **Skill System** — progressive disclosure, budget-aware skill loading
- **Eval Framework** — synthetic test cases, binary LLM judges, calibration, regression gates
- **Cost Governance** — per-model/agent/project token tracking with budget caps

---

## BaseAgentService (`app/ai/agents/base.py`)

All agents inherit from this base class. It provides the complete execution pipeline.

```python
class BaseAgentService:
    """Base class for all AI agents."""

    # --- Class-level config (override in subclass) ---
    agent_name: str = ""
    model_tier: Literal["complex", "standard", "lightweight"] = "standard"
    max_tokens: int = 8192
    run_qa_default: bool = False
    stream_prefix: str = ""
    output_mode_default: str = "raw"       # "raw" or "structured"
    _output_mode_supported: bool = False    # Enable structured output
    sanitization_profile: str = "default"   # XSS sanitization profile

    # --- MUST override ---
    def build_system_prompt(self, relevant_skills: list[str], output_mode: str) -> str:
        """Build the system prompt with injected skills."""
        raise NotImplementedError

    def _build_user_message(self, request: AgentRequest) -> str:
        """Construct the user message from the request."""
        raise NotImplementedError

    def detect_relevant_skills(self, request: AgentRequest) -> list[str]:
        """Determine which skill files to load for this request."""
        raise NotImplementedError

    def _build_response(self, content: str, qa_passed: bool, confidence: float, **kw) -> AgentResponse:
        """Construct agent-specific response schema."""
        raise NotImplementedError

    # --- Optional hooks ---
    def _post_process(self, raw_content: str) -> str:
        """Default: extract output + XSS sanitize via self.sanitization_profile."""

    async def _run_qa(self, output: str) -> bool:
        """Default: run all QA checks, return pass/fail."""

    def _get_model_tier(self, request: AgentRequest) -> str:
        """Dynamic tier per-request (override for adaptive routing)."""

    def _should_run_qa(self, request: AgentRequest) -> bool:
        """Conditional QA gate."""

    async def _process_structured(self, request: AgentRequest) -> AgentResponse:
        """Structured output pipeline (when _output_mode_supported=True)."""
```

### Execution Pipeline

```
1. Resolve model from tier → resolve_model(tier)
2. Detect relevant skills → list of skill names
3. Load skill files (budget-aware, priority-sorted)
4. Build system prompt + append CONFIDENCE_INSTRUCTION
5. Build user message (text + optional multimodal blocks)
6. Call LLM (with fallback chain if configured)
7. Post-process output (extract content, sanitize)
8. Extract confidence score (0.00–1.00)
9. Run QA checks if enabled
10. Build and return response
```

### Confidence Mechanism

Every agent appends `CONFIDENCE_INSTRUCTION` to its system prompt:

```
Rate your confidence in this output from 0.00 to 1.00.
Embed it as: <!-- CONFIDENCE: X.XX -->
```

The base class extracts this via regex, clamps to [0.0, 1.0], strips the comment from output.

---

## Provider Registry (`app/ai/registry.py`)

Factory pattern — stores provider **classes**, creates instances on demand.

```python
class ProviderRegistry:
    """Central registry for AI provider backends."""

    def register_llm(self, name: str, provider_class: type[LLMProvider]) -> None: ...
    def get_llm(self, name: str) -> LLMProvider: ...
    def register_embedding(self, name: str, cls: type[EmbeddingProvider]) -> None: ...
    def get_embedding(self, name: str) -> EmbeddingProvider: ...

# Built-in providers
registry.register_llm("openai", OpenAIProvider)
registry.register_llm("anthropic", AnthropicProvider)
registry.register_llm("ollama", OllamaProvider)
registry.register_llm("vllm", VLLMProvider)
registry.register_llm("litellm", LiteLLMProvider)
```

**Resilience wrapper:** Every LLM provider is wrapped with `_ResilientLLMProvider` — circuit breaker (5 failure threshold, 60s reset) on `complete()` calls.

---

## Protocols (`app/ai/protocols.py`)

```python
@dataclass
class Message:
    role: str                              # "user", "assistant", "system"
    content: str | list[ContentBlock]      # Text or multimodal
    cache_control: dict[str, str] | None   # Anthropic ephemeral cache

@dataclass
class CompletionResponse:
    content: str
    model: str
    usage: dict[str, int] | None
    parsed: dict[str, object] | None       # Structured output

class LLMProvider(Protocol):
    async def complete(self, messages: list[Message], **kwargs) -> CompletionResponse: ...
    async def stream(self, messages: list[Message], **kwargs) -> AsyncIterator[str]: ...

class EmbeddingProvider(Protocol):
    async def embed(self, texts: list[str]) -> list[list[float]]: ...

class RerankerProvider(Protocol):
    async def rerank(self, query: str, documents: list[str], top_k: int) -> list[RerankResult]: ...
```

---

## Multimodal Content Blocks (`app/ai/multimodal.py`)

```python
@dataclass
class TextBlock:
    text: str

@dataclass
class ImageBlock:
    data: bytes | None          # Base64 or raw
    media_type: str             # image/png, image/jpeg, etc.
    source: str                 # "base64" or "url"
    url: str | None
    width: int | None
    height: int | None
    # Validation: magic bytes, max 20MB, supported MIME types

@dataclass
class AudioBlock:
    data: bytes
    media_type: str             # audio/wav, audio/mp3, etc.
    duration_seconds: float
    # Validation: max 100MB, max 5 minutes

@dataclass
class StructuredOutputBlock:
    schema: dict                # JSON Schema
    name: str
    strict: bool = True
    # Validation: blocks $ref/$dynamicRef (except internal #-pointers)
```

**Token estimation:**
- Text: `chars / 4.0`
- Images: `(width * height) / 750`
- Audio: `duration_seconds * 25`

---

## Model Routing (`app/ai/routing.py`)

### Tier-Based Resolution

```python
TaskTier = Literal["complex", "standard", "lightweight"]

def resolve_model(tier: TaskTier) -> str:
    """Map tier to concrete model ID from config."""
    # complex  → settings.ai.complex_model
    # standard → settings.ai.standard_model
    # lightweight → settings.ai.lightweight_model

def resolve_model_by_capabilities(
    requirements: list[str],      # e.g., ["vision", "function_calling"]
    min_context: int = 0,
    tier: TaskTier = "standard",
) -> str:
    """Capability-aware model selection."""

def resolve_model_adaptive(
    tier: TaskTier,
    agent_name: str,
    project_id: int | None,
) -> str:
    """Adjust tier based on agent's historical performance."""
```

### Fallback Chains

Config-driven retry with model escalation:

```python
# Config: AI__FALLBACK_CHAINS='{"complex": ["openai:gpt-4o", "anthropic:claude-3.5-sonnet"]}'

@dataclass(frozen=True)
class FallbackChain:
    tier: TaskTier
    entries: tuple[FallbackEntry, ...]
    primary: FallbackEntry
    has_fallbacks: bool

async def call_with_fallback(
    chain: FallbackChain,
    registry: ProviderRegistry,
    messages: list[Message],
    max_tokens: int,
) -> CompletionResponse:
    """Try primary model, fall back on retryable errors."""
    # Retryable: 408, 429, 500, 502, 503, 504, timeout, rate limit, circuit open
```

---

## Skill System (`app/ai/agents/skills/`)

Progressive disclosure — skills loaded on-demand, budget-aware.

### Skill File Structure

```markdown
---
token_cost: 500
priority: 2
---

# Skill Name

## html
(Instructions for HTML output mode)

## structured
(Instructions for structured output mode)
```

### Loading Pipeline

```python
@dataclass(frozen=True)
class SkillMeta:
    token_cost: int = 500     # Estimated tokens
    priority: int = 2         # 1=critical (always load), 2=standard, 3=supplementary

def load_skills(skill_names: list[str], budget: int, output_mode: str) -> str:
    """
    1. Parse front matter for each skill
    2. Sort by priority (1 first)
    3. Priority 1: always load (critical)
    4. Priority 2-3: load while within budget
    5. Extract output-mode section
    6. Return concatenated skill text
    """
```

### Override Priority

1. **Prompt Store** (DB) — versioned templates, A/B variants
2. **In-Memory Override** — set programmatically
3. **Disk SKILL.md** — default fallback

### Prompt Store (`app/ai/prompt_store.py`)

```python
class PromptTemplate(Base):
    agent_id: str       # "scaffolder", "analyzer", etc.
    variant: str        # "default" or A/B variant name
    version: int        # Auto-incrementing
    content: str        # Full prompt text
    active: bool        # Flag for active version
    created_by: str
    created_at: datetime

# Methods: get_active(), list_versions(), create(), activate()
```

---

## Per-Agent Sanitization (`app/ai/shared.py`)

Each agent declares a sanitization profile. Output is cleaned via nh3 (Rust-backed) with agent-specific allowlists.

```python
PROFILES = {
    "default":       {"tags": FULL_TAG_SET, "attributes": STANDARD_ATTRS},
    "content":       {"tags": TEXT_ONLY_TAGS},           # p, span, a, ul, li, br
    "code_reviewer": {"tags": set()},                     # No HTML (returns JSON)
    "accessibility": {"tags": FULL_TAG_SET, "attributes": STANDARD_ATTRS | ARIA_ATTRS},
    "innovation":    {"tags": FULL_TAG_SET | FORM_TAGS},
    # ... more profiles
}

def sanitize_output_xss(content: str, profile: str = "default") -> str:
    """nh3-based allowlist sanitization with profile-specific rules."""
```

---

## Cost Governance (`app/ai/cost_governor.py`)

```python
class CostGovernor:
    """Redis-backed token + cost tracking with budget caps."""

    async def record_usage(self, model: str, agent: str, project_id: int,
                           input_tokens: int, output_tokens: int) -> None:
        """Record to monthly Redis bucket (YYYY-MM)."""

    async def get_monthly_cost(self, month: str | None = None) -> float:
        """Total cost in configured currency."""

    async def check_budget(self, project_id: int) -> BudgetStatus:
        """Returns ok/warning/exceeded."""
```

**Token budget** for skill loading:

```python
class TokenBudget:
    """Controls context budget for skill loading."""
    max_tokens: int
    used: int = 0

    def can_fit(self, cost: int) -> bool: ...
    def consume(self, cost: int) -> None: ...

    # ECONOMY_MODE_THRESHOLD triggers:
    # - compact_handoff_history()
    # - summarize_trajectory()
```

---

## Eval Framework (`app/ai/agents/evals/`)

### Architecture

```
synthetic_data_{agent}.py    # 10-16 test cases per agent
    ↓ runner.py
traces/{agent}_traces.jsonl  # Raw agent output traces
    ↓ judge_runner.py
traces/{agent}_verdicts.jsonl # Binary pass/fail verdicts
    ↓ calibration.py
TPR/TNR metrics              # Calibrated against human labels
    ↓ regression.py
Per-agent tolerance gate      # 3 percentage-point default
```

### Test Dimensions

Each agent defines failure-prone axes:

```python
# Example dimensions for any agent
DIMENSIONS = {
    "task_complexity": ["simple", "moderate", "complex", "edge_case"],
    "input_quality": ["detailed", "vague", "contradictory", "minimal"],
    "output_format": ["structured", "freeform", "mixed"],
}
```

### Judge Protocol

```python
class Judge(Protocol):
    agent_name: str
    criteria: list[JudgeCriteria]

    def build_prompt(self, judge_input: JudgeInput) -> str: ...
    def parse_response(self, raw: str) -> JudgeVerdict: ...

@dataclass
class JudgeVerdict:
    trace_id: str
    agent: str
    overall_pass: bool
    criteria_results: list[CriterionResult]
    error: str | None

@dataclass
class CriterionResult:
    name: str
    passed: bool
    reasoning: str
```

### Golden Tests (CI)

Deterministic, no LLM required — validates agent output structure and basic correctness:

```python
# golden_cases.py — 7+ deterministic test cases
def test_golden_case(case: GoldenCase):
    """Validates: output schema, required fields, size bounds, no regressions."""
```

### Production Sampler

Closes the eval feedback loop:

```python
class ProductionSampler:
    """
    1. Successful runs probabilistically enqueued to Redis
    2. ProductionJudgeWorker processes queue with LLM judges
    3. Verdicts appended to traces/production_verdicts.jsonl
    4. refresh_analysis() merges synthetic + production verdicts
    5. failure_warnings.py reads merged analysis
    """
    sample_rate: float = 0.0  # Default disabled (EVAL__PRODUCTION_SAMPLE_RATE)
```

### Regression Gate

```python
AGENT_REGRESSION_TOLERANCE = 0.03  # 3 percentage points

def check_regression(agent: str, current_pass_rate: float, baseline: float) -> bool:
    """Fails if current_pass_rate < baseline - tolerance."""
```

---

## Agent Registration

Agents are **standalone classes** — no central registry singleton. Each agent has:

```python
# app/ai/agents/{name}/service.py
class MyAgentService(BaseAgentService):
    agent_name = "my_agent"
    model_tier = "standard"
    sanitization_profile = "default"
    # ... override hooks

def get_my_agent_service() -> MyAgentService:
    return MyAgentService()
```

Blueprint nodes import and instantiate agents directly. Routes use FastAPI DI.

---

## Creating a New Agent (Checklist)

1. Create `app/ai/agents/{name}/` directory
2. `prompt.py` — `build_system_prompt()` + `detect_relevant_skills()`
3. `schemas.py` — Request/Response Pydantic models
4. `service.py` — Inherit `BaseAgentService`, override hooks
5. `skills/SKILL.md` — L1+L2 shared knowledge
6. `skills/*.md` — L3 specialized skill files with front matter
7. `evals/synthetic_data.py` — 10+ test cases across dimensions
8. `evals/judge.py` — 5-criteria binary judge
9. Register in blueprint graph (or expose via routes)
10. Add sanitization profile if custom allowlist needed
