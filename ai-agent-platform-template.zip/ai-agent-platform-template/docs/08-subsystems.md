# Subsystems Reference

## MCP Tool Server (`app/mcp/`)

Model Context Protocol server exposing platform capabilities as tools.

### Architecture

```python
# Factory + ASGI auth wrapper
def create_mcp_server() -> FastMCP:
    mcp = FastMCP(stateless_http=True, json_response=True)
    register_qa_tools(mcp)
    register_knowledge_tools(mcp)
    register_ai_tools(mcp)
    register_rendering_tools(mcp)
    # ... more tool groups
    filter_blocked_tools(mcp)  # Apply allowlist
    return mcp

# Auth middleware wraps the ASGI app
app = MCPAuthMiddleware(mcp.asgi_app())
```

### Tool Registration Pattern

```python
@mcp.tool()
async def qa_check(
    content: str,
    ctx: MCPContext,
    target_clients: list[str] | None = None,
    skip_checks: list[str] | None = None,
) -> str:
    """Run quality checks on content.

    Args:
        content: The content to validate (max 500KB)
        target_clients: Optional client targets for compatibility
        skip_checks: Check names to skip
    """
    if len(content) > 512_000:
        return "Error: Content exceeds 500KB limit"

    ctx.report_progress(0, 3)
    results = await run_qa_checks(content, target_clients, skip_checks)
    ctx.report_progress(3, 3)

    return format_results_as_markdown(results)
```

### Tool Organization

| Group | Tools | Purpose |
|-------|-------|---------|
| QA | qa_check, production_readiness, stress_test | Quality validation |
| Knowledge | search, retrieve, manage_documents | RAG pipeline |
| AI | run_blueprint, run_agent, list_agents | Agent orchestration |
| Rendering | screenshot, visual_diff, render_test | Visual validation |
| Content | create, update, list, get | Content CRUD |

### Config

```python
# Tool allowlist (operator-controlled)
def is_tool_allowed(tool_name: str) -> bool:
    allowlist = settings.mcp.allowed_tools  # Empty = all allowed
    return not allowlist or tool_name in allowlist
```

---

## Workflow Orchestration (`app/workflows/`)

Kestra-based workflow execution with Hub task wrappers.

### Architecture

```
WorkflowService
├── KestraClient (HTTP async)          # Flow CRUD, execution, logs
├── Task Wrappers (6 types)            # Hub-specific task implementations
└── Flow Templates (YAML)              # Bundled workflow definitions
```

### Kestra Client

```python
class KestraClient:
    async def create_flow(self, flow: dict) -> dict: ...
    async def trigger_execution(self, namespace: str, flow_id: str, inputs: dict) -> str: ...
    async def get_execution(self, execution_id: str) -> dict: ...
    async def get_logs(self, execution_id: str) -> list[LogEntry]: ...
    async def health_check(self) -> bool: ...
```

### Hub Task Protocol

```python
class HubTask(Protocol):
    task_type: str  # "hub.{name}"

    async def execute(self, inputs: dict) -> dict: ...
    def validate_inputs(self, inputs: dict) -> dict: ...

# Types: blueprint_run, approval_gate, qa_check, export_push,
#        stress_test, locale_build
```

### Safety

```python
# Task type allowlist prevents arbitrary code execution
ALLOWED_TASK_TYPES = {"hub.blueprint_run", "hub.qa_check", "hub.export_push", ...}
KESTRA_BUILTINS = {"Parallel", "Sequential", "Switch", "If", "ForEach", "Log"}

def validate_flow(flow: dict) -> bool:
    """Reject flows with unauthorized task types."""
```

---

## Knowledge & RAG (`app/knowledge/`)

Hybrid search pipeline with vector + fulltext + reciprocal rank fusion.

### Ingestion Pipeline

```
Document → Extract Text → Chunk (semantic, overlap-aware)
    → Embed (EmbeddingProvider) → Store (PostgreSQL + vector column)
    → Tag (organize by domain)
```

### Search Pipeline

```
Query → Embed Query
    ├── Vector Search (cosine similarity)
    ├── Fulltext Search (PostgreSQL tsvector)
    └── Reciprocal Rank Fusion (merge rankings)
        → Optional Reranker (RerankerProvider)
        → Top-K Results with scores + metadata
```

### Ontology Registry

Read-only reference knowledge base loaded from YAML:

```python
class OntologyRegistry:
    """Immutable indexed views of domain knowledge."""

    def get_entity(self, entity_id: str) -> Entity | None: ...
    def get_property(self, property_id: str) -> Property | None: ...
    def get_support(self, property_id: str, entity_id: str) -> SupportLevel: ...
    def entities_not_supporting(self, property_id: str) -> list[Entity]: ...
    def properties_unsupported_by(self, entity_id: str) -> list[Property]: ...
    def fallbacks_for(self, property_id: str) -> list[Fallback]: ...
```

---

## Rendering & Visual Validation (`app/rendering/`)

Multi-provider rendering with local emulators and visual regression.

### Provider Pattern

```python
class RenderingProvider(Protocol):
    async def submit_test(self, content: str, subject: str, clients: list[str]) -> str: ...
    async def get_test(self, test_id: str) -> RenderingTest: ...

# Providers: External APIs, Local emulators
```

### Client Emulators

Deterministic rule chains that simulate how different platforms transform content:

```python
class ClientEmulator:
    """Applies rule chain to transform content like a specific platform."""

    rules: list[TransformRule]

    def emulate(self, content: str) -> str:
        for rule in self.rules:
            content = rule.apply(content)
        return content

# Example rules:
# - Strip <style> tags
# - Rewrite class names with hash prefix
# - Remove unsupported CSS properties
# - Inject platform-specific attributes
# - Apply size constraints
```

### Visual Regression

```python
class VisualDiffService:
    async def compare(
        self,
        baseline_id: str,
        current_content: str,
        threshold: float = 0.01,
    ) -> DiffResult:
        """ODiff-based image comparison."""
        # Returns: match percentage, diff image, changed regions
```

---

## Connectors (`app/connectors/`)

Multi-provider external service sync with encrypted credentials.

### ESP Sync Provider Protocol

```python
class ExternalSyncProvider(Protocol):
    async def validate_connection(self) -> bool: ...
    async def list_items(self) -> list[ExternalItem]: ...
    async def import_item(self, item_id: str) -> str: ...
    async def export_item(self, build_id: str, name: str) -> str: ...
```

### Credential Management

```python
# Encrypted at rest (AES-256)
# BOLA: verify user has project access before exposing
# Display: last 4 chars only for safe hints
# Stored as generic Connection model with type discriminator

class Connection(Base):
    project_id: int
    provider_type: str      # Discriminator
    name: str
    encrypted_credentials: str
    created_by_id: int
```

### Translation Management (TMS) Integration

```python
class TMSService:
    async def extract_keys(self, content: str) -> list[str]:
        """Find {{key}} placeholders in content."""

    async def sync_keys(self, keys: list[str]) -> None:
        """Push extracted keys to TMS."""

    async def pull_translations(self) -> dict[str, dict[str, str]]:
        """Fetch all locales from TMS."""

    async def build_all_locales(self, content: str, translations: dict) -> dict[str, str]:
        """Generate per-locale content versions."""
```

---

## Reporting (`app/reporting/`)

PDF generation with Redis caching.

### Architecture

```python
class ReportingService:
    async def generate_report(self, request: ReportRequest) -> ReportResult:
        """
        1. Build structured data from request
        2. Render via Typst (or other PDF engine)
        3. SHA256 hash → report_id (deterministic, content-addressable)
        4. Cache base64 PDF in Redis with TTL
        5. Return report_id + metadata
        """

    async def get_report(self, report_id: str) -> ReportResult | None:
        """Retrieve cached report by ID."""

@dataclass
class ReportResult:
    report_id: str          # SHA256(content)[:16]
    filename: str
    pdf_base64: str
    generated_at: datetime
```

### Report Types

| Type | Input | Output |
|------|-------|--------|
| QA Report | Check results + scores | Failed checks, fix suggestions |
| Approval Package | Workflow snapshot | Build info, approvals, sign-offs |
| Regression Report | A/B comparison data | Metrics, trends, recommendations |

---

## Design System (`app/projects/design_system.py`)

Per-project brand identity as frozen Pydantic models:

```python
class DesignSystem(BaseModel, frozen=True):
    palette: BrandPalette
    typography: Typography
    logo: LogoConfig
    footer: FooterConfig
    social_links: list[SocialLink]
    colors: dict[str, str]       # Dynamic token map
    fonts: dict[str, str]
    font_sizes: dict[str, str]
    spacing: dict[str, str]

    def resolve_color_map(self) -> dict[str, str]:
        """Merge palette fields + explicit colors dict."""

# Stored as JSON column on Project model
# API: GET/PUT/DELETE /api/v1/projects/{id}/design-system
```

### Agent Pipeline Integration

Design system flows through the entire agent pipeline:

```
1. Service injects design system into blueprint context
2. Generator agent uses tokens for initial creation
3. Deterministic repair stage corrects off-palette values
4. QA checks validate brand compliance
5. Build stage applies final token replacements
```

---

## Subsystem Integration Map

```
┌─────────┐     ┌──────────┐     ┌──────────┐
│ Frontend │────→│ MCP Tools│────→│ QA Engine│
│ Builder  │     └──────────┘     └──────────┘
└────┬─────┘                           ↑
     │                                 │
     │ WebSocket                  ┌────┴─────┐
     ↓                            │ Plugins  │
┌──────────┐                      │ (QA ext) │
│ Streaming│                      └──────────┘
│ CRDT     │
└──────────┘     ┌──────────┐     ┌──────────┐
                 │ Workflows│────→│ Tasks    │
                 │ (Kestra) │     │ (Hub)    │
                 └──────────┘     └──────────┘
                                       ↓
┌──────────┐     ┌──────────┐     ┌──────────┐
│ Knowledge│←────│ Agents   │────→│ Blueprint│
│ (RAG)    │     │          │     │ Engine   │
└──────────┘     └──────────┘     └──────────┘
                                       ↓
┌──────────┐     ┌──────────┐     ┌──────────┐
│ Rendering│     │ Connectors│    │ Reporting│
│ (Visual) │     │ (ESP/TMS)│     │ (PDF)    │
└──────────┘     └──────────┘     └──────────┘
```

---

## Feature Toggle Pattern

All optional subsystems are guarded by config flags:

```python
# Config
plugins_enabled: bool = False
workflows_enabled: bool = False
reporting_enabled: bool = False
tms_enabled: bool = False
prompt_store_enabled: bool = False

# Router registration
if settings.plugins_enabled:
    app.include_router(plugins_router, prefix="/api/v1")

# Service initialization
if settings.workflows_enabled:
    await sync_workflow_templates()

# Agent behavior
if settings.prompt_store_enabled:
    prompt = await prompt_store.get_active(agent_id)
```
