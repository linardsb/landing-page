# Backend Architecture

## Vertical Slice Architecture

Every feature is a self-contained slice under `app/{feature}/`. No cross-feature imports at the repository layer.

```
app/{feature}/
├── schemas.py        # Pydantic request/response models
├── models.py         # SQLAlchemy ORM models
├── repository.py     # Data access ONLY (no business logic)
├── service.py        # Business logic, validation, logging
├── exceptions.py     # Feature-specific errors (inherit AppError)
├── routes.py         # Thin HTTP layer — delegates to service
├── dependencies.py   # Feature-specific DI factories (optional)
└── tests/            # Feature tests
```

**Data flow:** `Request → Route (thin) → Service (logic) → Repository (DB) → Model`

---

## Core Layer (`app/core/`)

### Configuration (`config.py`)

Nested Pydantic Settings with `env_nested_delimiter="__"`.

```python
class DatabaseConfig(BaseModel):
    url: str = "postgresql+asyncpg://..."
    pool_size: int = 3
    max_overflow: int = 5
    pool_recycle: int = 3600

class AuthConfig(BaseModel):
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

class AIConfig(BaseModel):
    provider: str = "openai"
    default_model: str = "gpt-4o"
    complex_model: str = "gpt-4o"
    standard_model: str = "gpt-4o-mini"
    lightweight_model: str = "gpt-4o-mini"
    fallback_chains: str = ""  # JSON: {"complex": ["openai:gpt-4o", "anthropic:claude-3.5-sonnet"]}
    prompt_store_enabled: bool = False
    max_tokens_default: int = 8192

class RedisConfig(BaseModel):
    url: str = "redis://localhost:6379/0"

class RateLimitConfig(BaseModel):
    default: str = "120/minute"
    auth: str = "10/minute"

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_nested_delimiter="__")

    database: DatabaseConfig = DatabaseConfig()
    auth: AuthConfig = AuthConfig()
    ai: AIConfig = AIConfig()
    redis: RedisConfig = RedisConfig()
    rate_limit: RateLimitConfig = RateLimitConfig()
    # Feature toggles
    plugins_enabled: bool = False
    workflows_enabled: bool = False
    # ... more groups

@lru_cache
def get_settings() -> Settings:
    return Settings()
```

**Pattern:** `DATABASE__URL`, `AUTH__JWT_SECRET_KEY`, `AI__PROVIDER` env vars.

---

### Database (`database.py`)

Async SQLAlchemy with two session providers:

```python
# 1. Request-scoped (FastAPI dependency)
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

# 2. Standalone context manager (background tasks, CLI, workers)
@asynccontextmanager
async def get_db_context() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
```

**Engine config:** `pool_pre_ping=True`, `expire_on_commit=False`, `autocommit=False`.

---

### Exception Hierarchy (`exceptions.py`)

```python
class AppError(Exception):
    """Base for all application errors. Maps to HTTP status."""
    status_code: int = 500
    error_type: str = "internal_error"

    def __init__(self, message: str, *, detail: str | None = None):
        self.message = message
        self.detail = detail
        super().__init__(message)

class NotFoundError(AppError):
    status_code = 404
    error_type = "not_found"

class DomainValidationError(AppError):
    status_code = 422
    error_type = "validation_error"

class ForbiddenError(AppError):
    status_code = 403
    error_type = "forbidden"

class ConflictError(AppError):
    status_code = 409
    error_type = "conflict"

class ServiceUnavailableError(AppError):
    status_code = 503
    error_type = "service_unavailable"
```

**Global handler** auto-maps exception → HTTP response:

```python
@app.exception_handler(AppError)
async def app_error_handler(request, exc: AppError):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": get_safe_error_message(exc),
            "type": exc.error_type,
        },
    )
```

**Error sanitization** prevents info leakage — only whitelisted error types pass messages through.

---

### Structured Logging (`logging.py`)

```python
# structlog with JSON output + context vars
logger = get_logger(__name__)

# Convention: domain.action_state
logger.info("projects.create_completed", project_id=42)
logger.warning("auth.login_failed", email=email)
logger.error("agents.execution_failed", agent="scaffolder", exc_info=True)
```

**Request correlation:** `X-Request-ID` header → context var → all downstream logs. Validated regex: `^[a-zA-Z0-9\-_.]{1,64}$` (prevents log injection).

---

### Middleware Stack (`middleware.py`)

Applied in order:

1. **BodySizeLimitMiddleware** — 102KB default, 50MB for upload paths. Returns 413/411.
2. **RequestLoggingMiddleware** — Correlation ID injection, timing, error logging.
3. **CORSMiddleware** — Configurable origins, credentials enabled.

---

### Rate Limiting (`rate_limit.py`)

Redis-backed via slowapi:

```python
# Key function extracts IP from X-Real-IP (proxy-safe, not client-spoofable)
def get_remote_address(request: Request) -> str:
    return request.headers.get("X-Real-IP", request.client.host)

limiter = Limiter(key_func=get_remote_address, storage_uri=settings.redis.url)

# Usage
@router.post("/login")
@limiter.limit("10/minute")
async def login(request: Request, ...): ...
```

In-memory fallback if Redis unavailable.

---

### Authentication & Authorization (`auth/`)

**JWT flow:**
1. Extract Bearer token
2. Decode JWT
3. Check revocation denylist in Redis
4. Check per-worker TTL cache (30s, max 200 users) or fetch from DB
5. Verify user is active
6. Return User object

**Role hierarchy:** `admin (3) > developer (2) > viewer (1)`

```python
# Dependency
current_user: User = Depends(get_current_user)

# Role gate
@router.delete("/projects/{id}")
async def delete_project(
    current_user: User = Depends(require_role("admin")),
): ...
```

**Brute-force protection:** 5 failed attempts → 15-minute lockout (Redis fast-path + DB persistence). Constant-time bcrypt even on invalid emails (prevents enumeration).

---

### Health Checks (`health.py`)

```
GET /health         — Liveness (rate limited 60/min)
GET /health/db      — Database connectivity (10s cache)
GET /health/redis   — Redis connectivity (10s cache)
GET /health/ready   — Readiness (DB + Redis)
```

---

## Shared Layer (`app/shared/`)

### Mixins

```python
class TimestampMixin:
    created_at: Mapped[datetime]  # Set once
    updated_at: Mapped[datetime]  # Auto-updated on commit

class SoftDeleteMixin:
    deleted_at: Mapped[datetime | None]  # NULL = active
```

### Schemas

```python
class PaginationParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)

class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
```

### Utilities

```python
def escape_like(value: str) -> str:
    """Escape %, _, \\ for SQL LIKE/ILIKE — prevents injection."""
```

---

## Dependency Injection Pattern

```python
# Service factory (request-scoped)
def get_project_service(db: AsyncSession = Depends(get_db)) -> ProjectService:
    return ProjectService(db)

# Route uses DI
@router.get("/projects")
async def list_projects(
    pagination: PaginationParams = Depends(),
    service: ProjectService = Depends(get_project_service),
    current_user: User = Depends(get_current_user),
):
    return await service.list_projects(pagination, current_user)
```

---

## Application Lifecycle (`main.py`)

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- STARTUP ---
    verify_security_config()           # JWT strength, DB creds
    configure_structured_logging()
    await init_database_pool()
    await init_redis()
    start_background_pollers()         # WebSocket, eval sampler, health monitors
    load_plugin_registry()             # If PLUGINS_ENABLED
    sync_workflow_templates()           # If WORKFLOWS_ENABLED
    warm_prompt_cache()                # If PROMPT_STORE_ENABLED
    load_model_capabilities()

    yield  # App serves requests

    # --- SHUTDOWN ---
    await stop_background_pollers()
    await shutdown_plugin_lifecycle()
    await close_redis()
    await dispose_database_pool()
```

**Router registration** with feature toggles:

```python
app.include_router(auth_router, prefix="/api/v1")
app.include_router(projects_router, prefix="/api/v1")
app.include_router(ai_router, prefix="/api/v1")

if settings.plugins_enabled:
    app.include_router(plugins_router, prefix="/api/v1")
if settings.workflows_enabled:
    app.include_router(workflows_router, prefix="/api/v1")
```

---

## Redis Integration

Singleton pattern with graceful fallback:

```python
async def get_redis() -> Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = Redis.from_url(settings.redis.url)
    return _redis_client

async def redis_available() -> bool:
    try:
        await (await get_redis()).ping()
        return True
    except Exception:
        return False
```

**Uses:** Rate limiting, token revocation, brute-force lockout, WebSocket pub/sub, cache, feature flags.

---

## Key Architectural Decisions

| Decision | Rationale |
|----------|-----------|
| Vertical slices | Feature-cohesive, easy to navigate and extend |
| Async SQLAlchemy | Non-blocking I/O, better resource utilization |
| JWT + Redis revocation | Immediate invalidation while keeping JWTs stateless |
| Per-worker TTL cache | Avoid DB query per request while catching deactivations |
| Exception inheritance | Automatic HTTP status mapping, consistent errors |
| Repository pattern | Pure data access, testable, isolates ORM details |
| Middleware over decorators | Applied globally, consistent request/response handling |
| Soft delete + timestamps | Audit trail, recovery, historical analysis |
| Structured JSON logging | Machine-parseable, correlation IDs, distributed tracing |
| Feature toggles | Gradual rollout, graceful degradation |
