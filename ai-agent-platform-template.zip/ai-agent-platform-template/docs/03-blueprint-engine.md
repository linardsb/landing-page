# Blueprint State Machine Engine

## Overview

The Blueprint Engine orchestrates multi-agent pipelines as directed graphs. Each node is either an agent (LLM-powered) or deterministic (rule-based). Edges define transitions based on node outcomes, with built-in QA gating and self-correction loops.

---

## Core Concepts

```
BlueprintDefinition
├── name: str
├── nodes: dict[str, BlueprintNode]
├── edges: list[Edge]
└── entry_node: str

Edge
├── from_node: str
├── to_node: str
├── condition: "success" | "qa_fail" | "always" | "route_to"
└── route_value: str | None    # For recovery router
```

---

## Node Protocol

```python
class BlueprintNode(Protocol):
    @property
    def name(self) -> str: ...

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]: ...

    async def execute(self, context: NodeContext) -> NodeResult: ...
```

### NodeContext (Progressive Hydration)

Each node receives a context that grows as the pipeline progresses:

```python
@dataclass
class NodeContext:
    output: str                              # Current artifact (HTML, JSON, etc.)
    brief: str                               # Original user request/brief
    node_rules: str                          # System prompt for this node
    qa_failures: list[str]                   # From previous QA iteration
    iteration: int                           # 0-based self-correction count
    metadata: dict[str, object]              # Arbitrary key-value pairs
    build_plan: BuildPlan | None             # Structured decisions (optional)
    multimodal_context: list[ContentBlock] | None  # Images/audio
```

### NodeResult

```python
@dataclass
class NodeResult:
    status: NodeStatus                       # "success" | "failed" | "skipped"
    output: str                              # Transformed artifact
    details: str                             # Human-readable summary
    error: str                               # Error message if failed
    usage: dict[str, int] | None             # Token usage
    handoff: AgentHandoff | None             # From agentic nodes
    structured_failures: tuple[StructuredFailure, ...]  # Typed QA failures
```

### AgentHandoff

Agentic nodes produce handoffs — structured summaries of agent work:

```python
@dataclass(frozen=True)
class AgentHandoff:
    status: HandoffStatus           # "ok" | "warning" | "blocked" | "failed"
    agent_name: str
    artifact: str                   # Output artifact
    decisions: tuple[str, ...]      # What the agent decided
    warnings: tuple[str, ...]       # Non-blocking issues
    component_refs: tuple[str, ...]
    confidence: float | None
    uncertainties: tuple[str, ...]
    typed_payload: object | None    # Structured decisions
```

---

## Engine Execution

### Constraints

```python
MAX_SELF_CORRECTION_ROUNDS = 2    # Max fixer attempts per QA failure
MAX_TOTAL_STEPS = 25              # Hard brake on runaway pipelines
CONFIDENCE_REVIEW_THRESHOLD = 0.5 # Below → status "needs_review"
```

### Execution Loop

```python
class BlueprintEngine:
    async def run(self, definition: BlueprintDefinition, brief: str) -> BlueprintRun:
        run = BlueprintRun(brief=brief)
        current_node = definition.entry_node

        while current_node and run.total_steps < MAX_TOTAL_STEPS:
            node = definition.nodes[current_node]
            context = self._build_context(run, node)

            # Execute node
            result = await node.execute(context)
            run.record_step(current_node, result)

            # Track handoffs
            if result.handoff:
                run.record_handoff(result.handoff)

            # Determine next node via edges
            current_node = self._resolve_next(definition, current_node, result)

        return run
```

### Edge Resolution

```python
def _resolve_next(self, definition, current_node, result) -> str | None:
    for edge in definition.edges:
        if edge.from_node != current_node:
            continue
        match edge.condition:
            case "success" if result.status == "success":
                return edge.to_node
            case "qa_fail" if result.status == "failed":
                return edge.to_node
            case "always":
                return edge.to_node
            case "route_to" if edge.route_value in result.details:
                return edge.to_node
    return None  # Pipeline complete
```

---

## Canonical Pipeline Pattern

```
┌────────────┐     ┌──────────┐     ┌──────────┐
│  Generator  │────→│  Repair   │────→│ QA Gate  │
│  (agentic)  │     │ (determ.) │     │ (determ.)│
└────────────┘     └──────────┘     └─────┬────┘
                                      success│  │qa_fail
                                          ↓     ↓
                                    ┌──────┐  ┌──────────────┐
                                    │ Build │  │Recovery Router│
                                    │ Node  │  │(route fixer)  │
                                    └──────┘  └──────┬───────┘
                                                      ↓
                                               ┌────────────┐
                                               │ Fixer Agent │
                                               │ (agentic)   │
                                               └──────┬─────┘
                                                      │ loops back
                                                      ↓ to Repair
```

### Node Types

| Node | Type | Purpose |
|------|------|---------|
| Generator | agentic | Primary creation (brief → artifact) |
| Repair | deterministic | Rule-based fixes (no LLM) |
| QA Gate | deterministic | Run quality checks, pass/fail decision |
| Recovery Router | deterministic | Analyze failures, select appropriate fixer |
| Fixer | agentic | Address specific QA failures (max 2 retries) |
| Build | deterministic | Compile/transform final artifact |
| Export | deterministic | Store/return result |
| Diagnostic | agentic | Analysis-only (no artifact mutation) |
| Advisory | agentic | Recommendations (not in QA loop) |

---

## BlueprintRun (Mutable State)

```python
@dataclass
class BlueprintRun:
    brief: str
    output: str = ""
    status: str = "running"            # running | completed | failed | needs_review
    total_steps: int = 0
    iteration_counts: dict[str, int]   # Per-node iteration tracking
    qa_failures: list[str] = []
    token_usage: dict[str, int] = {}   # Aggregated across all nodes
    handoff_history: list[AgentHandoff] = []
    step_log: list[StepRecord] = []

    def record_step(self, node_name: str, result: NodeResult) -> None: ...
    def record_handoff(self, handoff: AgentHandoff) -> None: ...
```

---

## Context Building

The engine progressively hydrates node context:

```python
def _build_context(self, run: BlueprintRun, node: BlueprintNode) -> NodeContext:
    context = NodeContext(
        output=run.output,
        brief=run.brief,
        node_rules=node.system_prompt,
        qa_failures=run.qa_failures,
        iteration=run.iteration_counts.get(node.name, 0),
        metadata={},
    )

    # Layer 1: Basic context
    context.metadata["total_steps"] = run.total_steps

    # Layer 2: Handoff history
    if run.handoff_history:
        context.metadata["upstream_handoff"] = run.handoff_history[-1]
        context.metadata["handoff_history"] = run.handoff_history

    # Layer 3: Domain-specific context (design system, constraints, etc.)
    self._inject_domain_context(context, run)

    # Layer 4: Build plan (structured decisions from generator)
    if run.build_plan:
        context.build_plan = run.build_plan

    return context
```

---

## Recovery Router

When QA fails, the recovery router selects the appropriate fixer:

```python
class RecoveryRouter:
    """Deterministic failure → fixer mapping."""

    ROUTING_TABLE = {
        "compatibility_check": "compatibility_fixer",
        "accessibility_check": "accessibility_fixer",
        "performance_check":   "performance_optimizer",
        "validation_check":    "validator_fixer",
        # Multiple failures → primary fixer
    }

    async def execute(self, context: NodeContext) -> NodeResult:
        failures = context.qa_failures
        fixer = self._select_fixer(failures)
        return NodeResult(
            status="success",
            details=f"route_to:{fixer}",
            output=context.output,
        )
```

---

## Inline Judges

When a fixer retries (`iteration > 0`), an inline judge can evaluate before QA:

```python
class InlineJudge:
    """Lightweight LLM judge on recovery retries."""

    def __init__(self, judge_registry: dict[str, Judge]):
        self.registry = judge_registry

    async def evaluate(self, agent_name: str, output: str, context: NodeContext) -> bool:
        """Returns True if output passes judge criteria."""
        # Uses lightweight model tier, temperature=0.0
        # Failure-safe: returns True on judge errors
        # Only runs when iteration > 0 (recovery retries)
```

---

## Checkpointing

For long-running pipelines, state can be checkpointed:

```python
class CheckpointManager:
    """Persist BlueprintRun state for resumption."""

    async def save(self, run_id: str, run: BlueprintRun) -> None:
        """Serialize to Redis with TTL."""

    async def load(self, run_id: str) -> BlueprintRun | None:
        """Resume from checkpoint."""

    async def cleanup_expired(self) -> int:
        """Background poller removes stale checkpoints."""
```

---

## Defining a Blueprint

```python
# Example: Generator → QA → Build pipeline
definition = BlueprintDefinition(
    name="content_pipeline",
    entry_node="generator",
    nodes={
        "generator": GeneratorNode(agent=MyGeneratorAgent()),
        "repair": RepairNode(rules=my_repair_rules),
        "qa_gate": QAGateNode(checks=my_checks),
        "recovery": RecoveryRouterNode(routing_table=my_routes),
        "fixer": FixerNode(agent=MyFixerAgent()),
        "build": BuildNode(builder=my_builder),
    },
    edges=[
        Edge("generator", "repair", "always"),
        Edge("repair", "qa_gate", "always"),
        Edge("qa_gate", "build", "success"),
        Edge("qa_gate", "recovery", "qa_fail"),
        Edge("recovery", "fixer", "route_to"),
        Edge("fixer", "repair", "always"),        # Loop back for re-check
    ],
)

# Execute
engine = BlueprintEngine()
run = await engine.run(definition, brief="Create a dashboard report")
```

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Bounded self-correction (2 rounds) | Prevents infinite loops, forces graceful degradation |
| Hard step limit (25) | Safety brake for complex graphs |
| Confidence threshold (0.5) | Low-confidence outputs flagged for human review |
| Handoff history | Downstream agents learn from upstream decisions |
| Progressive context | Nodes only receive what they need (not entire state) |
| Recovery router | Failure-specific fixing (not generic retry) |
| Inline judges | Early feedback before full QA re-run |
