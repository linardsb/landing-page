# Patterns Quick Reference

One-page cheat sheet of every reusable pattern in this template.

---

## Backend Patterns

### Vertical Slice (Feature Module)
```
app/{feature}/ → schemas → models → repository → service → exceptions → routes → tests
```
Route (thin HTTP) → Service (business logic) → Repository (DB only)

### Dependency Injection
```python
def get_service(db: AsyncSession = Depends(get_db)) -> MyService:
    return MyService(db)
```

### Exception Hierarchy
```
AppError (500) → NotFoundError (404) | DomainValidationError (422) | ForbiddenError (403) | ConflictError (409)
```
Global handler auto-maps to HTTP. Error sanitizer prevents info leakage.

### Configuration
```python
class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_nested_delimiter="__")
    database: DatabaseConfig = DatabaseConfig()
```
Env: `DATABASE__URL`, `AUTH__JWT_SECRET_KEY`, `AI__PROVIDER`

### Auth
JWT + Redis revocation + per-worker TTL cache + brute-force lockout + RBAC hierarchy

### Logging
`get_logger(__name__)` → structlog JSON + `X-Request-ID` correlation + log injection prevention

### Feature Toggles
```python
if settings.plugins_enabled:
    app.include_router(plugins_router)
```

---

## AI Agent Patterns

### BaseAgentService Pipeline
```
resolve_model → detect_skills → load_skills (budget-aware) → build_prompt
  → call_LLM (with fallback) → post_process → extract_confidence → run_QA → build_response
```

### Provider Registry
Factory pattern — stores classes, creates instances on demand, wraps with circuit breaker (5 failures → 60s reset)

### Model Routing
```
TaskTier ("complex" | "standard" | "lightweight") → resolve_model() → concrete model ID
Fallback chains: config-driven retry with model escalation on retryable errors
```

### Skill System
```markdown
---
token_cost: 500
priority: 2        # 1=critical (always load), 2=standard, 3=supplementary
---
```
Budget-aware loading: priority-sorted, within token budget, output-mode sections.
Override: Prompt Store (DB) > In-Memory > Disk

### Per-Agent Sanitization
Each agent declares a profile → nh3 allowlist → output cleaned before return

### Cost Governance
Redis monthly buckets, per-model pricing, project budgets with warning/exceeded thresholds

---

## Blueprint Engine Patterns

### State Machine
```
BlueprintDefinition(nodes, edges, entry_node) → BlueprintEngine.run() → BlueprintRun
```

### Edge Conditions
`"success"` | `"qa_fail"` | `"always"` | `"route_to"`

### Bounds
- MAX_SELF_CORRECTION_ROUNDS = 2
- MAX_TOTAL_STEPS = 25
- CONFIDENCE_REVIEW_THRESHOLD = 0.5

### Node Types
| Type | Purpose |
|------|---------|
| agentic | LLM-powered (generator, fixer, diagnostic) |
| deterministic | Rule-based (repair, QA gate, recovery router, build) |

### Handoff Chain
Upstream agent → AgentHandoff → downstream context.metadata["upstream_handoff"]

---

## Eval Patterns

### Pipeline
```
synthetic_data → runner → traces.jsonl → judge_runner → verdicts.jsonl
  → calibration (TPR/TNR) → regression gate (3pp tolerance)
```

### Judge Protocol
5 criteria per agent, binary pass/fail, LLM-evaluated

### Golden Tests
Deterministic CI — validates structure, not LLM quality. No LLM required.

### Production Sampler
Probabilistic enqueue → background worker → LLM judge → merge with synthetic → agents learn

---

## Plugin Patterns

### Lifecycle
Discovery → Manifest Validation → Registry → Sandbox Execution → Health Monitor → Auto-disable

### Manifest
Reverse domain name, semantic version, declared permissions, entry point

### Sandbox
asyncio.wait_for(timeout), handles sync+async, latency tracking, consecutive failure count

### API Surface
Plugins interact via HubPluginAPI only — no direct DB access

---

## Streaming & Collaboration

### WebSocket
Room-based routing, peer tracking, 12-color palette, capacity limits (20/room, 10 rooms/user)

### CRDT
Yjs document store, compaction (100 updates or 5min), 5MB size guard

### Redis Bridge
Pub/sub for multi-instance relay, hex-encoded binary, sender skip, exponential backoff

---

## Frontend Patterns

### Data Fetching
```typescript
useSWR("/api/v1/...", fetcher)                    // GET
useSWRMutation("/api/v1/...", mutationFetcher)     // POST
useSWRMutation("/api/v1/...", longMutationFetcher) // 120s timeout
```

### Auth
NextAuth JWT → authFetch (dual-mode: SSR + Client, 60s token cache) → API proxy to backend

### State Management
useState + useReducer + SWR (no Redux). Builder: useReducer + undo/redo (50 entries).

### Collaboration
Yjs Y.Doc → Y.Text("content") + Awareness (cursor, selection, activity, color)

### Security
DOMPurify on all user HTML, sandboxed iframes, CSS/attribute injection prevention, tokens in memory only

### Component System
SlotDefinition (type, selector, required, placeholder) → PropertyPanel tabs (Content, Style, Responsive, Advanced)

---

## Subsystem Patterns

| Subsystem | Pattern | Key Abstraction |
|-----------|---------|-----------------|
| Plugins | Registry + Sandbox | PluginInstance, HubPluginAPI |
| Workflows | Orchestrator + Task Wrappers | HubTask protocol, YAML templates |
| MCP | Tool Server + Auth Middleware | @mcp.tool(), domain tool groups |
| Streaming | Room-based WS + CRDT + Redis | CollabManager, YjsDocumentStore |
| Knowledge | RAG: embed → hybrid search → rerank | EmbeddingProvider, OntologyRegistry |
| Connectors | Sync Protocol + Encrypted Creds | ExternalSyncProvider protocol |
| Rendering | Multi-provider + Emulators | RenderingProvider, ClientEmulator |
| Reporting | Typst + Redis Cache | SHA256 content ID, TTL expiry |
