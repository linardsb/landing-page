# Security Patterns

## Overview

Defense-in-depth across backend, frontend, AI agents, and infrastructure. Covers authentication, authorization, input validation, output sanitization, rate limiting, and secure communication.

---

## Authentication

### JWT + Refresh Token Flow

```
Client              Backend              Redis
  │ POST /login        │                    │
  │ (email, password)  │                    │
  │───────────────────→│                    │
  │                    │ bcrypt verify      │
  │                    │ (constant-time)    │
  │  { access_token,   │                    │
  │    refresh_token }  │                    │
  │←───────────────────│                    │
  │                    │                    │
  │ GET /resource      │                    │
  │ Authorization:     │                    │
  │ Bearer {token}     │                    │
  │───────────────────→│                    │
  │                    │ Decode JWT         │
  │                    │ Check revocation──→│ SISMEMBER denylist
  │                    │←──────────────────│
  │                    │ Per-worker cache   │
  │                    │ (30s TTL, max 200) │
  │  Response          │                    │
  │←───────────────────│                    │
```

### Brute-Force Protection

```python
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION = 900  # 15 minutes

async def authenticate(email: str, password: str) -> User:
    # 1. Check Redis lockout (fast path)
    if await is_locked_out(email):
        raise AccountLockedError()

    # 2. Fetch user (or None)
    user = await repo.get_by_email(email)

    # 3. ALWAYS run bcrypt — even if user is None (prevents email enumeration)
    password_valid = bcrypt.checkpw(password, user.hashed_password if user else DUMMY_HASH)

    if not user or not password_valid:
        await increment_failures(email)  # Redis + DB
        raise InvalidCredentialsError("Invalid email or password")  # Generic message

    await clear_failures(email)
    return user
```

### Token Revocation

```python
# Immediate invalidation via Redis denylist
async def revoke_token(token_jti: str, expires_at: datetime) -> None:
    ttl = (expires_at - datetime.utcnow()).total_seconds()
    await redis.sadd("token_denylist", token_jti)
    await redis.expire("token_denylist", int(ttl))

# Checked on every request (not cached)
async def is_revoked(token_jti: str) -> bool:
    return await redis.sismember("token_denylist", token_jti)
```

---

## Authorization

### Role-Based Access Control (RBAC)

```python
# Role hierarchy: admin (3) > developer (2) > viewer (1)
ROLE_LEVELS = {"admin": 3, "developer": 2, "viewer": 1}

def require_role(minimum_role: str) -> Dependency:
    """FastAPI dependency — returns 403 if user role < minimum."""
    def checker(current_user: User = Depends(get_current_user)):
        if ROLE_LEVELS[current_user.role] < ROLE_LEVELS[minimum_role]:
            raise ForbiddenError("Insufficient permissions")
        return current_user
    return Depends(checker)

# Usage
@router.delete("/projects/{id}")
async def delete_project(user: User = Depends(require_role("admin"))): ...

@router.get("/projects")
async def list_projects(user: User = Depends(require_role("viewer"))): ...
```

### Broken Object-Level Authorization (BOLA) Prevention

```python
# Every service method verifies project access
async def get_project(self, project_id: int, user: User) -> Project:
    project = await self.repo.get(project_id)
    if not project:
        raise NotFoundError("Project not found")
    if not await self._has_access(user, project):
        raise ForbiddenError("Access denied")
    return project

# Credentials: verify user owns the project before exposing
async def get_connection(self, connection_id: int, user: User) -> Connection:
    conn = await self.repo.get(connection_id)
    await self._verify_project_access(conn.project_id, user)
    return conn
```

---

## Input Validation

### SQL Injection Prevention

```python
# NEVER use string formatting in queries
# Use SQLAlchemy parameterized queries exclusively

# For LIKE/ILIKE patterns:
from app.shared.utils import escape_like

query = select(Project).where(
    Project.name.ilike(f"%{escape_like(search_term)}%")
)
```

### Request Validation

```python
# Body size limits (middleware)
class BodySizeLimitMiddleware:
    DEFAULT_LIMIT = 102_400      # 100KB for most endpoints
    UPLOAD_LIMIT = 52_428_800    # 50MB for upload paths

# Pagination bounds
class PaginationParams(BaseModel):
    page: int = Field(ge=1)
    page_size: int = Field(ge=1, le=100)

# Log injection prevention
SAFE_REQUEST_ID = re.compile(r"^[a-zA-Z0-9\-_.]{1,64}$")
def validate_request_id(request_id: str) -> str | None:
    return request_id if SAFE_REQUEST_ID.match(request_id) else None
```

---

## Output Sanitization

### Per-Agent XSS Sanitization

```python
# Every AI agent output is sanitized with agent-specific allowlists
def sanitize_output_xss(content: str, profile: str = "default") -> str:
    """
    nh3-based (Rust) allowlist sanitization.
    Profile determines allowed tags + attributes.
    """

PROFILES = {
    "default":       FULL_TAGS + STANDARD_ATTRS,
    "content":       TEXT_ONLY_TAGS,           # p, span, a, br
    "code_reviewer": NO_TAGS,                  # Returns JSON only
    "accessibility": FULL_TAGS + ARIA_ATTRS,   # Enhanced ARIA support
}

# Wired into BaseAgentService._post_process()
class BaseAgentService:
    sanitization_profile: str = "default"

    def _post_process(self, raw: str) -> str:
        extracted = extract_content(raw)
        return sanitize_output_xss(extracted, self.sanitization_profile)
```

### Error Message Sanitization

```python
# Prevent information leakage in error responses
def get_safe_error_message(exc: AppError) -> str:
    """Only whitelisted error types pass messages through."""
    PASSTHROUGH = {NotFoundError, DomainValidationError, ForbiddenError, ConflictError}
    if type(exc) in PASSTHROUGH:
        return exc.message
    return "An internal error occurred"  # Generic fallback
```

---

## Frontend Security

### XSS Prevention

```typescript
// All user HTML through DOMPurify
import DOMPurify from "dompurify";
const clean = DOMPurify.sanitize(userHtml);

// Builder preview: sandboxed iframe
<iframe sandbox="" srcDoc={sanitizedHtml} />

// No dangerouslySetInnerHTML without DOMPurify
```

### CSS Injection Prevention

```typescript
// Strip dangerous CSS
function sanitizeCssValue(value: string): string {
  // Remove: expression(), behavior:, javascript:, vbscript:, data:text/html
  return value.replace(/expression\s*\(|behavior\s*:|javascript:|vbscript:|data:text\/html/gi, "");
}

// CSS properties: alphanumeric + hyphen only
function sanitizeCssProperty(prop: string): string {
  return /^[a-zA-Z-]+$/.test(prop) ? prop : "";
}

// Selectors: sanitized for section IDs
function sanitizeSelector(sel: string): string {
  return /^[a-zA-Z0-9_\-\s]+$/.test(sel) ? sel : "";
}

// Strip @import/@font-face before scoping
function stripDangerousAtRules(css: string): string { ... }
```

### Attribute Injection Prevention

```typescript
function sanitizeHtmlAttributes(attrs: Record<string, string>): Record<string, string> {
  const BLOCKED_KEYS = /^on/i;           // Event handlers
  const BLOCKED_VALUES = /javascript:|vbscript:|data:text\/html/i;

  return Object.fromEntries(
    Object.entries(attrs).filter(([key, value]) =>
      key !== "style" &&                   // Style handled via tokens
      !BLOCKED_KEYS.test(key) &&
      !BLOCKED_VALUES.test(value)
    )
  );
}
```

### Token Management

```typescript
// JWT in memory only (not localStorage)
let cachedToken: string | null = null;
let cacheExpiry = 0;

function getToken(): string | null {
  if (Date.now() < cacheExpiry) return cachedToken;
  return null;  // Refresh from session
}

function clearTokenCache(): void {
  cachedToken = null;
  cacheExpiry = 0;
}
```

---

## Rate Limiting

```python
# Redis-backed, per-IP
limiter = Limiter(key_func=get_remote_address, storage_uri=redis_url)

# Endpoint-specific limits
@router.post("/auth/login")
@limiter.limit("10/minute")
async def login(): ...

@router.post("/ai/chat")
@limiter.limit("10/minute")
async def chat(): ...

# Default: 120/minute for all other endpoints

# Key extraction: X-Real-IP header (proxy-safe)
def get_remote_address(request: Request) -> str:
    return request.headers.get("X-Real-IP", request.client.host)
```

---

## Credential Storage

```python
# Encrypt sensitive credentials at rest
from cryptography.fernet import Fernet

def encrypt_token(plaintext: str) -> str:
    """AES-256 encryption for stored credentials."""
    f = Fernet(settings.encryption_key)
    return f.encrypt(plaintext.encode()).decode()

def decrypt_token(ciphertext: str) -> str:
    f = Fernet(settings.encryption_key)
    return f.decrypt(ciphertext.encode()).decode()

# Display: last 4 chars only
def credential_hint(token: str) -> str:
    return f"***{token[-4:]}"
```

---

## WebSocket Security

```python
# JWT validation on WebSocket upgrade
@router.websocket("/ws/collab/{room_id}")
async def collab_ws(ws: WebSocket, room_id: str, token: str = Query(...)):
    user = await verify_ws_token(token)  # Validate JWT
    if not user:
        await ws.close(code=4001)
        return

# Room capacity limits prevent resource exhaustion
MAX_PEERS_PER_ROOM = 20
MAX_ROOMS_PER_USER = 10
```

---

## MCP Server Auth

```python
class MCPAuthMiddleware:
    """Bearer token validation on MCP HTTP requests."""

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            auth_header = get_header(scope, "authorization")
            if not auth_header or not auth_header.startswith("Bearer "):
                return await send_401(send)
            token = auth_header[7:]
            if not await verify_mcp_token(token):
                return await send_401(send)
        await self.app(scope, receive, send)
```

---

## Security Checklist

| Area | Control | Implementation |
|------|---------|---------------|
| Auth | Password hashing | bcrypt (never MD5/SHA) |
| Auth | Token revocation | Redis denylist, checked every request |
| Auth | Brute-force | 5 attempts → 15min lockout |
| Auth | Enumeration | Constant-time bcrypt on invalid emails |
| AuthZ | RBAC | Role hierarchy with `require_role()` |
| AuthZ | BOLA | Service-layer project access verification |
| Input | SQL injection | Parameterized queries + `escape_like()` |
| Input | Body size | Middleware limits (100KB/50MB) |
| Input | Log injection | Request ID regex validation |
| Output | XSS | nh3 per-agent profiles (backend) + DOMPurify (frontend) |
| Output | Error leakage | Safe error message sanitization |
| Frontend | CSS injection | Value/property/selector sanitization |
| Frontend | Attribute injection | Block `on*`, `style`, dangerous URIs |
| Frontend | Token storage | Memory only (not localStorage) |
| Network | Rate limiting | Redis-backed, per-IP, per-endpoint |
| Network | CORS | Whitelist origins, credentials enabled |
| Storage | Credentials | AES-256 encryption at rest |
| WebSocket | Auth | JWT via query param, validated on upgrade |
| WebSocket | DoS | Room capacity + per-user room limits |
