# Streaming & Real-Time Collaboration

## Overview

Room-based WebSocket collaboration using Yjs CRDT for conflict-free content sync, Redis pub/sub for multi-instance relay, and a document store with compaction for persistence.

---

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    CLIENT A                                │
│  Y.Doc → Y.Text("content") + Awareness                   │
│     ↕ WebSocket (Yjs sync protocol)                       │
└──────────────────┬───────────────────────────────────────┘
                   │
┌──────────────────┴───────────────────────────────────────┐
│              BACKEND INSTANCE 1                           │
│  ┌────────────────────┐  ┌─────────────────────────────┐ │
│  │ CollabManager       │  │ YjsDocumentStore            │ │
│  │ • Room tracking     │  │ • In-memory doc cache       │ │
│  │ • Peer management   │  │ • PostgreSQL persistence    │ │
│  │ • Broadcast bytes   │  │ • Compaction (100 updates)  │ │
│  └────────┬───────────┘  └─────────────────────────────┘ │
│           │                                               │
│  ┌────────┴───────────┐                                   │
│  │ Redis Pub/Sub      │←──── Channel: ws:collab:room:{id} │
│  │ Bridge             │                                   │
│  └────────┬───────────┘                                   │
└───────────┼──────────────────────────────────────────────┘
            │ Redis pub/sub
┌───────────┼──────────────────────────────────────────────┐
│           │  BACKEND INSTANCE 2                           │
│  ┌────────┴───────────┐                                   │
│  │ Redis Pub/Sub      │                                   │
│  │ Bridge             │                                   │
│  └────────┬───────────┘                                   │
│  ┌────────┴───────────┐                                   │
│  │ CollabManager       │──→ Relay to local peers          │
│  └────────────────────┘                                   │
└──────────────────────────────────────────────────────────┘
```

---

## WebSocket Manager (`app/streaming/websocket/manager.py`)

```python
class CollabConnectionManager:
    """Room-based peer tracking with capacity limits."""

    # Limits
    MAX_PEERS_PER_ROOM = 20
    MAX_ROOMS_PER_USER = 10

    # Peer tracking
    rooms: dict[str, dict[str, Peer]]  # room_id → {ws_id → Peer}

    async def connect(self, websocket: WebSocket, room_id: str, user_info: ConnectionInfo) -> str:
        """
        1. Check room capacity
        2. Check user room limit
        3. Assign color from 12-color palette (indexed by position)
        4. Add to room dict (async lock protected)
        5. Return ws_id
        """

    async def disconnect(self, room_id: str, ws_id: str) -> None:
        """Remove peer, clean up empty rooms."""

    async def broadcast_bytes(self, room_id: str, data: bytes, exclude_ws_id: str) -> None:
        """Send binary data (Yjs updates) to all peers except sender."""

    async def broadcast_json(self, room_id: str, data: dict, exclude_ws_id: str) -> None:
        """Send JSON (awareness/presence) to all peers except sender."""

    async def send_to_user(self, room_id: str, user_id: str, data: dict) -> None:
        """Unicast to specific user in room."""

@dataclass
class Peer:
    websocket: WebSocket
    info: ConnectionInfo

@dataclass
class ConnectionInfo:
    user_id: str
    room_id: str
    display_name: str
    role: str          # admin, developer, viewer
    color: str         # From 12-color palette
```

---

## CRDT Document Store (`app/streaming/crdt/document_store.py`)

```python
class YjsDocumentStore:
    """Yjs persistence with in-memory cache and background compaction."""

    # Compaction thresholds
    COMPACT_UPDATE_COUNT = 100    # Compact after 100 pending updates
    COMPACT_TIME_INTERVAL = 300   # Or after 5 minutes
    MAX_DOCUMENT_SIZE = 5_242_880  # 5MB size guard

    async def get_or_create(self, room_id: str) -> DocumentState:
        """
        1. Check in-memory cache
        2. If miss → load from PostgreSQL (state + pending_updates)
        3. If not in DB → create new empty document
        4. Cache in memory
        """

    async def apply_update(self, room_id: str, update: bytes) -> None:
        """
        1. Validate size guard (reject if total > 5MB)
        2. Append to pending_updates
        3. Persist to PostgreSQL
        4. Check compaction threshold → compact if needed
        """

    async def compact(self, room_id: str) -> None:
        """
        1. Merge all pending_updates into base state
        2. Reset pending counter
        3. Persist compacted state
        """

    def get_state_vector(self, room_id: str) -> bytes:
        """Yjs sync protocol: client sends this to get delta."""

    def get_update_for_peer(self, room_id: str, state_vector: bytes) -> bytes:
        """Compute minimal delta for peer based on their state vector."""

    async def evict(self, room_id: str) -> None:
        """Remove from in-memory cache (document persisted in DB)."""
```

---

## Redis Pub/Sub Bridge (`app/streaming/websocket/redis_bridge.py`)

Enables multi-instance WebSocket relay:

```python
class RedisPubSubBridge:
    """Publishes/subscribes to Redis channels for cross-instance relay."""

    CHANNEL_PREFIX = "ws:collab:room:"

    async def publish(self, room_id: str, data: bytes, sender_user_id: str) -> None:
        """
        1. Hex-encode binary data (Yjs updates)
        2. Publish to channel: ws:collab:room:{room_id}
        3. Include sender_user_id in envelope (to skip echo)
        """

    async def publish_json(self, room_id: str, data: dict, sender_user_id: str) -> None:
        """Publish JSON data (awareness/presence) with sender envelope."""

    async def start(self) -> None:
        """
        1. Pattern subscribe to ws:collab:room:*
        2. Start _subscribe_loop() as background task
        """

    async def _subscribe_loop(self) -> None:
        """
        For each message:
        1. Extract room_id from channel name
        2. Extract sender_user_id from envelope
        3. Decode data (hex → bytes or JSON)
        4. Relay to local peers via CollabManager (skip sender)
        5. Exponential backoff on connection errors (1s → 30s max)
        """
```

---

## WebSocket Route

```python
@router.websocket("/ws/collab/{room_id}")
async def collab_websocket(
    websocket: WebSocket,
    room_id: str,
    token: str = Query(...),  # JWT via query param
):
    # 1. Validate JWT
    user = await verify_ws_token(token)

    # 2. Connect to room
    ws_id = await manager.connect(websocket, room_id, ConnectionInfo(
        user_id=user.id, room_id=room_id,
        display_name=user.name, role=user.role,
    ))

    try:
        # 3. Send initial state (Yjs sync)
        state = await doc_store.get_or_create(room_id)
        await websocket.send_bytes(encode_sync_step1(state))

        # 4. Message loop
        while True:
            data = await websocket.receive()
            if "bytes" in data:
                # Yjs update
                await doc_store.apply_update(room_id, data["bytes"])
                await manager.broadcast_bytes(room_id, data["bytes"], exclude=ws_id)
                await redis_bridge.publish(room_id, data["bytes"], user.id)
            elif "text" in data:
                # Awareness/presence JSON
                msg = json.loads(data["text"])
                await manager.broadcast_json(room_id, msg, exclude=ws_id)
                await redis_bridge.publish_json(room_id, msg, user.id)
    finally:
        await manager.disconnect(room_id, ws_id)
```

---

## Frontend Collaboration Hooks

### useCollaboration

```typescript
function useCollaboration(roomId: string, token: string) {
  // Creates Y.Doc + WebsocketProvider on mount
  // Provider URL: ws://{HOST}/ws/collab/{roomId}?token={jwt}
  // Auto-reconnect with exponential backoff (max 30s)
  // Returns: { doc, status, awareness }
}
```

### usePresence

```typescript
function usePresence(awareness: Awareness | null) {
  // Awareness state per peer:
  //   { name, color, role, activity, cursor, selection, lastActiveAt }
  // Activity states: editing, idle, viewing
  // Idle timeout: 60s
  // 12-color palette indexed by clientId
  // Follow mode: track another user's cursor
  // Returns: { collaborators, followTarget, startFollowing, stopFollowing }
}
```

### Awareness Helpers

```typescript
function setLocalUser(awareness: Awareness, user: { name, color, role }): void;
function setLocalActivity(awareness: Awareness, activity: ActivityState): void;
function setLocalCursorState(awareness: Awareness, cursor: CursorPos, selection: SelectionRange): void;
function getEnrichedCollaborators(awareness: Awareness): Collaborator[];
```

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Yjs CRDT | Conflict-free merging without operational transform complexity |
| Redis pub/sub | Multi-instance relay without sticky sessions |
| Room-based routing | Scoped broadcast, capacity limits per room |
| Compaction (100 updates) | Prevents unbounded growth of update log |
| 5MB size guard | Protects against runaway document growth |
| JWT via query param | WebSocket upgrade can't use Authorization header in browsers |
| 12-color palette | Deterministic, visually distinct cursor colors |
| Exponential backoff | Graceful reconnection without thundering herd |
