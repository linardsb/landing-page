# Plugin System

## Overview

Manifest-based plugin discovery with sandboxed execution, lifecycle management, and auto-disable on failure. Plugins extend the platform without direct DB access — they interact through provided APIs only.

---

## Architecture

```
Plugin Discovery → Manifest Validation → Registry → Sandbox Execution
                                           ↓
                                    Lifecycle Manager
                                    (health monitor, auto-disable)
```

---

## Manifest (`app/plugins/manifest.py`)

Every plugin declares capabilities and permissions:

```python
class PluginManifest(BaseModel):
    name: str            # Reverse domain: "com.example.my-plugin"
    version: str         # Semantic version: "1.0.0"
    plugin_type: PluginType
    description: str
    author: str
    permissions: list[PluginPermission]
    entry_point: str     # Module path: "plugins.my_plugin.main"
    config_schema: dict | None  # JSON Schema for plugin config

class PluginType(str, Enum):
    qa_check = "qa_check"
    agent_skill = "agent_skill"
    export_connector = "export_connector"
    component_package = "component_package"
    theme = "theme"
    workflow_step = "workflow_step"

class PluginPermission(str, Enum):
    read_content = "read_content"
    write_content = "write_content"
    read_qa_results = "read_qa_results"
    write_qa_results = "write_qa_results"
    call_llm = "call_llm"
    network_access = "network_access"
    file_read = "file_read"
```

**Validation:** Name must be reverse domain (lowercase, 3-64 chars). Version must be semantic.

---

## Registry (`app/plugins/registry.py`)

Central singleton managing all plugin instances:

```python
class PluginRegistry:
    """Singleton registry for all plugins."""

    def discover(self, plugin_dir: str) -> list[PluginManifest]: ...
    def load_and_register(self, manifest: PluginManifest) -> PluginInstance: ...
    def get(self, name: str) -> PluginInstance | None: ...
    def list_active(self) -> list[PluginInstance]: ...
    def disable(self, name: str) -> None: ...
    def enable(self, name: str) -> None: ...

class PluginInstance:
    manifest: PluginManifest
    module: ModuleType
    api: HubPluginAPI
    status: PluginStatus     # active | disabled | error | inactive | degraded
    consecutive_failures: int

class PluginStatus(str, Enum):
    active = "active"
    disabled = "disabled"
    error = "error"
    inactive = "inactive"
    degraded = "degraded"
```

**Dynamic wiring:** `_wire_plugin()` connects plugins to subsystems. QA check plugins auto-register their check functions. Conflict detection prevents duplicate check names.

---

## Sandbox (`app/plugins/sandbox.py`)

Timeout and error isolation:

```python
class PluginSandbox:
    async def execute(
        self,
        plugin: PluginInstance,
        func_name: str,
        *args,
        timeout: float = 30.0,
        **kwargs,
    ) -> Any:
        """
        1. Resolve function on plugin module
        2. Wrap with asyncio.wait_for(timeout)
        3. Handle both sync and async callables
        4. Track latency
        5. Increment failure count on error
        """

    async def check_health(self, plugin: PluginInstance) -> PluginHealth:
        """Run plugin's health_fn with 5s timeout."""

@dataclass
class PluginHealth:
    status: Literal["healthy", "degraded", "unhealthy"]
    message: str
    latency_ms: float
```

---

## Lifecycle Manager (`app/plugins/lifecycle.py`)

```python
class PluginLifecycleManager:
    async def startup(self) -> None:
        """Call setup() on all registered plugins."""

    async def shutdown(self) -> None:
        """Call teardown() on all plugins (10s timeout each)."""

    async def restart(self, name: str) -> None:
        """Graceful hot reload: teardown → reload module → setup."""

    async def check_all_health(self) -> dict[str, PluginHealth]:
        """Periodic health check for all active plugins."""

    def _auto_disable(self, plugin: PluginInstance) -> None:
        """Disable after N consecutive failures (default 3)."""
```

**Status transitions:** `healthy → degraded → unhealthy → auto-disabled`

---

## Plugin API (`app/plugins/api.py`)

Plugins interact with the platform through sandboxed APIs:

```python
class HubPluginAPI:
    """API surface exposed to plugins."""

    qa: PluginQAAPI         # Register QA checks
    config: PluginConfigAPI  # Read plugin config

class PluginQAAPI:
    def register_check(
        self,
        name: str,
        check_fn: Callable[[str, QACheckConfig | None], Awaitable[QACheckResult]],
    ) -> None:
        """Register an async QA check function."""

class PluginConfigAPI:
    def get(self, key: str, default: Any = None) -> Any:
        """Read plugin configuration value."""
```

**Permission enforcement:** Every API call validates against the plugin's declared permissions.

---

## Writing a Plugin

### Module Structure

```python
# plugins/my_qa_check/main.py

async def setup(api: HubPluginAPI) -> None:
    """Called on plugin load. Register capabilities."""
    api.qa.register_check("my_custom_check", my_check_fn)

async def teardown() -> None:
    """Called on shutdown. Clean up resources."""
    pass

async def health() -> bool:
    """Optional health check. Return True if healthy."""
    return True

async def my_check_fn(content: str, config: QACheckConfig | None) -> QACheckResult:
    """The actual QA check implementation."""
    issues = analyze(content)
    return QACheckResult(
        passed=len(issues) == 0,
        issues=issues,
        score=1.0 - (len(issues) * 0.1),
    )
```

### Manifest

```json
{
  "name": "com.example.my-qa-check",
  "version": "1.0.0",
  "plugin_type": "qa_check",
  "description": "Custom quality check for content",
  "author": "Example Corp",
  "permissions": ["read_content", "write_qa_results"],
  "entry_point": "plugins.my_qa_check.main"
}
```

---

## Frontend Integration

### Ecosystem Dashboard

```typescript
// hooks/use-plugins.ts
function usePlugins() {
  const { data } = useSWR("/api/v1/plugins", fetcher);
  const { trigger: togglePlugin } = useSWRMutation("/api/v1/plugins/toggle", mutationFetcher);
  const { trigger: restartPlugin } = useSWRMutation("/api/v1/plugins/restart", mutationFetcher);
  return { plugins: data, togglePlugin, restartPlugin };
}
```

### Admin Panel

- List all plugins with status badges
- Enable/disable toggle (admin only)
- Restart button for degraded plugins
- Health status indicator
- Configuration editor (from manifest's config_schema)
