# Frontend Architecture

## Overview

Next.js 16 (App Router) + React 19 + TypeScript + Tailwind v4. SWR for data fetching, Yjs CRDT for real-time collaboration, @dnd-kit for drag-and-drop builder, CodeMirror 6 for code editing.

---

## Project Structure

```
cms/apps/web/src/
├── app/                              # Next.js App Router
│   ├── layout.tsx                    # Root: SessionProvider → SWR → ThemeProvider
│   ├── login/                        # Auth page
│   ├── (dashboard)/                  # Protected route group
│   │   ├── projects/
│   │   ├── connectors/
│   │   └── ecosystem/                # Plugin/workflow/report dashboard
│   ├── projects/[id]/workspace/      # Main editor workspace
│   │   ├── layout.tsx                # Flex container
│   │   └── page.tsx                  # WorkspacePage (state orchestrator)
│   └── api/
│       ├── auth/[...nextauth]/       # NextAuth handler
│       └── v1/[[...path]]/           # API proxy to backend
├── hooks/                            # React hooks (45+ files)
├── lib/                              # Utilities
│   ├── auth-fetch.ts                 # JWT-injecting fetch
│   ├── swr-fetcher.ts               # GET fetcher
│   ├── mutation-fetcher.ts           # POST/PATCH fetchers
│   ├── api-error.ts                  # Error class
│   ├── sync/                         # Bidirectional content sync
│   └── collaboration/                # Yjs + awareness helpers
├── components/                       # React components (30+ dirs)
│   ├── builder/                      # Visual builder
│   ├── workspace/                    # Editor container
│   ├── collaboration/                # Presence, cursors
│   ├── ecosystem/                    # Plugin/workflow panels
│   └── ui/                           # Generic Radix-based UI
├── types/                            # TypeScript types (30+ files)
└── auth.ts                           # NextAuth config
```

---

## Authentication

### NextAuth 5 (JWT Strategy)

```typescript
// auth.ts
export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      async authorize(credentials) {
        const res = await fetch(`${BACKEND_URL}/api/v1/auth/login`, {
          method: "POST",
          body: JSON.stringify(credentials),
        });
        return res.ok ? await res.json() : null;
      },
    }),
  ],
  session: { strategy: "jwt", maxAge: 7 * 24 * 60 * 60 },
  callbacks: {
    jwt({ token, user }) { /* store access_token, refresh_token */ },
    session({ session, token }) { /* expose user + role */ },
  },
});
```

### authFetch (`lib/auth-fetch.ts`)

Dual-mode fetch wrapper:

```typescript
// Server: uses auth() from auth.ts
// Client: uses getSession() with 60s token cache
async function authFetch(url: string, options?: RequestInit): Promise<Response> {
  const token = isServer ? await getServerToken() : await getClientToken();
  return fetch(url, {
    ...options,
    headers: {
      ...options?.headers,
      Authorization: `Bearer ${token}`,
    },
    signal: AbortSignal.any([
      options?.signal ?? AbortSignal.timeout(30_000),
      AbortSignal.timeout(isLongOperation ? 120_000 : 30_000),
    ]),
  });
}
```

### API Proxy (`app/api/v1/[[...path]]/route.ts`)

All `/api/v1/*` requests proxy to the FastAPI backend:
- Injects JWT from NextAuth session
- Forwards `X-Real-IP` for rate limiting
- Strips cookies (session-only)
- Supports streaming body (`duplex: "half"`)

---

## Data Fetching (SWR)

```typescript
// Read (GET)
const fetcher = <T>(url: string): Promise<T> =>
  authFetch(url).then(handleResponse);

// Mutation (POST/PATCH)
const mutationFetcher = <T>(url: string, { arg }: { arg: unknown }): Promise<T> =>
  authFetch(url, { method: "POST", body: JSON.stringify(arg) }).then(handleResponse);

// Long operation (120s timeout)
const longMutationFetcher = <T>(url: string, { arg }: { arg: unknown }): Promise<T> =>
  authFetch(url, { method: "POST", body: JSON.stringify(arg), timeout: 120_000 }).then(handleResponse);

// Usage
const { data, error, isLoading } = useSWR("/api/v1/projects", fetcher);
const { trigger, isMutating } = useSWRMutation("/api/v1/projects", mutationFetcher);
```

**SWR Config:** `revalidateOnFocus: false`, `dedupingInterval: 5000`

---

## State Management

### WorkspacePage — State Orchestrator

The main workspace page holds 15+ state pieces:

```typescript
// UI state
const [viewMode, setViewMode] = useState<"code" | "builder" | "split">("code");
const [qaPanelOpen, setQaPanelOpen] = useState(false);

// Editor state
const [editorContent, setEditorContent] = useState("");
const [savedContent, setSavedContent] = useState("");
const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");

// Preview state
const [compiledOutput, setCompiledOutput] = useState("");
const [buildTimeMs, setBuildTimeMs] = useState(0);

// QA state
const [qaResults, setQaResults] = useState<QAResult | null>(null);

// Collaboration state (via hooks)
const { status, collaborators } = useCollaboration(roomId, token);
const { followTarget, startFollowing } = usePresence(awareness);

// Derived state
const isDirty = editorContent !== savedContent;
```

### Builder State (useReducer + Undo/Redo)

```typescript
type BuilderAction =
  | { type: "ADD_SECTION"; payload: BuilderSection }
  | { type: "REMOVE_SECTION"; payload: string }
  | { type: "DUPLICATE_SECTION"; payload: string }
  | { type: "MOVE_SECTION"; payload: { id: string; newIndex: number } }
  | { type: "UPDATE_SECTION"; payload: { id: string; changes: Partial<BuilderSection> } }
  | { type: "SELECT_SECTION"; payload: string | null }
  | { type: "SET_SECTIONS"; payload: BuilderSection[] }
  | { type: "UNDO" }
  | { type: "REDO" };

// History: max 50 entries, structured clones for immutability
function useBuilderState() {
  const [state, dispatch] = useReducer(builderReducer, initialState);
  return { sections: state.sections, canUndo, canRedo, dispatch };
}
```

### Content Assembly (useMemo)

```typescript
function useBuilderPreview(sections: BuilderSection[], shell?: string) {
  return useMemo(() => {
    // Per section:
    // 1. Add data-section-id annotation
    // 2. Apply slot fills (sanitized via DOMPurify)
    // 3. Merge token override styles (CSS property mapping)
    // 4. Apply HTML attributes (block on*, style, dangerous URIs)
    // 5. Add custom CSS class (validated)
    // 6. Wrap in conditional blocks if configured
    // Collect scoped CSS for <head>
    // Assemble into document using shell
    return assembledOutput;
  }, [sections, shell]);
}
```

---

## Real-Time Collaboration

### Architecture

```
Backend WebSocket (/ws/collab/{roomId})
    ↕ Yjs Sync Protocol
Y.Doc (CRDT document)
├── Y.Text("content") → editor content sync
└── Awareness (peer presence)
    ├── Cursor positions { line, col }
    ├── Selection ranges { anchor, head }
    ├── User metadata { name, color, role }
    └── Activity state { editing, idle, viewing }
```

### useCollaboration Hook

```typescript
function useCollaboration(roomId: string, token: string) {
  const docRef = useRef<Y.Doc>();
  const providerRef = useRef<WebsocketProvider>();
  const [status, setStatus] = useState<"connecting" | "connected" | "disconnected">();

  useEffect(() => {
    const doc = new Y.Doc();
    const provider = createHubProvider(roomId, doc, token);
    provider.on("status", ({ status }) => setStatus(status));
    docRef.current = doc;
    providerRef.current = provider;
    return () => { provider.destroy(); doc.destroy(); };
  }, [roomId, token]);

  return { doc: docRef.current, status, awareness: providerRef.current?.awareness };
}
```

### usePresence Hook

```typescript
function usePresence(awareness: Awareness | null) {
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [followTarget, setFollowTarget] = useState<string | null>(null);

  // Listen to awareness changes (15s poll for idle transitions)
  // Set local activity based on role
  // Follow mode: track target's cursor position
  // 12-color palette indexed by clientId
  // Idle timeout: 60s

  return { collaborators, followTarget, startFollowing, stopFollowing, reportCursorMove };
}
```

---

## Visual Builder

### Component Hierarchy

```
WorkspacePage
├── EditorPanel (code | builder | split)
│   ├── CodeMirror (code syntax)
│   ├── SyncEngine (bidirectional content↔sections)
│   └── VisualBuilderPanel
│       ├── ComponentPalette (left, @dnd-kit drag sources)
│       ├── BuilderCanvas (center, drop zones + sections)
│       ├── SectionWrapper (selected section actions)
│       ├── BuilderPreview (sandboxed iframe)
│       └── PropertyPanel (right, 4 tabs)
│           ├── ContentTab (slot editors from definitions)
│           ├── StyleTab (design token overrides, palette colors)
│           ├── ResponsiveTab (mobile toggles/overrides)
│           └── AdvancedTab (CSS class, conditionals, attributes)
├── PreviewPanel (compiled output preview)
└── BottomPanel (AI chat, collapsible)
```

### Bidirectional Sync Engine

```typescript
class SyncEngine {
  // Code → Builder: debounced 500ms
  // Builder → Code: debounced 200ms
  // Builder wins on conflict
  // Template shell: captured after successful parse

  onCodeChange(code: string): void;     // Parse → sections
  onSectionsChange(sections: Section[]): void;  // Serialize → code
}
```

### Property Panel — Slot System

Components declare their editable slots:

```typescript
interface SlotDefinition {
  slot_id: string;
  slot_type: "headline" | "body" | "cta" | "image" | "footer" | /* ... */;
  selector: string;        // CSS selector to target
  required: boolean;
  max_chars?: number;
  placeholder: string;
  label: string;
}
```

### Design System Integration

```typescript
interface DesignSystemConfig {
  palette: {
    primary: string; secondary: string; accent: string;
    background: string; text: string; link: string;
  };
  typography: { heading_font: string; body_font: string; base_size: string };
  colors: Record<string, string>;     // Named color tokens
  fonts: Record<string, string>;      // Named font tokens
  font_sizes: Record<string, string>;
  spacing: Record<string, string>;
  button_border_radius: string;
  button_style: "filled" | "outlined" | "text";
}

// Extract palette swatches for color picker
function extractPaletteSwatches(ds: DesignSystemConfig): { role: string; hex: string }[];
```

---

## Ecosystem Dashboard

Unified panel for platform extensions:

```
/ecosystem
├── Overview (quadrant layout — plugins, workflows, reports, connectors)
├── Plugin Manager (enable/disable/restart, admin RBAC)
├── Workflow Panel (Gantt timeline, trigger dialog, log viewer)
├── Report Generator (session-persisted history, PDF preview)
└── Connector Browser (external service management)
```

**SWR Hooks:** `usePlugins()`, `useWorkflows()`, `useReports()`, `useConnectors()`

---

## Shared Packages

```
cms/packages/
├── sdk/       # @platform/sdk — OpenAPI-generated types from backend
└── ui/        # @platform/ui — Radix UI wrappers + theme provider
               #   Tabs, Card, Dialog, Popover, Sheet, Toast, etc.
               #   Semantic Tailwind tokens (text-foreground, bg-surface)
```

---

## Key Frontend Patterns

| Pattern | Implementation |
|---------|---------------|
| Data fetching | SWR hooks with `fetcher`/`mutationFetcher` |
| Auth | NextAuth JWT + `authFetch` wrapper |
| State management | `useState` + `useReducer` + SWR (no Redux/Zustand) |
| Real-time | Yjs CRDT + WebSocket + awareness |
| Code editing | CodeMirror 6 with extensions |
| Drag & drop | @dnd-kit with sortable + draggable |
| Styling | Tailwind v4 semantic tokens (never primitive colors) |
| Dialogs | Radix Dialog for detail views (not Sheet) |
| Toasts | Sonner for notifications |
| API proxy | Next.js catch-all route → backend |
| Performance | `useMemo` for expensive calcs, debounced sync |
