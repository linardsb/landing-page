"""Shared models, schemas, and utilities used across feature slices."""
