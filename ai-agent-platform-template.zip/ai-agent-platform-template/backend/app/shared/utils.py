"""
Shared utility functions.
"""

from __future__ import annotations


def escape_like(value: str) -> str:
    """Escape %, _, \\ for SQL LIKE/ILIKE queries. Prevents injection."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
