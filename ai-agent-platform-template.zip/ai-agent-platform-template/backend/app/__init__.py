"""AI Agent Platform — backend application package."""
