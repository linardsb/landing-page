"""
Middleware stack.

Applied in order:
  1. BodySizeLimitMiddleware — reject oversized payloads
  2. RequestLoggingMiddleware — correlation IDs, timing, error logging
  3. CORSMiddleware — configured separately in main.py
"""

from __future__ import annotations

import time
import uuid
from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app.core.config import get_settings
from app.core.logging import get_logger, set_request_id

if TYPE_CHECKING:
    from starlette.types import ASGIApp

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Body size limit
# ---------------------------------------------------------------------------

UPLOAD_PREFIXES = ("/api/v1/knowledge", "/api/v1/uploads", "/mcp")


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject payloads exceeding configured limits."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        settings = get_settings()
        path = request.url.path

        limit = settings.body_limit.upload_bytes if any(
            path.startswith(p) for p in UPLOAD_PREFIXES
        ) else settings.body_limit.default_bytes

        content_length = request.headers.get("content-length")
        if content_length is not None:
            if int(content_length) > limit:
                return JSONResponse(
                    status_code=413,
                    content={"error": "Payload too large", "type": "payload_too_large"},
                )
        elif request.method in ("POST", "PUT", "PATCH"):
            # No content-length header on methods that should have a body
            return JSONResponse(
                status_code=411,
                content={"error": "Content-Length required", "type": "length_required"},
            )

        return await call_next(request)


# ---------------------------------------------------------------------------
# Request logging + correlation ID
# ---------------------------------------------------------------------------


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Inject correlation ID, log request/response timing."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Extract or generate request ID
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        set_request_id(request_id)

        logger.info(
            "http.request_received",
            method=request.method,
            path=request.url.path,
        )

        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("http.request_failed", method=request.method, path=request.url.path)
            raise

        duration_ms = round((time.perf_counter() - start) * 1000, 1)

        response.headers["X-Request-ID"] = request_id

        logger.info(
            "http.request_completed",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            duration_ms=duration_ms,
        )

        return response
