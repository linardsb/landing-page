"""
Application exception hierarchy.

All domain errors inherit from AppError. The global exception handler
maps each subclass to its HTTP status code automatically.

Usage:
    raise NotFoundError("Project not found")
    raise DomainValidationError("Name must be unique")
    raise ForbiddenError("Access denied")
"""

from __future__ import annotations


class AppError(Exception):
    """Base for all application errors. Maps to HTTP status."""

    status_code: int = 500
    error_type: str = "internal_error"

    def __init__(self, message: str, *, detail: str | None = None) -> None:
        self.message = message
        self.detail = detail
        super().__init__(message)


class NotFoundError(AppError):
    status_code = 404
    error_type = "not_found"


class DomainValidationError(AppError):
    status_code = 422
    error_type = "validation_error"


class ForbiddenError(AppError):
    status_code = 403
    error_type = "forbidden"


class ConflictError(AppError):
    status_code = 409
    error_type = "conflict"


class ServiceUnavailableError(AppError):
    status_code = 503
    error_type = "service_unavailable"


class InvalidCredentialsError(AppError):
    status_code = 401
    error_type = "invalid_credentials"


class AccountLockedError(AppError):
    status_code = 423
    error_type = "account_locked"


# ---------------------------------------------------------------------------
# Error sanitization — prevent information leakage
# ---------------------------------------------------------------------------

_PASSTHROUGH_TYPES: set[type[AppError]] = {
    NotFoundError,
    DomainValidationError,
    ForbiddenError,
    ConflictError,
    InvalidCredentialsError,
    AccountLockedError,
}


def get_safe_error_message(exc: AppError) -> str:
    """Only whitelisted error types pass messages through."""
    if type(exc) in _PASSTHROUGH_TYPES:
        return exc.message
    return "An internal error occurred"


def get_safe_error_type(exc: AppError) -> str:
    """Return the error type string."""
    return exc.error_type
