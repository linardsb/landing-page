"""
Redis singleton with graceful fallback.

Uses:
  - Rate limiting storage
  - Token revocation denylist
  - Brute-force lockout
  - WebSocket pub/sub relay
  - Cache (reports, prompts, etc.)
  - Feature flags
"""

from __future__ import annotations

from redis.asyncio import Redis

from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)

_redis_client: Redis | None = None


async def get_redis() -> Redis:
    """Get or create the Redis singleton."""
    global _redis_client
    if _redis_client is None:
        settings = get_settings()
        _redis_client = Redis.from_url(
            settings.redis.url,
            decode_responses=False,
        )
    return _redis_client


async def redis_available() -> bool:
    """Check Redis connectivity (non-throwing)."""
    try:
        client = await get_redis()
        await client.ping()
        return True
    except Exception:
        logger.warning("redis.health_check_failed")
        return False


async def close_redis() -> None:
    """Call on application shutdown."""
    global _redis_client
    if _redis_client is not None:
        await _redis_client.aclose()
        _redis_client = None
