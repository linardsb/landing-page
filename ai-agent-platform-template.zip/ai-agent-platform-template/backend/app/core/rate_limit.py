"""
Redis-backed rate limiting via slowapi.

Key function extracts IP from X-Real-IP header (proxy-safe).
Falls back to in-memory if Redis is unavailable.
"""

from __future__ import annotations

from slowapi import Limiter
from starlette.requests import Request

from app.core.config import get_settings


def _get_remote_address(request: Request) -> str:
    """Extract client IP from X-Real-IP (set by reverse proxy, not client-spoofable)."""
    return request.headers.get("X-Real-IP", request.client.host if request.client else "unknown")


settings = get_settings()

limiter = Limiter(
    key_func=_get_remote_address,
    storage_uri=settings.redis.url,
    default_limits=[settings.rate_limit.default],
)
