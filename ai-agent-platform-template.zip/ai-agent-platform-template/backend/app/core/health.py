"""
Health check endpoints.

  /health       — Liveness
  /health/db    — Database connectivity (10s cache)
  /health/redis — Redis connectivity (10s cache)
  /health/ready — Readiness (all dependencies)
"""

from __future__ import annotations

import time

from fastapi import APIRouter

from app.core.database import get_db_context
from app.core.redis import redis_available

router = APIRouter(tags=["health"])

_db_cache: dict[str, tuple[bool, float]] = {}
_redis_cache: dict[str, tuple[bool, float]] = {}
_CACHE_TTL = 10.0  # seconds


@router.get("/health")
async def liveness() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/health/db")
async def db_health() -> dict[str, str | bool]:
    now = time.monotonic()
    cached = _db_cache.get("db")
    if cached and (now - cached[1]) < _CACHE_TTL:
        return {"status": "ok" if cached[0] else "degraded", "cached": True}

    try:
        async with get_db_context() as session:
            await session.execute("SELECT 1")
        _db_cache["db"] = (True, now)
        return {"status": "ok"}
    except Exception:
        _db_cache["db"] = (False, now)
        return {"status": "degraded"}


@router.get("/health/redis")
async def redis_health() -> dict[str, str | bool]:
    now = time.monotonic()
    cached = _redis_cache.get("redis")
    if cached and (now - cached[1]) < _CACHE_TTL:
        return {"status": "ok" if cached[0] else "degraded", "cached": True}

    available = await redis_available()
    _redis_cache["redis"] = (available, now)
    return {"status": "ok" if available else "degraded"}


@router.get("/health/ready")
async def readiness() -> dict[str, str]:
    db_ok = (await db_health())["status"] == "ok"
    redis_ok = (await redis_health())["status"] == "ok"

    if db_ok and redis_ok:
        return {"status": "ready"}
    return {"status": "not_ready"}
