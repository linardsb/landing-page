"""
Structured logging with structlog.

Features:
  - JSON output for machine parsing
  - Request ID correlation via ContextVar
  - Log injection prevention (regex-validated request IDs)
  - Convention: domain.action_state (e.g., "projects.create_completed")
"""

from __future__ import annotations

import logging
import re
from contextvars import ContextVar

import structlog

# ---------------------------------------------------------------------------
# Request ID correlation
# ---------------------------------------------------------------------------

_request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)

SAFE_REQUEST_ID = re.compile(r"^[a-zA-Z0-9\-_.]{1,64}$")


def set_request_id(request_id: str) -> None:
    """Set request ID for the current async context (validated)."""
    if SAFE_REQUEST_ID.match(request_id):
        _request_id_var.set(request_id)


def get_request_id() -> str | None:
    return _request_id_var.get()


# ---------------------------------------------------------------------------
# Processors
# ---------------------------------------------------------------------------


def _add_request_id(
    logger: structlog.types.WrappedLogger,
    method_name: str,
    event_dict: structlog.types.EventDict,
) -> structlog.types.EventDict:
    request_id = _request_id_var.get()
    if request_id:
        event_dict["request_id"] = request_id
    return event_dict


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


def configure_logging(*, json_output: bool = True, log_level: str = "INFO") -> None:
    """Call once during application startup."""

    shared_processors: list[structlog.types.Processor] = [
        _add_request_id,
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if json_output:
        shared_processors.append(structlog.processors.JSONRenderer())
    else:
        shared_processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=shared_processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    logging.basicConfig(format="%(message)s", level=getattr(logging, log_level))


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Get a named, context-aware logger.

    Usage:
        logger = get_logger(__name__)
        logger.info("projects.create_completed", project_id=42)
    """
    return structlog.get_logger(name)
