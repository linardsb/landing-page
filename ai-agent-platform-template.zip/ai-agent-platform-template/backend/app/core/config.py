"""
Nested Pydantic Settings configuration.

Environment variables use double-underscore delimiter:
  DATABASE__URL, AUTH__JWT_SECRET_KEY, AI__PROVIDER, etc.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


# ---------------------------------------------------------------------------
# Configuration Groups
# ---------------------------------------------------------------------------

class DatabaseConfig(BaseModel):
    url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/app"
    pool_size: int = 3
    max_overflow: int = 5
    pool_recycle: int = 3600
    echo: bool = False


class RedisConfig(BaseModel):
    url: str = "redis://localhost:6379/0"


class AuthConfig(BaseModel):
    jwt_secret_key: str = "CHANGE-ME-IN-PRODUCTION"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    max_failed_attempts: int = 5
    lockout_duration_seconds: int = 900


class RateLimitConfig(BaseModel):
    default: str = "120/minute"
    auth: str = "10/minute"
    ai_chat: str = "10/minute"


class AIConfig(BaseModel):
    provider: str = "openai"
    default_model: str = "gpt-4o"
    complex_model: str = "gpt-4o"
    standard_model: str = "gpt-4o-mini"
    lightweight_model: str = "gpt-4o-mini"
    max_tokens_default: int = 8192
    fallback_chains: str = ""  # JSON: {"complex": ["openai:gpt-4o", "anthropic:claude-sonnet"]}
    prompt_store_enabled: bool = False
    production_sample_rate: float = 0.0


class CORSConfig(BaseModel):
    allowed_origins: list[str] = ["http://localhost:3000", "http://localhost:8891"]


class BodyLimitConfig(BaseModel):
    default_bytes: int = 102_400       # 100KB
    upload_bytes: int = 52_428_800     # 50MB


class KnowledgeConfig(BaseModel):
    embedding_provider: str = "openai"
    embedding_model: str = "text-embedding-3-small"
    chunk_size: int = 512
    chunk_overlap: int = 64
    reranker_enabled: bool = False


class StreamingConfig(BaseModel):
    max_peers_per_room: int = 20
    max_rooms_per_user: int = 10
    crdt_compact_threshold: int = 100
    crdt_max_document_bytes: int = 5_242_880


class MCPConfig(BaseModel):
    enabled: bool = True
    allowed_tools: list[str] = Field(default_factory=list)  # Empty = all


class ReportingConfig(BaseModel):
    enabled: bool = False
    cache_ttl_hours: int = 24


# ---------------------------------------------------------------------------
# Root Settings
# ---------------------------------------------------------------------------

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Core
    database: DatabaseConfig = DatabaseConfig()
    redis: RedisConfig = RedisConfig()
    auth: AuthConfig = AuthConfig()
    rate_limit: RateLimitConfig = RateLimitConfig()
    cors: CORSConfig = CORSConfig()
    body_limit: BodyLimitConfig = BodyLimitConfig()

    # AI
    ai: AIConfig = AIConfig()
    knowledge: KnowledgeConfig = KnowledgeConfig()

    # Streaming
    streaming: StreamingConfig = StreamingConfig()

    # Subsystems
    mcp: MCPConfig = MCPConfig()
    reporting: ReportingConfig = ReportingConfig()

    # Feature toggles
    plugins_enabled: bool = False
    workflows_enabled: bool = False
    tms_enabled: bool = False

    # Application
    environment: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    encryption_key: str = ""  # Fernet key for credential encryption


@lru_cache
def get_settings() -> Settings:
    return Settings()
