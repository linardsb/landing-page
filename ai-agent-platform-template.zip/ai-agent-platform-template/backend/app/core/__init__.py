"""Core infrastructure: config, database, logging, middleware, exceptions."""
