"""
Application entry point with lifespan management.

Startup: security checks → logging → DB → Redis → background pollers → plugins → workflows
Shutdown: stop pollers → shutdown plugins → close Redis → dispose DB
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.database import dispose_engine
from app.core.exceptions import AppError, get_safe_error_message, get_safe_error_type
from app.core.health import router as health_router
from app.core.logging import configure_logging, get_logger
from app.core.middleware import BodySizeLimitMiddleware, RequestLoggingMiddleware
from app.core.rate_limit import limiter
from app.core.redis import close_redis

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()

    # --- STARTUP ---
    configure_logging(
        json_output=settings.environment != "development",
        log_level="DEBUG" if settings.debug else "INFO",
    )
    logger.info("app.startup_started", environment=settings.environment)

    # Security checks
    if settings.environment == "production":
        if settings.auth.jwt_secret_key == "CHANGE-ME-IN-PRODUCTION":
            raise RuntimeError("JWT secret must be changed in production")

    # Initialize connections (DB pool created lazily on first query)
    # Redis initialized lazily on first get_redis() call

    # Start background pollers
    # await start_websocket_subscriber()
    # await start_health_monitors()
    # await start_checkpoint_cleanup()

    # Optional subsystems
    if settings.plugins_enabled:
        logger.info("app.plugins_loading")
        # await load_plugin_registry()
        # await start_plugin_lifecycle()

    if settings.workflows_enabled:
        logger.info("app.workflows_syncing")
        # await sync_workflow_templates()

    logger.info("app.startup_completed")

    yield  # App serves requests

    # --- SHUTDOWN ---
    logger.info("app.shutdown_started")

    # Stop background tasks
    # await stop_background_pollers()

    if settings.plugins_enabled:
        pass  # await shutdown_plugin_lifecycle()

    await close_redis()
    await dispose_engine()

    logger.info("app.shutdown_completed")


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="AI Agent Platform",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Middleware (applied in reverse order — last added = first executed)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors.allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID", "Accept"],
    )
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(BodySizeLimitMiddleware)

    # Rate limiter
    app.state.limiter = limiter

    # Global exception handler
    @app.exception_handler(AppError)
    async def app_error_handler(request, exc: AppError):
        from starlette.responses import JSONResponse
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": get_safe_error_message(exc),
                "type": get_safe_error_type(exc),
            },
        )

    # --- Routes ---
    app.include_router(health_router)

    # Core feature routers
    # app.include_router(auth_router, prefix="/api/v1")
    from app.projects.routes import router as projects_router
    app.include_router(projects_router, prefix="/api/v1")

    # AI blueprint pipeline routes
    from app.ai.blueprints.routes import router as blueprints_router
    app.include_router(blueprints_router, prefix="/api/v1")

    # Optional subsystem routers
    if settings.plugins_enabled:
        pass  # app.include_router(plugins_router, prefix="/api/v1")
    if settings.workflows_enabled:
        pass  # app.include_router(workflows_router, prefix="/api/v1")
    if settings.reporting.enabled:
        pass  # app.include_router(reports_router, prefix="/api/v1")
    if settings.mcp.enabled:
        pass  # app.mount("/mcp", mcp_asgi_app)

    return app


app = create_app()
