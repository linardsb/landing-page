"""
Plugin sandbox — timeout, error isolation, health monitoring.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Callable, Literal


@dataclass
class PluginHealth:
    status: Literal["healthy", "degraded", "unhealthy"]
    message: str
    latency_ms: float


class PluginSandbox:
    """Execute plugin functions with timeout and error isolation."""

    async def execute(
        self,
        plugin_module: Any,
        func_name: str,
        *args: Any,
        timeout: float = 30.0,
        **kwargs: Any,
    ) -> Any:
        """Run a plugin function with timeout protection.

        Handles both sync and async callables.
        """
        func = getattr(plugin_module, func_name, None)
        if func is None:
            raise AttributeError(f"Plugin has no function '{func_name}'")

        start = time.perf_counter()

        if asyncio.iscoroutinefunction(func):
            result = await asyncio.wait_for(func(*args, **kwargs), timeout=timeout)
        else:
            result = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(None, lambda: func(*args, **kwargs)),
                timeout=timeout,
            )

        return result

    async def check_health(
        self,
        plugin_module: Any,
        timeout: float = 5.0,
    ) -> PluginHealth:
        """Run plugin's health function (if available)."""
        health_fn = getattr(plugin_module, "health", None)
        if health_fn is None:
            return PluginHealth(status="healthy", message="No health check defined", latency_ms=0.0)

        start = time.perf_counter()
        try:
            if asyncio.iscoroutinefunction(health_fn):
                result = await asyncio.wait_for(health_fn(), timeout=timeout)
            else:
                result = await asyncio.wait_for(
                    asyncio.get_event_loop().run_in_executor(None, health_fn),
                    timeout=timeout,
                )
            latency = (time.perf_counter() - start) * 1000
            return PluginHealth(
                status="healthy" if result else "degraded",
                message="OK" if result else "Health check returned False",
                latency_ms=round(latency, 1),
            )
        except asyncio.TimeoutError:
            latency = (time.perf_counter() - start) * 1000
            return PluginHealth(status="unhealthy", message="Health check timed out", latency_ms=round(latency, 1))
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000
            return PluginHealth(status="unhealthy", message=str(exc), latency_ms=round(latency, 1))
