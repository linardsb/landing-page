"""
Plugin manifest — strict Pydantic schemas with validation.
"""

from __future__ import annotations

import re
from enum import Enum

from pydantic import BaseModel, field_validator


class PluginType(str, Enum):
    qa_check = "qa_check"
    agent_skill = "agent_skill"
    export_connector = "export_connector"
    component_package = "component_package"
    theme = "theme"
    workflow_step = "workflow_step"


class PluginPermission(str, Enum):
    read_content = "read_content"
    write_content = "write_content"
    read_qa_results = "read_qa_results"
    write_qa_results = "write_qa_results"
    call_llm = "call_llm"
    network_access = "network_access"
    file_read = "file_read"


REVERSE_DOMAIN_PATTERN = re.compile(r"^[a-z][a-z0-9\-]*(\.[a-z][a-z0-9\-]*){1,5}$")
SEMVER_PATTERN = re.compile(r"^\d+\.\d+\.\d+$")


class PluginManifest(BaseModel):
    """Plugin declaration — validated on discovery."""

    name: str
    version: str
    plugin_type: PluginType
    description: str
    author: str
    permissions: list[PluginPermission] = []
    entry_point: str
    config_schema: dict | None = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not REVERSE_DOMAIN_PATTERN.match(v):
            raise ValueError(f"Plugin name must be reverse domain notation: {v}")
        if len(v) < 3 or len(v) > 64:
            raise ValueError(f"Plugin name must be 3-64 characters: {v}")
        return v

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        if not SEMVER_PATTERN.match(v):
            raise ValueError(f"Version must be semantic (X.Y.Z): {v}")
        return v
