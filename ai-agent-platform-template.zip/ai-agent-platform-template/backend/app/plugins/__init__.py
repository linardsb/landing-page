"""Plugin system: manifest discovery, sandboxed execution, lifecycle management."""
