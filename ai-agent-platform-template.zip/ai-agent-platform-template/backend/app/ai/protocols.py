"""
AI provider protocols — the contracts that all LLM/Embedding/Reranker backends must satisfy.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Message types
# ---------------------------------------------------------------------------

@dataclass
class ContentBlock:
    """Base for multimodal content blocks."""
    type: str


@dataclass
class TextBlock(ContentBlock):
    type: str = "text"
    text: str = ""


@dataclass
class ImageBlock(ContentBlock):
    type: str = "image"
    data: bytes | None = None
    media_type: str = "image/png"
    source: str = "base64"  # "base64" or "url"
    url: str | None = None
    width: int | None = None
    height: int | None = None


@dataclass
class AudioBlock(ContentBlock):
    type: str = "audio"
    data: bytes = b""
    media_type: str = "audio/wav"
    duration_seconds: float = 0.0


@dataclass
class StructuredOutputBlock(ContentBlock):
    type: str = "structured_output"
    schema: dict = field(default_factory=dict)
    name: str = ""
    strict: bool = True


@dataclass
class Message:
    role: str  # "user", "assistant", "system"
    content: str | list[ContentBlock]
    cache_control: dict[str, str] | None = None


# ---------------------------------------------------------------------------
# Response types
# ---------------------------------------------------------------------------

@dataclass
class CompletionResponse:
    content: str
    model: str
    usage: dict[str, int] | None = None
    parsed: dict[str, object] | None = None  # Structured output


@dataclass
class RerankResult:
    index: int
    score: float
    document: str


# ---------------------------------------------------------------------------
# Provider protocols
# ---------------------------------------------------------------------------

@runtime_checkable
class LLMProvider(Protocol):
    async def complete(self, messages: list[Message], **kwargs: object) -> CompletionResponse: ...
    async def stream(self, messages: list[Message], **kwargs: object) -> AsyncIterator[str]: ...


@runtime_checkable
class EmbeddingProvider(Protocol):
    async def embed(self, texts: list[str]) -> list[list[float]]: ...


@runtime_checkable
class RerankerProvider(Protocol):
    async def rerank(self, query: str, documents: list[str], top_k: int = 5) -> list[RerankResult]: ...
