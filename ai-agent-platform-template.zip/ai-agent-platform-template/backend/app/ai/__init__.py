"""AI subsystem: agents, blueprints, cost governance, and routing."""
