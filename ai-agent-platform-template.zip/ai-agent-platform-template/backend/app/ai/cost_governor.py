"""
Cost governance — Redis-backed token + cost tracking with budget caps.

Tracks input/output tokens, cost per model/agent/project in monthly buckets.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Literal

from app.core.logging import get_logger
from app.core.redis import get_redis

logger = get_logger(__name__)

BudgetStatus = Literal["ok", "warning", "exceeded"]


# Model pricing (per 1M tokens, configurable)
DEFAULT_PRICING: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "claude-3.5-sonnet": {"input": 3.00, "output": 15.00},
}


@dataclass
class UsageRecord:
    model: str
    agent: str
    project_id: int | None
    input_tokens: int
    output_tokens: int
    cost: float
    timestamp: str


class CostGovernor:
    """Redis-backed cost tracking with budget enforcement."""

    def __init__(self, pricing: dict[str, dict[str, float]] | None = None) -> None:
        self.pricing = pricing or DEFAULT_PRICING

    def _month_key(self, month: str | None = None) -> str:
        return month or datetime.utcnow().strftime("%Y-%m")

    def _calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        rates = self.pricing.get(model, {"input": 1.0, "output": 3.0})
        return (input_tokens * rates["input"] + output_tokens * rates["output"]) / 1_000_000

    async def record_usage(
        self,
        model: str,
        agent: str,
        project_id: int | None,
        input_tokens: int,
        output_tokens: int,
    ) -> None:
        """Record usage to monthly Redis bucket."""
        redis = await get_redis()
        month = self._month_key()
        cost = self._calculate_cost(model, input_tokens, output_tokens)

        pipe = redis.pipeline()
        pipe.hincrbyfloat(f"cost:{month}:total", "cost", cost)
        pipe.hincrby(f"cost:{month}:total", "input_tokens", input_tokens)
        pipe.hincrby(f"cost:{month}:total", "output_tokens", output_tokens)
        pipe.hincrbyfloat(f"cost:{month}:model:{model}", "cost", cost)
        pipe.hincrbyfloat(f"cost:{month}:agent:{agent}", "cost", cost)
        if project_id:
            pipe.hincrbyfloat(f"cost:{month}:project:{project_id}", "cost", cost)
        await pipe.execute()

        logger.info(
            "cost.usage_recorded",
            model=model,
            agent=agent,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost=round(cost, 6),
        )

    async def get_monthly_cost(self, month: str | None = None) -> float:
        """Total cost for a given month."""
        redis = await get_redis()
        key = f"cost:{self._month_key(month)}:total"
        raw = await redis.hget(key, "cost")
        return float(raw) if raw else 0.0

    async def check_budget(
        self,
        project_id: int,
        monthly_budget: float,
        warning_threshold: float = 0.8,
    ) -> BudgetStatus:
        """Check if project is within budget."""
        redis = await get_redis()
        month = self._month_key()
        raw = await redis.hget(f"cost:{month}:project:{project_id}", "cost")
        current = float(raw) if raw else 0.0

        if current >= monthly_budget:
            return "exceeded"
        if current >= monthly_budget * warning_threshold:
            return "warning"
        return "ok"
