"""Blueprint engine: state-machine orchestration of agent pipelines."""
