"""
Blueprint State Machine Engine.

Orchestrates multi-agent pipelines as directed graphs.
Nodes are either agentic (LLM-powered) or deterministic (rule-based).
Edges define transitions based on outcomes.
Built-in QA gating and bounded self-correction loops.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Constraints
# ---------------------------------------------------------------------------

MAX_SELF_CORRECTION_ROUNDS = 2
MAX_TOTAL_STEPS = 25
CONFIDENCE_REVIEW_THRESHOLD = 0.5

# ---------------------------------------------------------------------------
# Protocols & data classes
# ---------------------------------------------------------------------------

NodeStatus = Literal["success", "failed", "skipped"]
HandoffStatus = Literal["ok", "warning", "blocked", "failed"]


@dataclass
class NodeContext:
    """Context passed to each node (progressively hydrated)."""
    output: str
    brief: str
    node_rules: str = ""
    qa_failures: list[str] = field(default_factory=list)
    iteration: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    build_plan: Any | None = None
    multimodal_context: list[Any] | None = None


@dataclass
class AgentHandoff:
    """Structured summary of agent work (from agentic nodes)."""
    status: HandoffStatus
    agent_name: str
    artifact: str
    decisions: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    component_refs: tuple[str, ...] = ()
    confidence: float | None = None
    uncertainties: tuple[str, ...] = ()
    typed_payload: Any | None = None


@dataclass
class NodeResult:
    """Result from node execution."""
    status: NodeStatus
    output: str = ""
    details: str = ""
    error: str = ""
    usage: dict[str, int] | None = None
    handoff: AgentHandoff | None = None
    structured_failures: tuple[Any, ...] = ()


class BlueprintNode(Protocol):
    """Protocol that all blueprint nodes must satisfy."""

    @property
    def name(self) -> str: ...

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]: ...

    async def execute(self, context: NodeContext) -> NodeResult: ...


# ---------------------------------------------------------------------------
# Graph definition
# ---------------------------------------------------------------------------

@dataclass
class Edge:
    from_node: str
    to_node: str
    condition: Literal["success", "qa_fail", "always", "route_to"]
    route_value: str | None = None


@dataclass
class BlueprintDefinition:
    name: str
    nodes: dict[str, BlueprintNode]
    edges: list[Edge]
    entry_node: str


# ---------------------------------------------------------------------------
# Run state
# ---------------------------------------------------------------------------

@dataclass
class StepRecord:
    node_name: str
    status: NodeStatus
    details: str
    usage: dict[str, int] | None


@dataclass
class BlueprintRun:
    """Mutable state tracking for a blueprint execution."""
    brief: str
    output: str = ""
    status: str = "running"
    total_steps: int = 0
    iteration_counts: dict[str, int] = field(default_factory=dict)
    qa_failures: list[str] = field(default_factory=list)
    token_usage: dict[str, int] = field(default_factory=lambda: {"input": 0, "output": 0})
    handoff_history: list[AgentHandoff] = field(default_factory=list)
    step_log: list[StepRecord] = field(default_factory=list)
    build_plan: Any | None = None

    def record_step(self, node_name: str, result: NodeResult) -> None:
        self.total_steps += 1
        self.step_log.append(StepRecord(
            node_name=node_name,
            status=result.status,
            details=result.details,
            usage=result.usage,
        ))
        if result.output:
            self.output = result.output
        if result.usage:
            self.token_usage["input"] += result.usage.get("input_tokens", 0)
            self.token_usage["output"] += result.usage.get("output_tokens", 0)

    def record_handoff(self, handoff: AgentHandoff) -> None:
        self.handoff_history.append(handoff)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class BlueprintEngine:
    """Executes a blueprint definition as a directed graph."""

    async def run(self, definition: BlueprintDefinition, brief: str) -> BlueprintRun:
        run = BlueprintRun(brief=brief)
        current_node: str | None = definition.entry_node

        logger.info("blueprint.run_started", blueprint=definition.name)

        while current_node and run.total_steps < MAX_TOTAL_STEPS:
            node = definition.nodes[current_node]

            # Build context
            context = self._build_context(run, node)

            # Execute
            logger.info(
                "blueprint.node_executing",
                node=current_node,
                type=node.node_type,
                iteration=context.iteration,
            )

            try:
                result = await node.execute(context)
            except Exception as exc:
                logger.exception("blueprint.node_failed", node=current_node)
                result = NodeResult(status="failed", error=str(exc))

            # Record
            run.record_step(current_node, result)

            if result.handoff:
                run.record_handoff(result.handoff)

            # Track iterations per node (for self-correction bounds)
            run.iteration_counts[current_node] = run.iteration_counts.get(current_node, 0) + 1

            # Check self-correction limit
            if run.iteration_counts[current_node] > MAX_SELF_CORRECTION_ROUNDS + 1:
                logger.warning(
                    "blueprint.max_corrections_reached",
                    node=current_node,
                    iterations=run.iteration_counts[current_node],
                )
                result = NodeResult(status="failed", error="Max self-correction rounds exceeded")

            # Track QA failures for downstream nodes
            if result.structured_failures:
                run.qa_failures = [str(f) for f in result.structured_failures]
            elif result.status == "success":
                run.qa_failures = []

            # Resolve next node
            current_node = self._resolve_next(definition, current_node, result)

        # Final status
        if run.total_steps >= MAX_TOTAL_STEPS:
            run.status = "failed"
            logger.warning("blueprint.max_steps_reached", steps=run.total_steps)
        elif any(s.status == "failed" for s in run.step_log[-1:]):
            run.status = "failed"
        else:
            run.status = "completed"

        # Check confidence
        if run.handoff_history:
            min_confidence = min(
                (h.confidence for h in run.handoff_history if h.confidence is not None),
                default=1.0,
            )
            if min_confidence < CONFIDENCE_REVIEW_THRESHOLD:
                run.status = "needs_review"

        logger.info(
            "blueprint.run_completed",
            blueprint=definition.name,
            status=run.status,
            steps=run.total_steps,
        )

        return run

    def _build_context(self, run: BlueprintRun, node: BlueprintNode) -> NodeContext:
        context = NodeContext(
            output=run.output,
            brief=run.brief,
            qa_failures=run.qa_failures,
            iteration=run.iteration_counts.get(node.name, 0),
        )

        # Inject handoff history
        if run.handoff_history:
            context.metadata["upstream_handoff"] = run.handoff_history[-1]
            context.metadata["handoff_history"] = run.handoff_history

        context.metadata["total_steps"] = run.total_steps

        if run.build_plan:
            context.build_plan = run.build_plan

        return context

    def _resolve_next(
        self,
        definition: BlueprintDefinition,
        current_node: str,
        result: NodeResult,
    ) -> str | None:
        for edge in definition.edges:
            if edge.from_node != current_node:
                continue

            match edge.condition:
                case "success" if result.status == "success":
                    return edge.to_node
                case "qa_fail" if result.status == "failed":
                    return edge.to_node
                case "always":
                    return edge.to_node
                case "route_to" if edge.route_value and edge.route_value in result.details:
                    return edge.to_node

        return None  # Pipeline complete
