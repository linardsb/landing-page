"""Analysis pipeline — the canonical multi-agent content analysis workflow.

Graph:
    Analyzer -> Repair -> QA Gate --(success)--> [done]
                                  --(qa_fail)--> Fixer -> Repair (loop back to QA Gate)

The QA gate re-evaluates after the fixer runs. The engine's built-in
MAX_SELF_CORRECTION_ROUNDS (2) bounds the loop to prevent infinite cycles.
"""

from __future__ import annotations

from app.ai.blueprints.engine import BlueprintDefinition, Edge
from app.ai.blueprints.nodes.analyzer_node import AnalyzerNode
from app.ai.blueprints.nodes.fixer_node import FixerNode
from app.ai.blueprints.nodes.qa_gate_node import QAGateNode
from app.ai.blueprints.nodes.repair_node import RepairNode


def build_analysis_pipeline(
    *,
    fail_on_warnings: bool = False,
) -> BlueprintDefinition:
    """Build the standard analysis pipeline.

    Args:
        fail_on_warnings: If True, the QA gate will also fail on warning-level
            issues (not just critical). Useful for strict compliance checks.

    Returns:
        A BlueprintDefinition ready to execute with BlueprintEngine.run().
    """
    # Instantiate nodes
    analyzer = AnalyzerNode()
    repair = RepairNode()
    qa_gate = QAGateNode(fail_on_warnings=fail_on_warnings)
    fixer = FixerNode()

    # We need distinct repair instances for pre-QA and post-fix stages,
    # but they can share the same class. We use name prefixes to
    # disambiguate in the graph.
    repair_post_fix = _PrefixedRepairNode("repair_post_fix")

    nodes = {
        analyzer.name: analyzer,
        repair.name: repair,
        qa_gate.name: qa_gate,
        fixer.name: fixer,
        repair_post_fix.name: repair_post_fix,
    }

    edges = [
        # Analyzer -> Repair (deterministic cleanup before QA)
        Edge(from_node="analyzer", to_node="repair", condition="success"),

        # Repair -> QA Gate
        Edge(from_node="repair", to_node="qa_gate", condition="always"),

        # QA Gate -> done (success path — no more edges, pipeline ends)
        # (success with no outgoing edge = pipeline complete)

        # QA Gate -> Fixer (failure path)
        Edge(from_node="qa_gate", to_node="fixer", condition="qa_fail"),

        # Fixer -> Repair (post-fix cleanup)
        Edge(from_node="fixer", to_node="repair_post_fix", condition="success"),

        # Post-fix Repair -> QA Gate (re-evaluate)
        Edge(from_node="repair_post_fix", to_node="qa_gate", condition="always"),
    ]

    return BlueprintDefinition(
        name="analysis_pipeline",
        nodes=nodes,
        edges=edges,
        entry_node="analyzer",
    )


class _PrefixedRepairNode(RepairNode):
    """RepairNode with a custom name for graph disambiguation."""

    def __init__(self, node_name: str) -> None:
        self._node_name = node_name

    @property
    def name(self) -> str:
        return self._node_name
