"""Blueprint pipelines — pre-built multi-agent orchestration graphs."""
