"""Blueprint API routes — run and query agent pipelines."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.ai.blueprints.engine import (
    BlueprintDefinition,
    BlueprintEngine,
    BlueprintNode,
    BlueprintRun,
    NodeContext,
)
from app.ai.blueprints.pipelines.analysis_pipeline import build_analysis_pipeline
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/ai/blueprints", tags=["blueprints"])


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------

class BlueprintRunRequest(BaseModel):
    """Request to run a blueprint pipeline."""

    brief: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Brief describing the analysis task.",
    )
    content: str = Field(
        ...,
        min_length=1,
        max_length=100_000,
        description="Content to analyze.",
    )
    analysis_type: Literal["quality", "compliance", "performance"] = Field(
        default="quality",
        description="Type of analysis to perform.",
    )
    fail_on_warnings: bool = Field(
        default=False,
        description="If true, warnings also block the QA gate.",
    )


class StepSummary(BaseModel):
    node: str
    status: str
    details: str


class BlueprintRunResponse(BaseModel):
    """Response from a blueprint pipeline execution."""

    status: str
    output: str
    total_steps: int
    token_usage: dict[str, int]
    steps: list[StepSummary]
    handoff_count: int


class BlueprintStatusResponse(BaseModel):
    """Placeholder response for async run status queries."""

    run_id: str
    status: str
    message: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.post("/run", response_model=BlueprintRunResponse)
async def run_blueprint(request: BlueprintRunRequest) -> BlueprintRunResponse:
    """Run the analysis pipeline on the provided content.

    Orchestrates: Analyzer -> Repair -> QA Gate -> (optional) Fixer -> Repair loop.
    """
    logger.info(
        "blueprints.run_requested",
        analysis_type=request.analysis_type,
        content_length=len(request.content),
        fail_on_warnings=request.fail_on_warnings,
    )

    pipeline = build_analysis_pipeline(
        fail_on_warnings=request.fail_on_warnings,
    )

    engine = _ContentSeededEngine(
        content=request.content,
        analysis_type=request.analysis_type,
    )

    run = await engine.run(pipeline, brief=request.brief)

    steps = [
        StepSummary(
            node=s.node_name,
            status=s.status,
            details=s.details,
        )
        for s in run.step_log
    ]

    return BlueprintRunResponse(
        status=run.status,
        output=run.output,
        total_steps=run.total_steps,
        token_usage=run.token_usage,
        steps=steps,
        handoff_count=len(run.handoff_history),
    )


@router.get("/status/{run_id}", response_model=BlueprintStatusResponse)
async def get_blueprint_status(run_id: str) -> BlueprintStatusResponse:
    """Check the status of a blueprint run.

    Placeholder for async execution support. Currently, all runs are
    synchronous and complete before the response is returned.
    """
    return BlueprintStatusResponse(
        run_id=run_id,
        status="not_found",
        message=(
            "Async run tracking is not yet implemented. "
            "All pipeline runs currently execute synchronously via POST /run."
        ),
    )


# ---------------------------------------------------------------------------
# Engine with content seeding
# ---------------------------------------------------------------------------

class _ContentSeededEngine(BlueprintEngine):
    """Engine subclass that pre-seeds content and metadata into the run context.

    The base engine creates a BlueprintRun with an empty output. This subclass
    overrides _build_context to inject the initial content as output and the
    analysis_type into metadata, so the analyzer node receives them.
    """

    def __init__(self, content: str, analysis_type: str) -> None:
        self._initial_content = content
        self._analysis_type = analysis_type
        self._first_node = True

    async def run(
        self, definition: BlueprintDefinition, brief: str
    ) -> BlueprintRun:
        self._first_node = True
        return await super().run(definition, brief)

    def _build_context(
        self, run: BlueprintRun, node: BlueprintNode
    ) -> NodeContext:
        """Override to seed content on the first node invocation."""
        # On the first node, the run output is empty. Seed it with content.
        if self._first_node and not run.output:
            run.output = self._initial_content
            self._first_node = False

        context = super()._build_context(run, node)
        context.metadata["analysis_type"] = self._analysis_type
        return context
