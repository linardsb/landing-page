"""QAGateNode — deterministic node that checks if unresolved issues exist."""

from __future__ import annotations

from typing import Literal

from app.ai.blueprints.engine import NodeContext, NodeResult
from app.core.logging import get_logger

logger = get_logger(__name__)


class QAGateNode:
    """Deterministic QA gate that passes or fails based on issue state.

    Reads analysis results from context.metadata and checks whether any
    critical issues remain. Returns "success" if the content passes QA,
    "failed" otherwise (which routes to the fixer via qa_fail edge).
    """

    def __init__(self, *, fail_on_warnings: bool = False) -> None:
        self._fail_on_warnings = fail_on_warnings

    @property
    def name(self) -> str:
        return "qa_gate"

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]:
        return "deterministic"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Check if content passes quality gate."""
        issues: list[dict[str, str]] = context.metadata.get("analysis_issues", [])
        score: float = context.metadata.get("analysis_score", 1.0)

        critical_issues = [i for i in issues if i.get("severity") == "critical"]
        warning_issues = [i for i in issues if i.get("severity") == "warning"]

        blocking_issues = list(critical_issues)
        if self._fail_on_warnings:
            blocking_issues.extend(warning_issues)

        logger.info(
            "qa_gate.evaluating",
            total_issues=len(issues),
            critical=len(critical_issues),
            warnings=len(warning_issues),
            score=score,
            fail_on_warnings=self._fail_on_warnings,
        )

        if blocking_issues:
            failure_messages = tuple(
                f"[{i.get('severity', 'unknown')}] {i.get('category', '')}: {i.get('message', '')}"
                for i in blocking_issues
            )

            logger.info(
                "qa_gate.failed",
                blocking_count=len(blocking_issues),
            )

            return NodeResult(
                status="failed",
                output=context.output,
                details=f"QA gate failed: {len(blocking_issues)} blocking issues",
                structured_failures=failure_messages,
            )

        logger.info(
            "qa_gate.passed",
            score=score,
            info_count=len(issues) - len(critical_issues) - len(warning_issues),
        )

        return NodeResult(
            status="success",
            output=context.output,
            details=f"QA gate passed (score: {score:.2f}, {len(issues)} non-blocking issues)",
        )
