"""FixerNode — wraps the Fixer agent as a blueprint node."""

from __future__ import annotations

from typing import Any, Literal

from app.ai.agents.fixer.schemas import FixerRequest, FixerResponse
from app.ai.agents.fixer.service import get_fixer_service
from app.ai.blueprints.engine import (
    AgentHandoff,
    NodeContext,
    NodeResult,
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class FixerNode:
    """Agentic node that applies LLM-driven fixes to content.

    Reads issues from context.qa_failures (set by the QA gate) and
    context.metadata["analysis_issues"] (set by the analyzer node).
    """

    @property
    def name(self) -> str:
        return "fixer"

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]:
        return "agentic"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Run the Fixer agent on the current output with known issues."""
        service = get_fixer_service()

        # Gather issues from upstream nodes
        issues: list[dict[str, Any]] = context.metadata.get("analysis_issues", [])
        if not issues and context.qa_failures:
            # Fallback: convert string failures to issue dicts
            issues = [
                {"severity": "warning", "category": "qa_failure", "message": f}
                for f in context.qa_failures
            ]

        logger.info(
            "fixer_node.executing",
            issue_count=len(issues),
            iteration=context.iteration,
            content_length=len(context.output),
        )

        request = FixerRequest(
            content=context.output,
            issues=issues,
            context={"brief": context.brief, "iteration": context.iteration},
        )

        response = await service.process(request)

        if not isinstance(response, FixerResponse):
            return NodeResult(
                status="failed",
                error="Fixer returned unexpected response type",
            )

        fix_summary = f"{response.fix_count} fixes applied"

        handoff = AgentHandoff(
            status="ok" if response.fix_count > 0 else "warning",
            agent_name="fixer",
            artifact=response.content,
            decisions=tuple(response.fixes_applied),
            confidence=response.confidence,
        )

        return NodeResult(
            status="success",
            output=response.content,
            details=fix_summary,
            usage=response.usage,
            handoff=handoff,
        )
