"""Blueprint nodes — reusable building blocks for agent pipelines."""
