"""AnalyzerNode — wraps the Analyzer agent as a blueprint node."""

from __future__ import annotations

from typing import Literal

from app.ai.agents.analyzer.schemas import AnalyzerRequest, AnalyzerResponse
from app.ai.agents.analyzer.service import get_analyzer_service
from app.ai.blueprints.engine import (
    AgentHandoff,
    NodeContext,
    NodeResult,
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class AnalyzerNode:
    """Agentic node that runs content through the Analyzer agent.

    Extracts issues from the response and populates structured_failures
    if any critical issues are found (triggering QA gate failure downstream).
    """

    @property
    def name(self) -> str:
        return "analyzer"

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]:
        return "agentic"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Run the Analyzer agent on the current output."""
        service = get_analyzer_service()

        analysis_type = context.metadata.get("analysis_type", "quality")

        request = AnalyzerRequest(
            content=context.output or context.brief,
            analysis_type=analysis_type,
            context={"brief": context.brief, "iteration": context.iteration},
            output_mode="structured",
        )

        logger.info(
            "analyzer_node.executing",
            analysis_type=analysis_type,
            iteration=context.iteration,
            content_length=len(request.content),
        )

        response = await service.process(request)

        if not isinstance(response, AnalyzerResponse):
            return NodeResult(
                status="failed",
                error="Analyzer returned unexpected response type",
            )

        # Build handoff summary
        issue_summary = (
            f"{len(response.issues)} issues found "
            f"({response.critical_count} critical, {response.warning_count} warnings)"
        )

        handoff = AgentHandoff(
            status="warning" if response.has_critical_issues else "ok",
            agent_name="analyzer",
            artifact=response.content,
            decisions=(
                f"analysis_type={analysis_type}",
                f"score={response.score:.2f}",
                issue_summary,
            ),
            confidence=response.confidence,
        )

        # If critical issues exist, set structured_failures so the QA gate
        # can route to the fixer
        structured_failures: tuple[str, ...] = ()
        if response.has_critical_issues:
            structured_failures = tuple(
                f"[{i.severity}] {i.category}: {i.message}"
                for i in response.issues
                if i.severity == "critical"
            )

        # Store full issues in metadata for downstream nodes
        context.metadata["analysis_issues"] = [i.to_dict() for i in response.issues]
        context.metadata["analysis_score"] = response.score
        context.metadata["analysis_summary"] = response.summary

        return NodeResult(
            status="success",
            output=context.output or context.brief,  # Pass content through
            details=issue_summary,
            usage=response.usage,
            handoff=handoff,
            structured_failures=structured_failures,
        )
