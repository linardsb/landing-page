"""RepairNode — deterministic node that applies rule-based content fixes."""

from __future__ import annotations

import re
from typing import Literal

from app.ai.blueprints.engine import NodeContext, NodeResult
from app.core.logging import get_logger

logger = get_logger(__name__)


class RepairNode:
    """Deterministic repair node that applies simple rule-based fixes.

    These are cheap, reliable transformations that don't need an LLM:
      - Strip excessive whitespace
      - Normalize line endings
      - Remove null bytes
      - Fix common encoding issues
      - Trim trailing whitespace from lines
    """

    @property
    def name(self) -> str:
        return "repair"

    @property
    def node_type(self) -> Literal["deterministic", "agentic"]:
        return "deterministic"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Apply deterministic repairs to the content."""
        content = context.output
        repairs: list[str] = []

        if not content:
            return NodeResult(
                status="success",
                output="",
                details="No content to repair",
            )

        original_length = len(content)

        # 1. Remove null bytes
        if "\x00" in content:
            content = content.replace("\x00", "")
            repairs.append("removed null bytes")

        # 2. Normalize line endings (CRLF/CR -> LF)
        if "\r\n" in content or "\r" in content:
            content = content.replace("\r\n", "\n").replace("\r", "\n")
            repairs.append("normalized line endings to LF")

        # 3. Strip trailing whitespace from each line
        lines = content.split("\n")
        stripped_lines = [line.rstrip() for line in lines]
        if lines != stripped_lines:
            content = "\n".join(stripped_lines)
            repairs.append("stripped trailing whitespace from lines")

        # 4. Collapse runs of 3+ blank lines into 2
        collapsed = re.sub(r"\n{4,}", "\n\n\n", content)
        if collapsed != content:
            content = collapsed
            repairs.append("collapsed excessive blank lines")

        # 5. Ensure trailing newline
        if content and not content.endswith("\n"):
            content += "\n"
            repairs.append("added trailing newline")

        # 6. Fix common mojibake patterns
        mojibake_fixes: dict[str, str] = {
            "\u00e2\u0080\u0099": "\u2019",  # right single quote
            "\u00e2\u0080\u009c": "\u201c",  # left double quote
            "\u00e2\u0080\u009d": "\u201d",  # right double quote
            "\u00e2\u0080\u0093": "\u2013",  # en dash
            "\u00e2\u0080\u0094": "\u2014",  # em dash
        }
        for bad, good in mojibake_fixes.items():
            if bad in content:
                content = content.replace(bad, good)
                repairs.append(f"fixed mojibake: {bad!r} -> {good!r}")

        delta = original_length - len(content)
        details = f"{len(repairs)} repairs applied" if repairs else "no repairs needed"
        if delta:
            details += f" (size delta: {delta:+d} bytes)"

        logger.info(
            "repair_node.completed",
            repairs=len(repairs),
            size_delta=delta,
        )

        return NodeResult(
            status="success",
            output=content,
            details=details,
        )
