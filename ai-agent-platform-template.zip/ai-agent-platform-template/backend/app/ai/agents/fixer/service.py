"""Fixer agent service — applies LLM-driven fixes to content based on issues."""

from __future__ import annotations

import json
import re
from typing import Any

from app.ai.agents.base.service import AgentRequest, AgentResponse, BaseAgentService
from app.ai.agents.fixer.schemas import FixerRequest, FixerResponse
from app.core.logging import get_logger

logger = get_logger(__name__)

_FIXES_APPLIED_RE = re.compile(
    r"FIXES_APPLIED:\s*(\[.*?\])", re.DOTALL
)

_SYSTEM_PROMPT = """\
You are a content fixer agent. You receive content along with a list of \
identified issues. Your job is to fix all issues and return the corrected content.

## Instructions

1. Fix every issue listed below. Apply the suggestion when one is provided.
2. Preserve the original content structure and intent — only change what is \
necessary to resolve the issues.
3. Do not introduce new problems while fixing existing ones.
4. After the fixed content, include a line:
   FIXES_APPLIED: ["description of fix 1", "description of fix 2", ...]

{skills_block}

Return the fixed content followed by the FIXES_APPLIED list."""


class FixerService(BaseAgentService):
    """Takes content + list of issues and returns fixed content.

    Pipeline:
        1. Build system prompt with fix instructions
        2. Format issues into user message alongside content
        3. Call LLM to apply fixes
        4. Parse fixed content and extract list of applied fixes
    """

    agent_name: str = "fixer"
    model_tier = "standard"
    max_tokens: int = 8192
    run_qa_default: bool = False
    sanitization_profile: str = "code_reviewer"
    _output_mode_supported: bool = False

    def build_system_prompt(self, relevant_skills: list[str], output_mode: str) -> str:
        skills_block = ""
        if relevant_skills:
            skills_block = "## Guidelines\n\n" + "\n\n".join(relevant_skills)
        return _SYSTEM_PROMPT.format(skills_block=skills_block)

    def _build_user_message(self, request: AgentRequest) -> str:
        parts: list[str] = []

        if isinstance(request, FixerRequest) and request.issues:
            issues_text = json.dumps(request.issues, indent=2, default=str)
            parts.append(f"Issues to fix:\n{issues_text}")

        parts.append(f"Content:\n\n{request.content}")

        return "\n\n".join(parts)

    def detect_relevant_skills(self, request: AgentRequest) -> list[str]:
        return []

    def _build_response(
        self,
        content: str,
        qa_passed: bool | None,
        confidence: float,
        usage: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> AgentResponse:
        fixed_content, fixes_applied = self._extract_fixes(content)

        return FixerResponse(
            content=fixed_content,
            confidence=confidence,
            qa_passed=qa_passed,
            usage=usage,
            agent_name=self.agent_name,
            fixes_applied=fixes_applied,
        )

    # --- Internal helpers ---

    def _extract_fixes(self, content: str) -> tuple[str, list[str]]:
        """Separate fixed content from the FIXES_APPLIED list."""
        match = _FIXES_APPLIED_RE.search(content)
        if not match:
            return content.strip(), []

        fixes_json = match.group(1)
        # Content is everything before the FIXES_APPLIED marker
        fixed_content = content[: match.start()].strip()

        try:
            fixes = json.loads(fixes_json)
            if isinstance(fixes, list):
                return fixed_content, [str(f) for f in fixes]
        except json.JSONDecodeError:
            logger.warning("fixer.fixes_parse_failed", raw=fixes_json[:200])

        return fixed_content, []


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_fixer_service() -> FixerService:
    """Create a new FixerService instance."""
    return FixerService()
