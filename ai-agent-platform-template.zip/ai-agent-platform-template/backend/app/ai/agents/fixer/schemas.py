"""Fixer agent request/response schemas."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.ai.agents.base.service import AgentRequest, AgentResponse


@dataclass
class FixerRequest(AgentRequest):
    """Request for the Fixer agent."""

    issues: list[dict[str, Any]] = field(default_factory=list)

    # Override base defaults
    content: str = ""
    context: dict[str, Any] | None = None
    output_mode: str = "raw"


@dataclass
class FixerResponse(AgentResponse):
    """Response from the Fixer agent."""

    fixes_applied: list[str] = field(default_factory=list)

    @property
    def fix_count(self) -> int:
        return len(self.fixes_applied)
