"""Fixer agent — applies fixes to content based on identified issues."""
