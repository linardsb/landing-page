"""
BaseAgentService — the unified pipeline all agents inherit from.

Pipeline: prompt → LLM → post-process → confidence extract → QA → response

Subclasses MUST override:
  - build_system_prompt(relevant_skills, output_mode)
  - _build_user_message(request)
  - detect_relevant_skills(request)
  - _build_response(content, qa_passed, confidence, **kw)

Optional hooks:
  - _post_process(raw_content)
  - _run_qa(output)
  - _get_model_tier(request)
  - _should_run_qa(request)
  - _process_structured(request)
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Literal

from app.ai.protocols import CompletionResponse, Message
from app.ai.registry import get_registry
from app.ai.routing import TaskTier, resolve_model
from app.core.logging import get_logger

logger = get_logger(__name__)

CONFIDENCE_INSTRUCTION = """
Rate your confidence in this output from 0.00 to 1.00.
Consider: completeness, correctness, adherence to instructions.
Embed your confidence as an invisible comment: <!-- CONFIDENCE: X.XX -->
"""

CONFIDENCE_PATTERN = re.compile(r"<!--\s*CONFIDENCE:\s*([\d.]+)\s*-->")


@dataclass
class AgentRequest:
    """Base request — extend per agent."""
    content: str
    context: dict[str, Any] | None = None
    output_mode: str = "raw"


@dataclass
class AgentResponse:
    """Base response — extend per agent."""
    content: str
    confidence: float
    qa_passed: bool | None = None
    usage: dict[str, int] | None = None
    agent_name: str = ""


class BaseAgentService(ABC):
    """Base class for all AI agents."""

    # --- Class-level config (override in subclass) ---
    agent_name: str = ""
    model_tier: TaskTier = "standard"
    max_tokens: int = 8192
    run_qa_default: bool = False
    stream_prefix: str = ""
    output_mode_default: str = "raw"
    _output_mode_supported: bool = False
    sanitization_profile: str = "default"

    # --- MUST override ---

    @abstractmethod
    def build_system_prompt(self, relevant_skills: list[str], output_mode: str) -> str:
        """Build the system prompt with injected skill content."""
        ...

    @abstractmethod
    def _build_user_message(self, request: AgentRequest) -> str:
        """Construct the user message from the request."""
        ...

    @abstractmethod
    def detect_relevant_skills(self, request: AgentRequest) -> list[str]:
        """Determine which skill files to load for this request."""
        ...

    @abstractmethod
    def _build_response(
        self,
        content: str,
        qa_passed: bool | None,
        confidence: float,
        usage: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> AgentResponse:
        """Construct agent-specific response."""
        ...

    # --- Optional hooks ---

    def _post_process(self, raw_content: str) -> str:
        """Override for custom post-processing. Default: return as-is."""
        return raw_content

    async def _run_qa(self, output: str) -> bool:
        """Override to run quality checks. Default: always passes."""
        return True

    def _get_model_tier(self, request: AgentRequest) -> TaskTier:
        """Override for dynamic tier per-request."""
        return self.model_tier

    def _should_run_qa(self, request: AgentRequest) -> bool:
        """Override for conditional QA gate."""
        return self.run_qa_default

    # --- Pipeline ---

    async def process(self, request: AgentRequest) -> AgentResponse:
        """Execute the full agent pipeline."""

        # 1. Resolve model
        tier = self._get_model_tier(request)
        model = resolve_model(tier)

        # 2. Detect and load skills
        skill_names = self.detect_relevant_skills(request)
        # TODO: Load skill files with budget awareness (see skill_loader.py)

        # 3. Build prompts
        output_mode = request.output_mode or self.output_mode_default
        system_prompt = self.build_system_prompt(skill_names, output_mode)
        system_prompt += "\n\n" + CONFIDENCE_INSTRUCTION

        user_message = self._build_user_message(request)

        messages = [
            Message(role="system", content=system_prompt),
            Message(role="user", content=user_message),
        ]

        # 4. Call LLM
        registry = get_registry()
        provider = registry.get_llm(get_settings().ai.provider)

        logger.info(
            f"{self.agent_name}.execution_started",
            model=model,
            tier=tier,
        )

        try:
            response: CompletionResponse = await provider.complete(
                messages,
                model=model,
                max_tokens=self.max_tokens,
            )
        except Exception:
            logger.exception(f"{self.agent_name}.execution_failed")
            raise

        raw_content = response.content

        # 5. Post-process
        processed = self._post_process(raw_content)

        # 6. Extract confidence
        confidence = self._extract_confidence(processed)
        processed = self._strip_confidence(processed)

        # 7. Run QA if enabled
        qa_passed: bool | None = None
        if self._should_run_qa(request):
            qa_passed = await self._run_qa(processed)

        logger.info(
            f"{self.agent_name}.execution_completed",
            confidence=confidence,
            qa_passed=qa_passed,
        )

        # 8. Build response
        return self._build_response(
            content=processed,
            qa_passed=qa_passed,
            confidence=confidence,
            usage=response.usage,
        )

    # --- Confidence helpers ---

    @staticmethod
    def _extract_confidence(content: str) -> float:
        """Extract confidence from <!-- CONFIDENCE: X.XX --> comment."""
        match = CONFIDENCE_PATTERN.search(content)
        if match:
            return max(0.0, min(1.0, float(match.group(1))))
        return 0.5  # Default if not found

    @staticmethod
    def _strip_confidence(content: str) -> str:
        """Remove confidence comment from output."""
        return CONFIDENCE_PATTERN.sub("", content).strip()


# Avoid circular import at module level
def get_settings():
    from app.core.config import get_settings as _gs
    return _gs()
