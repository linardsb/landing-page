"""Base agent service and shared agent infrastructure."""
