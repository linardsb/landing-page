"""Automatic skill extraction and loading."""
