"""
Skill loader — progressive disclosure, budget-aware skill loading.

Skills are markdown files with front matter (token_cost, priority).
Loaded on-demand based on agent request context.

Override priority:
  1. Prompt Store (DB) — versioned templates, A/B variants
  2. In-Memory Override — set programmatically
  3. Disk SKILL.md — default fallback
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from app.core.logging import get_logger

logger = get_logger(__name__)

FRONT_MATTER_PATTERN = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
SECTION_PATTERN = re.compile(r"^## (\w+)\n(.*?)(?=^## |\Z)", re.MULTILINE | re.DOTALL)


@dataclass(frozen=True)
class SkillMeta:
    """Metadata parsed from skill file front matter."""
    token_cost: int = 500
    priority: int = 2  # 1=critical (always), 2=standard, 3=supplementary
    name: str = ""


@dataclass
class TokenBudget:
    """Controls context budget for skill loading."""
    max_tokens: int
    used: int = 0

    def can_fit(self, cost: int) -> bool:
        return (self.used + cost) <= self.max_tokens

    def consume(self, cost: int) -> None:
        self.used += cost

    @property
    def remaining(self) -> int:
        return max(0, self.max_tokens - self.used)


def parse_front_matter(content: str) -> tuple[SkillMeta, str]:
    """Extract front matter metadata and return (meta, body)."""
    match = FRONT_MATTER_PATTERN.match(content)
    if not match:
        return SkillMeta(), content

    raw_meta = match.group(1)
    body = content[match.end():]

    # Parse YAML-like key: value pairs
    meta_dict: dict[str, str] = {}
    for line in raw_meta.strip().split("\n"):
        if ":" in line:
            key, value = line.split(":", 1)
            meta_dict[key.strip()] = value.strip()

    return SkillMeta(
        token_cost=int(meta_dict.get("token_cost", "500")),
        priority=int(meta_dict.get("priority", "2")),
        name=meta_dict.get("name", ""),
    ), body


def extract_skill_for_mode(content: str, output_mode: str) -> str:
    """Extract the section matching the output mode (e.g., 'raw', 'structured')."""
    sections = dict(SECTION_PATTERN.findall(content))
    if output_mode in sections:
        return sections[output_mode].strip()
    return content  # Fallback: return full content


def load_skills(
    skill_dir: Path,
    skill_names: list[str],
    budget: TokenBudget,
    output_mode: str = "raw",
) -> str:
    """Load skill files with budget-aware, priority-sorted selection.

    1. Parse front matter for each skill
    2. Sort by priority (1 first)
    3. Priority 1 (critical): always load
    4. Priority 2-3: load while within budget
    5. Extract output-mode section
    6. Return concatenated skill text
    """
    skills: list[tuple[SkillMeta, str]] = []

    for name in skill_names:
        path = skill_dir / f"{name}.md"
        if not path.exists():
            logger.warning("skills.file_not_found", skill=name)
            continue

        content = path.read_text()
        meta, body = parse_front_matter(content)
        skills.append((meta, body))

    # Sort by priority (critical first)
    skills.sort(key=lambda s: s[0].priority)

    loaded_parts: list[str] = []

    for meta, body in skills:
        if meta.priority == 1:
            # Critical skills always load
            section = extract_skill_for_mode(body, output_mode)
            loaded_parts.append(section)
            budget.consume(meta.token_cost)
        elif budget.can_fit(meta.token_cost):
            section = extract_skill_for_mode(body, output_mode)
            loaded_parts.append(section)
            budget.consume(meta.token_cost)
        else:
            logger.info(
                "skills.budget_exceeded",
                skill=meta.name,
                cost=meta.token_cost,
                remaining=budget.remaining,
            )

    return "\n\n".join(loaded_parts)
