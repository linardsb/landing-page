---
token_cost: 400
priority: 2
name: quality_checks
---

# Quality Check Criteria

## Structure
- Verify logical flow and organization of content sections.
- Check for missing headers, incomplete sections, or orphaned content.
- Ensure consistent formatting throughout.

## Clarity
- Flag ambiguous language, jargon without definitions, and unclear references.
- Check for overly complex sentences (>40 words) and suggest simplification.
- Verify that key terms are used consistently.

## Grammar & Style
- Identify grammatical errors, typos, and punctuation issues.
- Check for passive voice overuse (>30% of sentences).
- Flag inconsistent capitalization, numbering, or list formatting.

## Completeness
- Verify all referenced items (figures, tables, links) actually exist.
- Check for TODO/FIXME/HACK markers left in content.
- Ensure introductions have conclusions and vice versa.

## Encoding & Formatting
- Detect encoding issues (mojibake, invalid UTF-8 sequences).
- Flag excessive whitespace, trailing spaces, or inconsistent line endings.
- Check for broken markdown/HTML if applicable.
