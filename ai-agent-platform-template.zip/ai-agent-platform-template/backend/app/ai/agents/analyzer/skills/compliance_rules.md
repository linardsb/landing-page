---
token_cost: 500
priority: 2
name: compliance_rules
---

# Compliance Analysis Rules

## Data Privacy
- Check for personally identifiable information (PII) exposure: names, emails,
  phone numbers, addresses, SSNs, credit card numbers.
- Verify data handling descriptions comply with GDPR/CCPA principles.
- Flag any data retention statements that lack specific timeframes.

## Accessibility
- Ensure content provides alternative text descriptions for visual elements.
- Check that color is not the sole means of conveying information.
- Verify readability level is appropriate for the target audience.
- Flag content that relies solely on sensory characteristics (shape, size, color).

## Legal & Regulatory
- Check for required disclaimers and disclosures.
- Flag unsubstantiated claims (superlatives without evidence).
- Verify copyright attributions are present where needed.
- Check for terms that may constitute unauthorized legal/medical/financial advice.

## Inclusive Language
- Flag exclusionary or biased language.
- Check for culturally insensitive references.
- Verify gender-neutral language is used where appropriate.
