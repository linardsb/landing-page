"""Synthetic test cases for the Analyzer agent.

10 cases across three dimensions:
  - task_complexity: simple, moderate, complex
  - input_quality: clean, messy, minimal
  - analysis_type: quality, compliance, performance
"""

from __future__ import annotations

from app.ai.agents.evals.framework import SyntheticTestCase, TestDimension

# ---------------------------------------------------------------------------
# Dimensions
# ---------------------------------------------------------------------------

ANALYZER_DIMENSIONS: tuple[TestDimension, ...] = (
    TestDimension(name="task_complexity", values=("simple", "moderate", "complex")),
    TestDimension(name="input_quality", values=("clean", "messy", "minimal")),
    TestDimension(name="analysis_type", values=("quality", "compliance", "performance")),
)

# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

ANALYZER_CASES: list[SyntheticTestCase] = [
    # --- Simple / Clean ---
    SyntheticTestCase(
        case_id="analyzer-001",
        agent_name="analyzer",
        brief="Analyze a well-written paragraph for quality issues",
        dimensions={"task_complexity": "simple", "input_quality": "clean", "analysis_type": "quality"},
        expected_behavior=(
            "Should return 0-1 informational issues at most. Score should be >= 0.9. "
            "No false-positive critical or warning issues."
        ),
        metadata={"content": (
            "The quick brown fox jumps over the lazy dog. This sentence contains "
            "every letter of the English alphabet and has been used as a typing "
            "exercise since the late 19th century."
        )},
    ),

    # --- Simple / Messy ---
    SyntheticTestCase(
        case_id="analyzer-002",
        agent_name="analyzer",
        brief="Analyze text with obvious typos and grammar errors",
        dimensions={"task_complexity": "simple", "input_quality": "messy", "analysis_type": "quality"},
        expected_behavior=(
            "Should detect at least 2 grammar/typo issues. Severity should be 'warning' "
            "not 'critical'. Suggestions should include corrections."
        ),
        metadata={"content": (
            "Teh companey has recieved many complants about there product. "
            "Its important that we adress these issues imediately."
        )},
    ),

    # --- Moderate / Clean / Compliance ---
    SyntheticTestCase(
        case_id="analyzer-003",
        agent_name="analyzer",
        brief="Check privacy policy text for compliance issues",
        dimensions={"task_complexity": "moderate", "input_quality": "clean", "analysis_type": "compliance"},
        expected_behavior=(
            "Should identify the missing data retention timeframe as a warning. "
            "Should flag the vague 'third parties' reference. Score 0.5-0.8."
        ),
        metadata={"content": (
            "We collect your personal information including name, email, and browsing "
            "history. This data may be shared with third parties for marketing purposes. "
            "We retain your data for as long as necessary."
        )},
    ),

    # --- Moderate / Messy / Quality ---
    SyntheticTestCase(
        case_id="analyzer-004",
        agent_name="analyzer",
        brief="Analyze a document with mixed formatting and incomplete sections",
        dimensions={"task_complexity": "moderate", "input_quality": "messy", "analysis_type": "quality"},
        expected_behavior=(
            "Should detect: missing conclusion, inconsistent heading levels, "
            "TODO marker. At least 3 issues total. Score 0.4-0.7."
        ),
        metadata={"content": (
            "# Introduction\n\nThis document describes the architecture.\n\n"
            "### Design Decisions\n\nWe chose PostgreSQL because...\n\n"
            "## Implementation\n\nTODO: fill in implementation details\n\n"
            "## Testing\n\nUnit tests cover 80% of the codebase."
        )},
    ),

    # --- Simple / Minimal ---
    SyntheticTestCase(
        case_id="analyzer-005",
        agent_name="analyzer",
        brief="Analyze extremely short content",
        dimensions={"task_complexity": "simple", "input_quality": "minimal", "analysis_type": "quality"},
        expected_behavior=(
            "Should note the content is too brief for thorough analysis. "
            "May flag lack of context as informational. Score 0.5-0.8."
        ),
        metadata={"content": "OK"},
    ),

    # --- Complex / Clean / Performance ---
    SyntheticTestCase(
        case_id="analyzer-006",
        agent_name="analyzer",
        brief="Analyze a SQL query for performance issues",
        dimensions={"task_complexity": "complex", "input_quality": "clean", "analysis_type": "performance"},
        expected_behavior=(
            "Should identify: missing index hint for large table scan, "
            "SELECT * anti-pattern, N+1 potential in subquery. "
            "At least 2 issues, score 0.3-0.6."
        ),
        metadata={"content": (
            "SELECT * FROM orders o\n"
            "JOIN customers c ON o.customer_id = c.id\n"
            "WHERE o.created_at > '2024-01-01'\n"
            "AND c.country IN (SELECT country FROM regions WHERE active = true)\n"
            "ORDER BY o.total DESC;"
        )},
    ),

    # --- Complex / Messy / Compliance ---
    SyntheticTestCase(
        case_id="analyzer-007",
        agent_name="analyzer",
        brief="Analyze user-facing text with PII and accessibility issues",
        dimensions={"task_complexity": "complex", "input_quality": "messy", "analysis_type": "compliance"},
        expected_behavior=(
            "Should detect: exposed email address as PII, phone number as PII, "
            "color-only status indicator as accessibility issue. "
            "At least 2 critical issues. Score < 0.4."
        ),
        metadata={"content": (
            "Contact John Smith at john.smith@example.com or call 555-0123.\n"
            "Account status is indicated by the colored dot next to your name:\n"
            "green = active, red = suspended, yellow = pending review."
        )},
    ),

    # --- Moderate / Clean / Performance ---
    SyntheticTestCase(
        case_id="analyzer-008",
        agent_name="analyzer",
        brief="Analyze API response payload for performance concerns",
        dimensions={"task_complexity": "moderate", "input_quality": "clean", "analysis_type": "performance"},
        expected_behavior=(
            "Should identify: oversized response with nested redundant data, "
            "lack of pagination. At least 1 warning. Score 0.5-0.8."
        ),
        metadata={"content": (
            '{"users": [{"id": 1, "name": "Alice", "orders": [{"id": 100, '
            '"items": [{"product": {"id": 1, "name": "Widget", "description": '
            '"A very long description...", "manufacturer": {"id": 1, "name": '
            '"Acme", "address": "123 Main St"}}}]}]}]}'
        )},
    ),

    # --- Complex / Minimal / Quality ---
    SyntheticTestCase(
        case_id="analyzer-009",
        agent_name="analyzer",
        brief="Analyze a code snippet with subtle logic error",
        dimensions={"task_complexity": "complex", "input_quality": "minimal", "analysis_type": "quality"},
        expected_behavior=(
            "Should detect the off-by-one error in the loop bounds. "
            "Severity should be 'critical' or 'warning'. Score 0.4-0.7."
        ),
        metadata={"content": (
            "def find_max(items):\n"
            "    max_val = items[0]\n"
            "    for i in range(1, len(items) - 1):\n"
            "        if items[i] > max_val:\n"
            "            max_val = items[i]\n"
            "    return max_val"
        )},
    ),

    # --- Simple / Clean / Compliance ---
    SyntheticTestCase(
        case_id="analyzer-010",
        agent_name="analyzer",
        brief="Analyze a marketing claim for compliance",
        dimensions={"task_complexity": "simple", "input_quality": "clean", "analysis_type": "compliance"},
        expected_behavior=(
            "Should flag 'best in the world' as an unsubstantiated superlative. "
            "Should flag '100% guaranteed' as potentially misleading. "
            "At least 1 warning. Score 0.5-0.8."
        ),
        metadata={"content": (
            "Our product is the best in the world. Results are 100% guaranteed "
            "or your money back. Trusted by millions of satisfied customers."
        )},
    ),
]
