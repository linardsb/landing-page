"""LLM judge for the Analyzer agent — 5-criteria binary evaluation."""

from __future__ import annotations

import json
import re

from app.ai.agents.evals.framework import (
    CriterionResult,
    JudgeCriteria,
    JudgeInput,
    JudgeVerdict,
)
from app.core.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Criteria
# ---------------------------------------------------------------------------

ANALYZER_CRITERIA: list[JudgeCriteria] = [
    JudgeCriteria(
        name="issue_detection_accuracy",
        description=(
            "Did the agent correctly identify real issues present in the content? "
            "Issues must correspond to actual problems, not hallucinated ones."
        ),
        weight=1.0,
    ),
    JudgeCriteria(
        name="severity_calibration",
        description=(
            "Are issue severities correctly calibrated? Critical issues should "
            "genuinely block release. Warnings should be real but non-blocking. "
            "Info items should be minor improvements."
        ),
        weight=1.0,
    ),
    JudgeCriteria(
        name="actionable_suggestions",
        description=(
            "Does each issue include a concrete, actionable suggestion for how "
            "to fix it? Vague advice like 'improve this' does not count."
        ),
        weight=1.0,
    ),
    JudgeCriteria(
        name="no_false_positives",
        description=(
            "Are there any false positive issues — problems reported that do not "
            "actually exist in the content? A single false critical is a failure."
        ),
        weight=1.0,
    ),
    JudgeCriteria(
        name="completeness",
        description=(
            "Did the agent find all the issues that a skilled human reviewer "
            "would find? Missing an obvious critical issue is a failure."
        ),
        weight=1.0,
    ),
]

# ---------------------------------------------------------------------------
# Judge
# ---------------------------------------------------------------------------

_JUDGE_PROMPT = """\
You are an evaluation judge for an AI content analysis agent. Your job is to \
assess whether the agent's analysis output meets quality standards.

## Test Case
Brief: {brief}

## Agent Output
{output}

## Expected Behavior
{expected_behavior}

## Evaluation Criteria
For each criterion, respond with PASS or FAIL and a brief reasoning.

1. **issue_detection_accuracy**: Did the agent find real issues that actually \
exist in the content?
2. **severity_calibration**: Are severities correctly assigned (critical = \
release-blocking, warning = should-fix, info = nice-to-have)?
3. **actionable_suggestions**: Does each issue have a concrete, specific \
suggestion for fixing it?
4. **no_false_positives**: Are there any issues reported that don't actually \
exist in the content? (FAIL if any false positives found)
5. **completeness**: Did the agent find all issues a skilled human would catch? \
(FAIL if an obvious issue was missed)

## Response Format
Return a JSON object:
```json
{{
  "issue_detection_accuracy": {{"pass": true, "reasoning": "..."}},
  "severity_calibration": {{"pass": true, "reasoning": "..."}},
  "actionable_suggestions": {{"pass": true, "reasoning": "..."}},
  "no_false_positives": {{"pass": true, "reasoning": "..."}},
  "completeness": {{"pass": true, "reasoning": "..."}}
}}
```
Return ONLY the JSON."""

_JSON_BLOCK_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


class AnalyzerJudge:
    """Binary pass/fail LLM judge for Analyzer agent output.

    Evaluates 5 criteria. Overall pass requires all criteria to pass.
    """

    agent_name: str = "analyzer"
    criteria: list[JudgeCriteria] = ANALYZER_CRITERIA

    def build_prompt(self, judge_input: JudgeInput) -> str:
        """Build the evaluation prompt for the judge LLM."""
        expected = str(judge_input.metadata.get("expected_behavior", ""))
        return _JUDGE_PROMPT.format(
            brief=judge_input.brief,
            output=judge_input.output,
            expected_behavior=expected,
        )

    def parse_response(self, raw: str, judge_input: JudgeInput) -> JudgeVerdict:
        """Parse the judge LLM's response into a structured verdict.

        Falls back gracefully if the response is not valid JSON.
        """
        # Strip markdown fences if present
        content = raw.strip()
        fence_match = _JSON_BLOCK_RE.search(content)
        if fence_match:
            content = fence_match.group(1).strip()

        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            logger.warning(
                "analyzer_judge.parse_failed",
                trace_id=judge_input.trace_id,
                raw_preview=raw[:200],
            )
            return JudgeVerdict(
                trace_id=judge_input.trace_id,
                agent="analyzer",
                overall_pass=False,
                criteria_results=[],
                error=f"Failed to parse judge response: {raw[:200]}",
            )

        criteria_results: list[CriterionResult] = []
        for criterion in self.criteria:
            entry = data.get(criterion.name, {})
            passed = bool(entry.get("pass", False))
            reasoning = str(entry.get("reasoning", "No reasoning provided"))
            criteria_results.append(CriterionResult(
                name=criterion.name,
                passed=passed,
                reasoning=reasoning,
            ))

        overall_pass = all(cr.passed for cr in criteria_results)

        return JudgeVerdict(
            trace_id=judge_input.trace_id,
            agent="analyzer",
            overall_pass=overall_pass,
            criteria_results=criteria_results,
        )
