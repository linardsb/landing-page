"""Analyzer agent evaluation suite — synthetic test cases and LLM judges."""
