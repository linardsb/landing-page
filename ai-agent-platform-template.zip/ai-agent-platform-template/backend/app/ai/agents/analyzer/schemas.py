"""Analyzer agent request/response schemas."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from app.ai.agents.base.service import AgentRequest, AgentResponse


# ---------------------------------------------------------------------------
# Issue model
# ---------------------------------------------------------------------------

@dataclass
class AnalysisIssue:
    """A single issue found during content analysis."""

    severity: Literal["critical", "warning", "info"]
    category: str
    message: str
    suggestion: str | None = None
    location: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "severity": self.severity,
            "category": self.category,
            "message": self.message,
            "suggestion": self.suggestion,
            "location": self.location,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnalysisIssue:
        return cls(
            severity=data.get("severity", "info"),
            category=data.get("category", "general"),
            message=data.get("message", ""),
            suggestion=data.get("suggestion"),
            location=data.get("location"),
        )


# ---------------------------------------------------------------------------
# Request / Response
# ---------------------------------------------------------------------------

AnalysisType = Literal["quality", "compliance", "performance"]


@dataclass
class AnalyzerRequest(AgentRequest):
    """Request for the Analyzer agent."""

    analysis_type: AnalysisType = "quality"

    # Override base defaults
    content: str = ""
    context: dict[str, Any] | None = None
    output_mode: str = "structured"


@dataclass
class AnalyzerResponse(AgentResponse):
    """Response from the Analyzer agent with structured issue data."""

    issues: list[AnalysisIssue] = field(default_factory=list)
    summary: str = ""
    score: float = 1.0  # 0.0 = worst, 1.0 = perfect

    @property
    def critical_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "critical")

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "warning")

    @property
    def has_critical_issues(self) -> bool:
        return self.critical_count > 0
