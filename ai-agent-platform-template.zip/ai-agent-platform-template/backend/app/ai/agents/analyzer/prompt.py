"""Analyzer agent prompt construction and skill routing."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.ai.agents.analyzer.schemas import AnalyzerRequest


# ---------------------------------------------------------------------------
# Skill mapping
# ---------------------------------------------------------------------------

_ANALYSIS_SKILL_MAP: dict[str, list[str]] = {
    "quality": ["quality_checks", "best_practices"],
    "compliance": ["compliance_rules", "regulatory"],
    "performance": ["performance_metrics", "optimization"],
}


def detect_relevant_skills(request: AnalyzerRequest) -> list[str]:
    """Map analysis_type to the skill files this request needs."""
    base_skills = ["SKILL"]  # Always load the root skill
    type_skills = _ANALYSIS_SKILL_MAP.get(request.analysis_type, [])
    return base_skills + type_skills


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """\
You are a content analysis agent. Your job is to examine the provided content \
and identify issues related to {analysis_focus}.

{skills_block}

## Instructions

1. Analyze the content thoroughly for issues.
2. Classify each issue by severity: "critical" (blocks release), "warning" \
(should fix), or "info" (nice to have).
3. Assign a category to each issue (e.g., "grammar", "structure", "security", \
"accessibility", "encoding", "formatting").
4. Provide an actionable suggestion for every issue when possible.
5. Include the location in the content where the issue occurs (line number, \
section name, or character offset) when identifiable.
6. Calculate an overall quality score from 0.0 (worst) to 1.0 (perfect).

## Output format

{output_format}

Be precise, thorough, and avoid false positives. Only report genuine issues."""

_STRUCTURED_FORMAT = """\
Return a JSON object with this exact structure:
```json
{
  "issues": [
    {
      "severity": "critical" | "warning" | "info",
      "category": "string",
      "message": "string",
      "suggestion": "string or null",
      "location": "string or null"
    }
  ],
  "summary": "Brief 1-2 sentence summary of findings",
  "score": 0.85
}
```
Return ONLY the JSON — no markdown fences, no commentary."""

_RAW_FORMAT = """\
Return a structured analysis report with sections for Critical Issues, \
Warnings, and Informational notes. End with an overall score (0.0-1.0)."""

_ANALYSIS_FOCUS: dict[str, str] = {
    "quality": "content quality, grammar, structure, clarity, and best practices",
    "compliance": "regulatory compliance, policy adherence, and legal requirements",
    "performance": "performance bottlenecks, resource usage, and optimization opportunities",
}


def build_system_prompt(
    relevant_skills: list[str],
    output_mode: str,
    analysis_type: str = "quality",
) -> str:
    """Build the full system prompt with injected skills and output format.

    Args:
        relevant_skills: Loaded skill text blocks to inject.
        output_mode: "structured" for JSON output, "raw" for freeform.
        analysis_type: The type of analysis being performed.

    Returns:
        Complete system prompt string.
    """
    skills_block = ""
    if relevant_skills:
        skills_block = "## Reference Guidelines\n\n" + "\n\n".join(relevant_skills)

    output_format = _STRUCTURED_FORMAT if output_mode == "structured" else _RAW_FORMAT
    analysis_focus = _ANALYSIS_FOCUS.get(analysis_type, _ANALYSIS_FOCUS["quality"])

    return _SYSTEM_PROMPT.format(
        analysis_focus=analysis_focus,
        skills_block=skills_block,
        output_format=output_format,
    )
