"""Analyzer agent — content quality, compliance, and performance analysis."""
