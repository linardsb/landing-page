"""Analyzer agent service — content quality analysis pipeline."""

from __future__ import annotations

import json
from typing import Any

from app.ai.agents.base.service import AgentRequest, AgentResponse, BaseAgentService
from app.ai.agents.analyzer.prompt import (
    build_system_prompt,
    detect_relevant_skills,
)
from app.ai.agents.analyzer.schemas import (
    AnalysisIssue,
    AnalyzerRequest,
    AnalyzerResponse,
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class AnalyzerService(BaseAgentService):
    """Analyzes content for quality, compliance, or performance issues.

    Pipeline:
        1. Detect relevant skills based on analysis_type
        2. Build system prompt with skill injection + output format
        3. Call LLM with content as user message
        4. Post-process: parse structured JSON from LLM output
        5. Build AnalyzerResponse with issues, summary, score
    """

    agent_name: str = "analyzer"
    model_tier = "standard"
    max_tokens: int = 4096
    run_qa_default: bool = False
    sanitization_profile: str = "code_reviewer"
    _output_mode_supported: bool = True
    output_mode_default: str = "structured"

    # --- Required overrides ---

    def build_system_prompt(self, relevant_skills: list[str], output_mode: str) -> str:
        """Build system prompt with skills and output format."""
        analysis_type = getattr(self, "_current_analysis_type", "quality")
        return build_system_prompt(relevant_skills, output_mode, analysis_type)

    def _build_user_message(self, request: AgentRequest) -> str:
        """Construct user message from the analyzer request."""
        parts: list[str] = []

        if isinstance(request, AnalyzerRequest):
            parts.append(f"Analysis type: {request.analysis_type}")

        if request.context:
            context_str = json.dumps(request.context, indent=2, default=str)
            parts.append(f"Context:\n{context_str}")

        parts.append(f"Content to analyze:\n\n{request.content}")

        return "\n\n".join(parts)

    def detect_relevant_skills(self, request: AgentRequest) -> list[str]:
        """Route to analysis-type-specific skills."""
        if isinstance(request, AnalyzerRequest):
            # Store for prompt builder
            self._current_analysis_type = request.analysis_type
            return detect_relevant_skills(request)
        return ["SKILL"]

    def _build_response(
        self,
        content: str,
        qa_passed: bool | None,
        confidence: float,
        usage: dict[str, int] | None = None,
        **kwargs: Any,
    ) -> AgentResponse:
        """Parse LLM output into structured AnalyzerResponse."""
        issues, summary, score = self._parse_analysis_output(content)

        return AnalyzerResponse(
            content=content,
            confidence=confidence,
            qa_passed=qa_passed,
            usage=usage,
            agent_name=self.agent_name,
            issues=issues,
            summary=summary,
            score=score,
        )

    # --- Optional hooks ---

    def _post_process(self, raw_content: str) -> str:
        """Strip markdown fences if the LLM wraps JSON in them."""
        content = raw_content.strip()

        # Remove ```json ... ``` wrapping
        if content.startswith("```"):
            lines = content.split("\n")
            # Drop first line (```json) and last line (```)
            if lines[-1].strip() == "```":
                lines = lines[1:-1]
            elif lines[0].startswith("```"):
                lines = lines[1:]
            content = "\n".join(lines)

        return content

    # --- Internal helpers ---

    def _parse_analysis_output(
        self,
        content: str,
    ) -> tuple[list[AnalysisIssue], str, float]:
        """Parse JSON output from LLM into structured data.

        Returns:
            Tuple of (issues, summary, score). Falls back gracefully on
            parse errors.
        """
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            logger.warning(
                "analyzer.json_parse_failed",
                content_preview=content[:200],
            )
            return (
                [AnalysisIssue(
                    severity="info",
                    category="parse_error",
                    message="LLM returned non-JSON output; raw content preserved.",
                )],
                "Analysis completed but output was not parseable as JSON.",
                0.5,
            )

        # Extract issues
        raw_issues = data.get("issues", [])
        issues = [AnalysisIssue.from_dict(i) for i in raw_issues if isinstance(i, dict)]

        summary = str(data.get("summary", "Analysis complete."))
        score = float(data.get("score", 0.5))
        score = max(0.0, min(1.0, score))

        return issues, summary, score


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_analyzer_service() -> AnalyzerService:
    """Create a new AnalyzerService instance."""
    return AnalyzerService()
