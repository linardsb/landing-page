"""Agent evaluation framework: judges, calibration, and regression tracking."""
