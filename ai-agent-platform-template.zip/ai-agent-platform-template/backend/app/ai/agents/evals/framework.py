"""
Eval Framework — synthetic test cases, binary LLM judges, calibration, regression gates.

Architecture:
  synthetic_data → runner → traces.jsonl → judge_runner → verdicts.jsonl
    → calibration (TPR/TNR) → regression gate (3pp tolerance)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol


# ---------------------------------------------------------------------------
# Test dimensions (per-agent failure-prone axes)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TestDimension:
    """Defines a failure-prone axis for an agent."""
    name: str
    values: tuple[str, ...]  # e.g., ("simple", "moderate", "complex")


@dataclass
class SyntheticTestCase:
    """A single test case for an agent."""
    case_id: str
    agent_name: str
    brief: str
    dimensions: dict[str, str]  # dimension_name → value
    expected_behavior: str
    metadata: dict[str, object] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Judge protocol
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class JudgeCriteria:
    name: str
    description: str
    weight: float = 1.0


@dataclass
class JudgeInput:
    trace_id: str
    agent_name: str
    brief: str
    output: str
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass
class CriterionResult:
    name: str
    passed: bool
    reasoning: str


@dataclass
class JudgeVerdict:
    trace_id: str
    agent: str
    overall_pass: bool
    criteria_results: list[CriterionResult]
    error: str | None = None


class Judge(Protocol):
    """Binary pass/fail LLM judge for agent output."""

    agent_name: str
    criteria: list[JudgeCriteria]

    def build_prompt(self, judge_input: JudgeInput) -> str:
        """Build the judge evaluation prompt."""
        ...

    def parse_response(self, raw: str, judge_input: JudgeInput) -> JudgeVerdict:
        """Parse LLM response into structured verdict."""
        ...


# ---------------------------------------------------------------------------
# Regression gate
# ---------------------------------------------------------------------------

DEFAULT_REGRESSION_TOLERANCE = 0.03  # 3 percentage points


def check_regression(
    agent: str,
    current_pass_rate: float,
    baseline_pass_rate: float,
    tolerance: float = DEFAULT_REGRESSION_TOLERANCE,
) -> bool:
    """Returns True if no regression detected.

    Fails if current_pass_rate < baseline - tolerance.
    """
    return current_pass_rate >= (baseline_pass_rate - tolerance)


# ---------------------------------------------------------------------------
# Golden tests (deterministic CI, no LLM)
# ---------------------------------------------------------------------------

@dataclass
class GoldenCase:
    """Deterministic test case — validates structure, not LLM quality."""
    case_id: str
    agent_name: str
    input_data: dict[str, object]
    expected_schema: dict[str, object]  # JSON Schema for output validation
    expected_fields: list[str]          # Required fields in output
    max_output_size: int = 100_000      # 100KB


# ---------------------------------------------------------------------------
# Production sampler
# ---------------------------------------------------------------------------

@dataclass
class ProductionSample:
    """Captures a successful production run for offline evaluation."""
    trace_id: str
    agent_name: str
    brief: str
    output: str
    metadata: dict[str, object]
    timestamp: str


class ProductionSampler:
    """Probabilistically samples successful runs for offline LLM judging.

    Flow:
      1. Successful runs enqueued to Redis at configured sample rate
      2. Background worker processes queue with LLM judges
      3. Verdicts appended to production_verdicts.jsonl
      4. refresh_analysis() merges synthetic + production verdicts
      5. failure_warnings reads merged analysis → agents learn
    """

    def __init__(self, sample_rate: float = 0.0) -> None:
        self.sample_rate = sample_rate  # 0.0 = disabled

    def should_sample(self) -> bool:
        import random
        return random.random() < self.sample_rate

    async def enqueue(self, sample: ProductionSample) -> None:
        """Push to Redis queue for async processing."""
        # Implementation: LPUSH to Redis list
        ...
