"""AI agents: base service, evaluations, and skill extraction."""
