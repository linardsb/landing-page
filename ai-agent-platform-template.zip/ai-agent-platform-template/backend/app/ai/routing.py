"""
Model routing — tier-based resolution with fallback chains.

TaskTier → concrete model ID → optional fallback chain.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Literal

from app.ai.protocols import CompletionResponse, Message
from app.ai.registry import ProviderRegistry, get_registry
from app.core.config import get_settings
from app.core.logging import get_logger

logger = get_logger(__name__)

TaskTier = Literal["complex", "standard", "lightweight"]

# Retryable HTTP status codes
RETRYABLE_STATUSES = {408, 429, 500, 502, 503, 504}


# ---------------------------------------------------------------------------
# Tier-based resolution
# ---------------------------------------------------------------------------

def resolve_model(tier: TaskTier) -> str:
    """Map tier to concrete model ID from config."""
    settings = get_settings()
    mapping = {
        "complex": settings.ai.complex_model,
        "standard": settings.ai.standard_model,
        "lightweight": settings.ai.lightweight_model,
    }
    return mapping.get(tier, settings.ai.default_model)


# ---------------------------------------------------------------------------
# Fallback chains
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FallbackEntry:
    provider: str
    model: str


@dataclass(frozen=True)
class FallbackChain:
    tier: TaskTier
    entries: tuple[FallbackEntry, ...]
    primary: FallbackEntry
    has_fallbacks: bool


@dataclass
class FallbackEvent:
    tier: TaskTier
    failed_model: str
    error_type: str
    next_model: str | None
    elapsed_ms: float


def parse_fallback_chains(raw_config: str) -> dict[TaskTier, FallbackChain]:
    """Parse config JSON into FallbackChain objects.

    Config format: {"complex": ["openai:gpt-4o", "anthropic:claude-sonnet"]}
    """
    if not raw_config:
        return {}

    parsed: dict[TaskTier, FallbackChain] = {}
    data = json.loads(raw_config)

    for tier, entries_raw in data.items():
        entries = []
        for entry_str in entries_raw:
            provider, model = entry_str.split(":", 1)
            entries.append(FallbackEntry(provider=provider, model=model))

        if entries:
            parsed[tier] = FallbackChain(
                tier=tier,
                entries=tuple(entries),
                primary=entries[0],
                has_fallbacks=len(entries) > 1,
            )

    return parsed


def _is_retryable(error: Exception) -> bool:
    """Determine if an error should trigger fallback."""
    error_str = str(error).lower()
    return any(
        keyword in error_str
        for keyword in ("timeout", "rate limit", "429", "500", "502", "503", "504", "circuit")
    )


async def call_with_fallback(
    chain: FallbackChain,
    registry: ProviderRegistry,
    messages: list[Message],
    max_tokens: int,
) -> CompletionResponse:
    """Try primary model, fall back on retryable errors."""
    last_error: Exception | None = None

    for i, entry in enumerate(chain.entries):
        try:
            provider = registry.get_llm(entry.provider)
            return await provider.complete(
                messages,
                model=entry.model,
                max_tokens=max_tokens,
            )
        except Exception as exc:
            last_error = exc
            if not _is_retryable(exc) or i == len(chain.entries) - 1:
                raise

            logger.warning(
                "routing.fallback_triggered",
                failed_model=f"{entry.provider}:{entry.model}",
                error=str(exc),
                next_model=f"{chain.entries[i + 1].provider}:{chain.entries[i + 1].model}",
            )

    raise last_error  # type: ignore[misc]
