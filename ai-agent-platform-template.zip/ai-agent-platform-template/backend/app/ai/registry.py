"""
Provider Registry — factory-based, multi-provider LLM access with circuit breakers.

Stores provider *classes* (not instances). Creates new instances on demand
so each caller gets fresh config. Wraps LLM providers with circuit breaker.
"""

from __future__ import annotations

import asyncio
import time
from functools import lru_cache
from typing import Any

from app.ai.protocols import CompletionResponse, LLMProvider, EmbeddingProvider, Message, RerankerProvider
from app.core.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

class CircuitBreaker:
    """Simple circuit breaker: open after N failures, reset after timeout."""

    def __init__(self, failure_threshold: int = 5, reset_timeout: float = 60.0) -> None:
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self._failure_count = 0
        self._last_failure_time: float = 0.0
        self._is_open = False

    @property
    def is_open(self) -> bool:
        if self._is_open and (time.monotonic() - self._last_failure_time) > self.reset_timeout:
            self._is_open = False
            self._failure_count = 0
        return self._is_open

    def record_failure(self) -> None:
        self._failure_count += 1
        self._last_failure_time = time.monotonic()
        if self._failure_count >= self.failure_threshold:
            self._is_open = True
            logger.warning("circuit_breaker.opened", failures=self._failure_count)

    def record_success(self) -> None:
        self._failure_count = 0
        self._is_open = False


class _ResilientLLMProvider:
    """Wraps an LLMProvider with circuit breaker protection."""

    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider
        self._breaker = CircuitBreaker()

    async def complete(self, messages: list[Message], **kwargs: Any) -> CompletionResponse:
        if self._breaker.is_open:
            raise RuntimeError("Circuit breaker is open — provider temporarily unavailable")
        try:
            result = await self._provider.complete(messages, **kwargs)
            self._breaker.record_success()
            return result
        except Exception:
            self._breaker.record_failure()
            raise

    async def stream(self, messages: list[Message], **kwargs: Any):
        if self._breaker.is_open:
            raise RuntimeError("Circuit breaker is open")
        try:
            async for chunk in self._provider.stream(messages, **kwargs):
                yield chunk
            self._breaker.record_success()
        except Exception:
            self._breaker.record_failure()
            raise


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class ProviderRegistry:
    """Central registry for AI provider backends."""

    def __init__(self) -> None:
        self._llm_classes: dict[str, type[LLMProvider]] = {}
        self._embedding_classes: dict[str, type[EmbeddingProvider]] = {}
        self._reranker_classes: dict[str, type[RerankerProvider]] = {}

    # -- LLM --

    def register_llm(self, name: str, provider_class: type[LLMProvider]) -> None:
        self._llm_classes[name] = provider_class
        logger.info("registry.llm_registered", provider=name)

    def get_llm(self, name: str) -> _ResilientLLMProvider:
        """Create a new instance with circuit breaker wrapping."""
        cls = self._llm_classes.get(name)
        if cls is None:
            raise KeyError(f"LLM provider '{name}' not registered")
        return _ResilientLLMProvider(cls())

    # -- Embedding --

    def register_embedding(self, name: str, provider_class: type[EmbeddingProvider]) -> None:
        self._embedding_classes[name] = provider_class

    def get_embedding(self, name: str) -> EmbeddingProvider:
        cls = self._embedding_classes.get(name)
        if cls is None:
            raise KeyError(f"Embedding provider '{name}' not registered")
        return cls()

    # -- Reranker --

    def register_reranker(self, name: str, provider_class: type[RerankerProvider]) -> None:
        self._reranker_classes[name] = provider_class

    def get_reranker(self, name: str) -> RerankerProvider:
        cls = self._reranker_classes.get(name)
        if cls is None:
            raise KeyError(f"Reranker provider '{name}' not registered")
        return cls()

    @property
    def available_llms(self) -> list[str]:
        return list(self._llm_classes)


@lru_cache
def get_registry() -> ProviderRegistry:
    """Singleton registry."""
    return ProviderRegistry()
