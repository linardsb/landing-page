"""Unit tests for ProjectService using mocked database sessions."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.projects.exceptions import (
    ProjectAccessDeniedError,
    ProjectNameConflictError,
    ProjectNotFoundError,
)
from app.projects.models import Project
from app.projects.schemas import ProjectCreate, ProjectUpdate
from app.projects.service import ProjectService
from app.shared.schemas import PaginationParams


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime(2026, 1, 15, 12, 0, 0, tzinfo=timezone.utc)


def make_project(
    *,
    id: int = 1,
    name: str = "Test Project",
    description: str | None = "A test project",
    status: str = "active",
    owner_id: int = 1,
) -> Project:
    """Factory for Project model instances with sensible defaults."""
    project = MagicMock(spec=Project)
    project.id = id
    project.name = name
    project.description = description
    project.status = status
    project.owner_id = owner_id
    project.design_config = None
    project.created_at = _NOW
    project.updated_at = _NOW
    project.deleted_at = None
    project.members = []
    return project


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db_session() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def service(db_session: AsyncMock) -> ProjectService:
    return ProjectService(db_session)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_project(service: ProjectService) -> None:
    """Creating a project returns a ProjectResponse with the correct data."""
    data = ProjectCreate(name="New Project", description="desc")
    project = make_project(name="New Project", description="desc")

    with patch.object(service._repo, "get_by_name", return_value=None), patch.object(
        service._repo, "create", return_value=project
    ):
        result = await service.create_project(data, owner_id=1)

    assert result.name == "New Project"
    assert result.description == "desc"
    assert result.id == 1


@pytest.mark.asyncio
async def test_create_project_name_conflict(service: ProjectService) -> None:
    """Creating a project with an existing name raises ProjectNameConflictError."""
    data = ProjectCreate(name="Existing")
    existing = make_project(name="Existing")

    with patch.object(service._repo, "get_by_name", return_value=existing):
        with pytest.raises(ProjectNameConflictError):
            await service.create_project(data, owner_id=1)


@pytest.mark.asyncio
async def test_get_project(service: ProjectService) -> None:
    """Getting an existing project returns a detail response."""
    project = make_project()

    with patch.object(service._repo, "get", return_value=project):
        result = await service.get_project(project_id=1, user_id=1)

    assert result.id == 1
    assert result.name == "Test Project"
    assert result.members == []


@pytest.mark.asyncio
async def test_get_project_not_found(service: ProjectService) -> None:
    """Getting a nonexistent project raises ProjectNotFoundError."""
    with patch.object(service._repo, "get", return_value=None):
        with pytest.raises(ProjectNotFoundError):
            await service.get_project(project_id=999, user_id=1)


@pytest.mark.asyncio
async def test_update_project(service: ProjectService) -> None:
    """Updating a project returns the modified response."""
    project = make_project(owner_id=1)
    updated = make_project(name="Updated Name", owner_id=1)

    data = ProjectUpdate(name="Updated Name")

    with (
        patch.object(service._repo, "get", return_value=project),
        patch.object(service._repo, "get_by_name", return_value=None),
        patch.object(service._repo, "update", return_value=updated),
    ):
        result = await service.update_project(project_id=1, data=data, user_id=1)

    assert result.name == "Updated Name"


@pytest.mark.asyncio
async def test_update_project_access_denied(service: ProjectService) -> None:
    """Updating a project owned by another user raises ProjectAccessDeniedError."""
    project = make_project(owner_id=99)
    data = ProjectUpdate(name="Hacked")

    with patch.object(service._repo, "get", return_value=project):
        with pytest.raises(ProjectAccessDeniedError):
            await service.update_project(project_id=1, data=data, user_id=1)


@pytest.mark.asyncio
async def test_delete_project(service: ProjectService) -> None:
    """Deleting an owned project succeeds without error."""
    project = make_project(owner_id=1)

    with (
        patch.object(service._repo, "get", return_value=project),
        patch.object(service._repo, "delete", return_value=None),
    ):
        await service.delete_project(project_id=1, user_id=1)


@pytest.mark.asyncio
async def test_delete_project_not_found(service: ProjectService) -> None:
    """Deleting a nonexistent project raises ProjectNotFoundError."""
    with patch.object(service._repo, "get", return_value=None):
        with pytest.raises(ProjectNotFoundError):
            await service.delete_project(project_id=999, user_id=1)


@pytest.mark.asyncio
async def test_delete_project_access_denied(service: ProjectService) -> None:
    """Deleting a project owned by another user raises ProjectAccessDeniedError."""
    project = make_project(owner_id=99)

    with patch.object(service._repo, "get", return_value=project):
        with pytest.raises(ProjectAccessDeniedError):
            await service.delete_project(project_id=1, user_id=1)


@pytest.mark.asyncio
async def test_list_projects(service: ProjectService) -> None:
    """Listing projects returns a paginated response."""
    projects = [make_project(id=i, name=f"Project {i}") for i in range(1, 4)]
    pagination = PaginationParams(page=1, page_size=20)

    with (
        patch.object(service._repo, "list", return_value=projects),
        patch.object(service._repo, "count", return_value=3),
    ):
        result = await service.list_projects(pagination)

    assert result.total == 3
    assert len(result.items) == 3
    assert result.page == 1
