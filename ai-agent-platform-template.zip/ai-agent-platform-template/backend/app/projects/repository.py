"""Data-access layer for projects. No business logic — SQL only."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.projects.models import Project
from app.projects.schemas import ProjectCreate, ProjectUpdate
from app.shared.utils import escape_like


class ProjectRepository:
    """Async repository for Project CRUD operations."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    async def get(self, project_id: int) -> Project | None:
        """Fetch a single non-deleted project by ID."""
        stmt = select(Project).where(
            Project.id == project_id,
            Project.deleted_at.is_(None),
        )
        result = await self._db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_name(self, name: str) -> Project | None:
        """Fetch a single non-deleted project by exact name."""
        stmt = select(Project).where(
            Project.name == name,
            Project.deleted_at.is_(None),
        )
        result = await self._db.execute(stmt)
        return result.scalar_one_or_none()

    async def list(
        self,
        offset: int,
        limit: int,
        search: str | None = None,
        owner_id: int | None = None,
    ) -> Sequence[Project]:
        """List non-deleted projects with optional search and owner filter."""
        stmt = select(Project).where(Project.deleted_at.is_(None))

        if search:
            pattern = f"%{escape_like(search)}%"
            stmt = stmt.where(Project.name.ilike(pattern))
        if owner_id is not None:
            stmt = stmt.where(Project.owner_id == owner_id)

        stmt = stmt.order_by(Project.created_at.desc()).offset(offset).limit(limit)
        result = await self._db.execute(stmt)
        return result.scalars().all()

    async def count(
        self,
        search: str | None = None,
        owner_id: int | None = None,
    ) -> int:
        """Count non-deleted projects matching optional filters."""
        stmt = select(func.count(Project.id)).where(Project.deleted_at.is_(None))

        if search:
            pattern = f"%{escape_like(search)}%"
            stmt = stmt.where(Project.name.ilike(pattern))
        if owner_id is not None:
            stmt = stmt.where(Project.owner_id == owner_id)

        result = await self._db.execute(stmt)
        return result.scalar_one()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    async def create(self, data: ProjectCreate, owner_id: int) -> Project:
        """Insert a new project and flush to obtain the generated ID."""
        project = Project(
            name=data.name,
            description=data.description,
            owner_id=owner_id,
        )
        self._db.add(project)
        await self._db.flush()
        await self._db.refresh(project)
        return project

    async def update(self, project: Project, data: ProjectUpdate) -> Project:
        """Apply partial updates to an existing project."""
        update_fields = data.model_dump(exclude_unset=True)
        for field, value in update_fields.items():
            setattr(project, field, value)
        await self._db.flush()
        await self._db.refresh(project)
        return project

    async def delete(self, project: Project) -> None:
        """Soft-delete a project by setting deleted_at."""
        from sqlalchemy import func as sa_func

        project.deleted_at = sa_func.now()
        await self._db.flush()
