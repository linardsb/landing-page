"""HTTP endpoints for the projects feature."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query, status

from app.projects.dependencies import get_project_service
from app.projects.schemas import (
    ProjectCreate,
    ProjectDetailResponse,
    ProjectResponse,
    ProjectUpdate,
)
from app.projects.service import ProjectService
from app.shared.schemas import PaginatedResponse, PaginationParams

router = APIRouter(prefix="/projects", tags=["projects"])

# Placeholder owner_id until auth module is implemented.
# Replace with: current_user: User = Depends(get_current_user)
_PLACEHOLDER_OWNER_ID = 1


@router.get("", response_model=PaginatedResponse[ProjectResponse])
async def list_projects(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    # current_user: User = Depends(get_current_user),
    service: ProjectService = Depends(get_project_service),
) -> PaginatedResponse[ProjectResponse]:
    """List projects with pagination."""
    pagination = PaginationParams(page=page, page_size=page_size)
    return await service.list_projects(pagination)


@router.get("/{project_id}", response_model=ProjectDetailResponse)
async def get_project(
    project_id: int,
    # current_user: User = Depends(get_current_user),
    service: ProjectService = Depends(get_project_service),
) -> ProjectDetailResponse:
    """Get a single project with its members."""
    return await service.get_project(project_id, user_id=_PLACEHOLDER_OWNER_ID)


@router.post(
    "",
    response_model=ProjectResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_project(
    data: ProjectCreate,
    # current_user: User = Depends(get_current_user),
    service: ProjectService = Depends(get_project_service),
) -> ProjectResponse:
    """Create a new project."""
    return await service.create_project(data, owner_id=_PLACEHOLDER_OWNER_ID)


@router.patch("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: int,
    data: ProjectUpdate,
    # current_user: User = Depends(get_current_user),
    service: ProjectService = Depends(get_project_service),
) -> ProjectResponse:
    """Partially update a project."""
    return await service.update_project(
        project_id, data, user_id=_PLACEHOLDER_OWNER_ID
    )


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_project(
    project_id: int,
    # current_user: User = Depends(get_current_user),
    service: ProjectService = Depends(get_project_service),
) -> None:
    """Soft-delete a project."""
    await service.delete_project(project_id, user_id=_PLACEHOLDER_OWNER_ID)
