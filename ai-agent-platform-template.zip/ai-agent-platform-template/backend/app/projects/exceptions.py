"""Project-specific exceptions."""

from __future__ import annotations

from app.core.exceptions import ConflictError, ForbiddenError, NotFoundError


class ProjectNotFoundError(NotFoundError):
    """Raised when a project does not exist or has been soft-deleted."""

    def __init__(self) -> None:
        super().__init__("Project not found")


class ProjectAccessDeniedError(ForbiddenError):
    """Raised when a user lacks permission for a project operation."""

    def __init__(self) -> None:
        super().__init__("Access denied to this project")


class ProjectNameConflictError(ConflictError):
    """Raised when a project name is already taken."""

    def __init__(self) -> None:
        super().__init__("A project with this name already exists")
