"""Projects feature slice: CRUD, membership, and design configuration."""
