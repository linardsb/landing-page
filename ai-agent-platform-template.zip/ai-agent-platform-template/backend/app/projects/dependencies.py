"""FastAPI dependency injection for the projects feature."""

from __future__ import annotations

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.projects.service import ProjectService


async def get_project_service(
    db: AsyncSession = Depends(get_db),
) -> ProjectService:
    """Provide a ProjectService wired to the request-scoped DB session."""
    return ProjectService(db)
