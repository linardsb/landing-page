"""Business logic for the projects feature."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.projects.exceptions import (
    ProjectAccessDeniedError,
    ProjectNameConflictError,
    ProjectNotFoundError,
)
from app.projects.repository import ProjectRepository
from app.projects.schemas import (
    ProjectCreate,
    ProjectDetailResponse,
    ProjectMemberResponse,
    ProjectResponse,
    ProjectUpdate,
)
from app.shared.schemas import PaginatedResponse, PaginationParams

logger = get_logger(__name__)


class ProjectService:
    """Orchestrates project operations with access control and validation."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._repo = ProjectRepository(db)

    # ------------------------------------------------------------------
    # List
    # ------------------------------------------------------------------

    async def list_projects(
        self,
        pagination: PaginationParams,
        user_id: int | None = None,
    ) -> PaginatedResponse[ProjectResponse]:
        """Return a paginated list of projects, optionally filtered by owner."""
        items = await self._repo.list(
            offset=pagination.offset,
            limit=pagination.page_size,
            owner_id=user_id,
        )
        total = await self._repo.count(owner_id=user_id)

        return PaginatedResponse[ProjectResponse](
            items=[ProjectResponse.model_validate(p) for p in items],
            total=total,
            page=pagination.page,
            page_size=pagination.page_size,
        )

    # ------------------------------------------------------------------
    # Get (detail)
    # ------------------------------------------------------------------

    async def get_project(
        self,
        project_id: int,
        user_id: int,
    ) -> ProjectDetailResponse:
        """Fetch a single project with its members. Raises on miss."""
        project = await self._repo.get(project_id)
        if project is None:
            raise ProjectNotFoundError()

        members = [
            ProjectMemberResponse.model_validate(m) for m in project.members
        ]
        return ProjectDetailResponse(
            **ProjectResponse.model_validate(project).model_dump(),
            members=members,
        )

    # ------------------------------------------------------------------
    # Create
    # ------------------------------------------------------------------

    async def create_project(
        self,
        data: ProjectCreate,
        owner_id: int,
    ) -> ProjectResponse:
        """Create a project after validating name uniqueness."""
        existing = await self._repo.get_by_name(data.name)
        if existing is not None:
            raise ProjectNameConflictError()

        project = await self._repo.create(data, owner_id)
        logger.info(
            "projects.create_completed",
            project_id=project.id,
            owner_id=owner_id,
        )
        return ProjectResponse.model_validate(project)

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    async def update_project(
        self,
        project_id: int,
        data: ProjectUpdate,
        user_id: int,
    ) -> ProjectResponse:
        """Update a project. Only the owner may modify it."""
        project = await self._repo.get(project_id)
        if project is None:
            raise ProjectNotFoundError()
        if project.owner_id != user_id:
            raise ProjectAccessDeniedError()

        # Check name uniqueness if name is being changed
        if data.name is not None and data.name != project.name:
            existing = await self._repo.get_by_name(data.name)
            if existing is not None:
                raise ProjectNameConflictError()

        project = await self._repo.update(project, data)
        logger.info(
            "projects.update_completed",
            project_id=project.id,
            user_id=user_id,
        )
        return ProjectResponse.model_validate(project)

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    async def delete_project(
        self,
        project_id: int,
        user_id: int,
    ) -> None:
        """Soft-delete a project. Only the owner may delete."""
        project = await self._repo.get(project_id)
        if project is None:
            raise ProjectNotFoundError()
        if project.owner_id != user_id:
            raise ProjectAccessDeniedError()

        await self._repo.delete(project)
        logger.info(
            "projects.delete_completed",
            project_id=project_id,
            user_id=user_id,
        )
