"""Pydantic schemas for the projects feature."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ProjectCreate(BaseModel):
    """Schema for creating a new project."""

    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = None


class ProjectUpdate(BaseModel):
    """Schema for partially updating a project."""

    name: str | None = Field(default=None, min_length=1, max_length=100)
    description: str | None = None
    status: str | None = Field(default=None, pattern=r"^(active|archived|paused)$")


class ProjectResponse(BaseModel):
    """Public representation of a project."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None
    status: str
    owner_id: int
    created_at: datetime
    updated_at: datetime


class ProjectMemberResponse(BaseModel):
    """Public representation of a project member."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    role: str
    created_at: datetime


class ProjectDetailResponse(ProjectResponse):
    """Project with its member list."""

    members: list[ProjectMemberResponse] = []
