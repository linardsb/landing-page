#!/usr/bin/env python3
"""Scaffold CLI for generating vertical slices and AI agents.

Usage:
    python cli.py new-feature <name>    Generate a complete feature vertical slice
    python cli.py new-agent <name>      Generate a complete AI agent scaffold
"""
from __future__ import annotations

import argparse
import re
import sys
import textwrap
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# Name helpers
# ---------------------------------------------------------------------------

def _validate_name(name: str) -> str:
    """Ensure the name is a valid Python identifier in snake_case."""
    slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    if not slug.isidentifier():
        print(f"Error: '{name}' cannot be converted to a valid Python identifier.")
        sys.exit(1)
    return slug


def _to_pascal(snake: str) -> str:
    return "".join(part.capitalize() for part in snake.split("_"))


def _to_upper(snake: str) -> str:
    return snake.upper()


def _singular(name: str) -> str:
    """Naive singularisation: strip trailing 's' if present."""
    if name.endswith("ies"):
        return name[:-3] + "y"
    if name.endswith("ses"):
        return name[:-2]
    if name.endswith("s") and not name.endswith("ss"):
        return name[:-1]
    return name


def _plural(name: str) -> str:
    """Naive pluralisation."""
    if name.endswith("y") and not name.endswith("ey"):
        return name[:-1] + "ies"
    if name.endswith(("s", "sh", "ch", "x", "z")):
        return name + "es"
    return name + "s"


# ---------------------------------------------------------------------------
# File writer
# ---------------------------------------------------------------------------

def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(content).lstrip("\n"), encoding="utf-8")
    print(f"  created {path.relative_to(BASE_DIR)}")


# ---------------------------------------------------------------------------
# new-feature templates
# ---------------------------------------------------------------------------

def _feature_init(name: str) -> str:
    Name = _to_pascal(name)
    return f'"""{Name} feature — vertical slice."""\n'


def _feature_models(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    return f'''\
        """Database models for the {name} feature."""
        from __future__ import annotations

        import uuid
        from datetime import datetime

        from sqlalchemy import Boolean, DateTime, String, Text, func
        from sqlalchemy.dialects.postgresql import UUID
        from sqlalchemy.orm import Mapped, mapped_column

        from app.shared.database import Base
        from app.shared.mixins import SoftDeleteMixin, TimestampMixin


        class {Singular}(TimestampMixin, SoftDeleteMixin, Base):
            """Core {singular} entity."""

            __tablename__ = "{name}"

            id: Mapped[uuid.UUID] = mapped_column(
                UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
            )
            name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
            description: Mapped[str | None] = mapped_column(Text, nullable=True)

            def __repr__(self) -> str:
                return f"<{Singular} id={{self.id}} name={{self.name!r}}>"
    '''


def _feature_schemas(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    return f'''\
        """Pydantic schemas for the {name} feature."""
        from __future__ import annotations

        import uuid
        from datetime import datetime

        from pydantic import BaseModel, ConfigDict


        class {Singular}Create(BaseModel):
            """Schema for creating a {singular}."""

            name: str
            description: str | None = None


        class {Singular}Update(BaseModel):
            """Schema for updating a {singular}."""

            name: str | None = None
            description: str | None = None


        class {Singular}Response(BaseModel):
            """Schema for {singular} API responses."""

            model_config = ConfigDict(from_attributes=True)

            id: uuid.UUID
            name: str
            description: str | None = None
            created_at: datetime
            updated_at: datetime
    '''


def _feature_exceptions(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    return f'''\
        """Exceptions for the {name} feature."""
        from __future__ import annotations

        from app.core.exceptions import AppError


        class {Singular}NotFoundError(AppError):
            """Raised when a {singular} is not found."""

            def __init__(self, identifier: str | None = None) -> None:
                detail = f"{Singular} not found"
                if identifier:
                    detail = f"{Singular} '{{identifier}}' not found"
                super().__init__(detail=detail, status_code=404)


        class {Singular}AccessDeniedError(AppError):
            """Raised when access to a {singular} is denied."""

            def __init__(self) -> None:
                super().__init__(
                    detail="Access denied to this {singular}", status_code=403
                )


        class {Singular}ConflictError(AppError):
            """Raised when a {singular} conflicts with an existing record."""

            def __init__(self, field: str, value: str) -> None:
                super().__init__(
                    detail=f"{Singular} with {{field}} '{{value}}' already exists",
                    status_code=409,
                )
    '''


def _feature_repository(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    plural = _plural(singular)
    return f'''\
        """Repository layer for the {name} feature — database operations only."""
        from __future__ import annotations

        import uuid
        from typing import Sequence

        from sqlalchemy import func, select, update
        from sqlalchemy.ext.asyncio import AsyncSession

        from app.{name}.models import {Singular}
        from app.{name}.schemas import {Singular}Create, {Singular}Update


        class {Singular}Repository:
            """Database access for {plural}."""

            def __init__(self, db: AsyncSession) -> None:
                self.db = db

            async def get(self, {singular}_id: uuid.UUID) -> {Singular} | None:
                stmt = select({Singular}).where(
                    {Singular}.id == {singular}_id,
                    {Singular}.is_deleted.is_(False),
                )
                result = await self.db.execute(stmt)
                return result.scalar_one_or_none()

            async def list(
                self,
                *,
                offset: int = 0,
                limit: int = 50,
            ) -> Sequence[{Singular}]:
                stmt = (
                    select({Singular})
                    .where({Singular}.is_deleted.is_(False))
                    .order_by({Singular}.created_at.desc())
                    .offset(offset)
                    .limit(limit)
                )
                result = await self.db.execute(stmt)
                return result.scalars().all()

            async def count(self) -> int:
                stmt = select(func.count()).select_from({Singular}).where(
                    {Singular}.is_deleted.is_(False)
                )
                result = await self.db.execute(stmt)
                return result.scalar_one()

            async def create(self, data: {Singular}Create) -> {Singular}:
                instance = {Singular}(**data.model_dump())
                self.db.add(instance)
                await self.db.flush()
                await self.db.refresh(instance)
                return instance

            async def update(
                self,
                {singular}_id: uuid.UUID,
                data: {Singular}Update,
            ) -> {Singular} | None:
                instance = await self.get({singular}_id)
                if instance is None:
                    return None
                for key, value in data.model_dump(exclude_unset=True).items():
                    setattr(instance, key, value)
                await self.db.flush()
                await self.db.refresh(instance)
                return instance

            async def delete(self, {singular}_id: uuid.UUID) -> bool:
                """Soft-delete a {singular}."""
                instance = await self.get({singular}_id)
                if instance is None:
                    return False
                instance.is_deleted = True
                await self.db.flush()
                return True
    '''


def _feature_service(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    plural = _plural(singular)
    return f'''\
        """Service layer for the {name} feature — business logic."""
        from __future__ import annotations

        import uuid
        from typing import Sequence

        from app.core.logging import get_logger
        from app.{name}.exceptions import {Singular}NotFoundError
        from app.{name}.repository import {Singular}Repository
        from app.{name}.schemas import {Singular}Create, {Singular}Response, {Singular}Update

        logger = get_logger(__name__)


        class {Singular}Service:
            """Business logic for {plural}."""

            def __init__(self, repository: {Singular}Repository) -> None:
                self.repository = repository

            async def get(self, {singular}_id: uuid.UUID) -> {Singular}Response:
                instance = await self.repository.get({singular}_id)
                if instance is None:
                    raise {Singular}NotFoundError(str({singular}_id))
                logger.info("{name}.get_completed", {singular}_id=str({singular}_id))
                return {Singular}Response.model_validate(instance)

            async def list(
                self,
                *,
                offset: int = 0,
                limit: int = 50,
            ) -> list[{Singular}Response]:
                items = await self.repository.list(offset=offset, limit=limit)
                logger.info("{name}.list_completed", count=len(items))
                return [{Singular}Response.model_validate(i) for i in items]

            async def count(self) -> int:
                return await self.repository.count()

            async def create(self, data: {Singular}Create) -> {Singular}Response:
                instance = await self.repository.create(data)
                logger.info("{name}.create_completed", {singular}_id=str(instance.id))
                return {Singular}Response.model_validate(instance)

            async def update(
                self,
                {singular}_id: uuid.UUID,
                data: {Singular}Update,
            ) -> {Singular}Response:
                instance = await self.repository.update({singular}_id, data)
                if instance is None:
                    raise {Singular}NotFoundError(str({singular}_id))
                logger.info("{name}.update_completed", {singular}_id=str({singular}_id))
                return {Singular}Response.model_validate(instance)

            async def delete(self, {singular}_id: uuid.UUID) -> None:
                deleted = await self.repository.delete({singular}_id)
                if not deleted:
                    raise {Singular}NotFoundError(str({singular}_id))
                logger.info("{name}.delete_completed", {singular}_id=str({singular}_id))
    '''


def _feature_routes(name: str) -> str:
    Name = _to_pascal(name)
    singular = _singular(name)
    Singular = _to_pascal(singular)
    plural = _plural(singular)
    return f'''\
        """API routes for the {name} feature."""
        from __future__ import annotations

        import uuid

        from fastapi import APIRouter, Depends, Query

        from app.{name}.dependencies import get_{singular}_service
        from app.{name}.schemas import {Singular}Create, {Singular}Response, {Singular}Update
        from app.{name}.service import {Singular}Service

        router = APIRouter(prefix="/{name}", tags=["{Name}"])


        @router.get("/", response_model=list[{Singular}Response])
        async def list_{plural}(
            offset: int = Query(0, ge=0),
            limit: int = Query(50, ge=1, le=200),
            service: {Singular}Service = Depends(get_{singular}_service),
        ) -> list[{Singular}Response]:
            return await service.list(offset=offset, limit=limit)


        @router.get("/{{{singular}_id}}", response_model={Singular}Response)
        async def get_{singular}(
            {singular}_id: uuid.UUID,
            service: {Singular}Service = Depends(get_{singular}_service),
        ) -> {Singular}Response:
            return await service.get({singular}_id)


        @router.post("/", response_model={Singular}Response, status_code=201)
        async def create_{singular}(
            body: {Singular}Create,
            service: {Singular}Service = Depends(get_{singular}_service),
        ) -> {Singular}Response:
            return await service.create(body)


        @router.patch("/{{{singular}_id}}", response_model={Singular}Response)
        async def update_{singular}(
            {singular}_id: uuid.UUID,
            body: {Singular}Update,
            service: {Singular}Service = Depends(get_{singular}_service),
        ) -> {Singular}Response:
            return await service.update({singular}_id, body)


        @router.delete("/{{{singular}_id}}", status_code=204)
        async def delete_{singular}(
            {singular}_id: uuid.UUID,
            service: {Singular}Service = Depends(get_{singular}_service),
        ) -> None:
            await service.delete({singular}_id)
    '''


def _feature_dependencies(name: str) -> str:
    singular = _singular(name)
    Singular = _to_pascal(singular)
    return f'''\
        """Dependency injection for the {name} feature."""
        from __future__ import annotations

        from fastapi import Depends
        from sqlalchemy.ext.asyncio import AsyncSession

        from app.core.database import get_db
        from app.{name}.repository import {Singular}Repository
        from app.{name}.service import {Singular}Service


        async def get_{singular}_service(
            db: AsyncSession = Depends(get_db),
        ) -> {Singular}Service:
            repository = {Singular}Repository(db)
            return {Singular}Service(repository)
    '''


def _feature_test_init() -> str:
    return '"""Tests package."""\n'


def _feature_test_service(name: str) -> str:
    singular = _singular(name)
    Singular = _to_pascal(singular)
    plural = _plural(singular)
    return f'''\
        """Unit tests for the {name} service layer."""
        from __future__ import annotations

        import uuid
        from unittest.mock import AsyncMock

        import pytest

        from app.{name}.exceptions import {Singular}NotFoundError
        from app.{name}.schemas import {Singular}Create, {Singular}Update
        from app.{name}.service import {Singular}Service


        def make_{singular}(
            *,
            name: str = "Test {Singular}",
            description: str | None = None,
        ) -> {Singular}Create:
            return {Singular}Create(name=name, description=description)


        @pytest.fixture
        def repository() -> AsyncMock:
            return AsyncMock()


        @pytest.fixture
        def service(repository: AsyncMock) -> {Singular}Service:
            return {Singular}Service(repository=repository)


        @pytest.mark.asyncio
        async def test_create_{singular}(service: {Singular}Service, repository: AsyncMock) -> None:
            data = make_{singular}()
            repository.create.return_value = AsyncMock(
                id=uuid.uuid4(),
                name=data.name,
                description=data.description,
                created_at="2024-01-01T00:00:00Z",
                updated_at="2024-01-01T00:00:00Z",
            )
            result = await service.create(data)
            repository.create.assert_awaited_once_with(data)
            assert result.name == data.name


        @pytest.mark.asyncio
        async def test_get_{singular}_not_found(
            service: {Singular}Service, repository: AsyncMock
        ) -> None:
            repository.get.return_value = None
            with pytest.raises({Singular}NotFoundError):
                await service.get(uuid.uuid4())


        @pytest.mark.asyncio
        async def test_list_{plural}(service: {Singular}Service, repository: AsyncMock) -> None:
            repository.list.return_value = []
            result = await service.list()
            assert result == []
            repository.list.assert_awaited_once()


        @pytest.mark.asyncio
        async def test_delete_{singular}_not_found(
            service: {Singular}Service, repository: AsyncMock
        ) -> None:
            repository.delete.return_value = False
            with pytest.raises({Singular}NotFoundError):
                await service.delete(uuid.uuid4())
    '''


# ---------------------------------------------------------------------------
# new-agent templates
# ---------------------------------------------------------------------------

def _agent_init(name: str) -> str:
    Name = _to_pascal(name)
    return f'"""{Name} AI agent."""\n'


def _agent_schemas(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        """Request/response schemas for the {name} agent."""
        from __future__ import annotations

        from pydantic import Field

        from app.ai.agents.base import AgentRequest, AgentResponse


        class {Name}Request(AgentRequest):
            """Input for the {name} agent."""

            content: str = Field(..., description="The content to process")
            context: dict[str, str] = Field(
                default_factory=dict,
                description="Additional context for the agent",
            )


        class {Name}Response(AgentResponse):
            """Output from the {name} agent."""

            result: str = Field(..., description="The processed result")
            confidence: float = Field(
                default=1.0,
                ge=0.0,
                le=1.0,
                description="Confidence score of the result",
            )
    '''


def _agent_prompt(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        """Prompt construction for the {name} agent."""
        from __future__ import annotations


        def build_system_prompt(*, context: dict[str, str] | None = None) -> str:
            """Build the system prompt for the {name} agent.

            Args:
                context: Optional key-value context to inject into the prompt.

            Returns:
                The complete system prompt string.
            """
            base = (
                "You are the {Name} agent. "
                "Your role is to analyse the provided content and produce a structured result.\\n\\n"
                "Guidelines:\\n"
                "- Be precise and consistent\\n"
                "- Cite specific evidence for your decisions\\n"
                "- Return structured output matching the response schema\\n"
            )
            if context:
                extras = "\\n".join(f"- {{k}}: {{v}}" for k, v in context.items())
                base += f"\\nAdditional context:\\n{{extras}}\\n"
            return base


        def detect_relevant_skills(content: str) -> list[str]:
            """Detect which skills are relevant for the given content.

            Args:
                content: The input content to analyse.

            Returns:
                A list of skill identifiers that should be activated.
            """
            # TODO: Implement skill detection logic
            return []
    '''


def _agent_service(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        """Service for the {name} agent."""
        from __future__ import annotations

        from app.ai.agents.base import BaseAgentService
        from app.ai.agents.{name}.prompt import build_system_prompt, detect_relevant_skills
        from app.ai.agents.{name}.schemas import {Name}Request, {Name}Response
        from app.core.logging import get_logger

        logger = get_logger(__name__)


        class {Name}AgentService(BaseAgentService[{Name}Request, {Name}Response]):
            """Business logic for the {name} agent."""

            agent_name: str = "{name}"
            sanitization_profile: str = "{name}"

            async def build_prompt(self, request: {Name}Request) -> str:
                """Build the complete prompt for this agent invocation."""
                return build_system_prompt(context=request.context)

            async def parse_response(self, raw: str, request: {Name}Request) -> {Name}Response:
                """Parse the LLM output into a structured response."""
                return {Name}Response(
                    result=raw,
                    confidence=1.0,
                )

            async def validate_input(self, request: {Name}Request) -> None:
                """Validate the request before processing."""
                if not request.content.strip():
                    raise ValueError("Content must not be empty")

            async def run(self, request: {Name}Request) -> {Name}Response:
                """Execute the agent pipeline."""
                await self.validate_input(request)

                skills = detect_relevant_skills(request.content)
                logger.info(
                    "{name}.run_started",
                    content_length=len(request.content),
                    skills=skills,
                )

                prompt = await self.build_prompt(request)
                raw = await self.call_llm(prompt, request.content)
                response = await self.parse_response(raw, request)

                logger.info(
                    "{name}.run_completed",
                    confidence=response.confidence,
                )
                return response
    '''


def _agent_skill_md(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        ---
        agent: {name}
        version: "1.0"
        description: "Skills extracted for the {Name} agent"
        ---

        # {Name} Agent Skills

        ## Skill: analyse_content
        **Description:** Analyse the provided content and extract key insights.
        **When to use:** When the agent receives new content for processing.
        **Parameters:**
        - `content` (str): The raw content to analyse.
        - `depth` (str): "shallow" | "deep" — analysis depth.

        ## Skill: generate_result
        **Description:** Generate a structured result based on the analysis.
        **When to use:** After content analysis is complete.
        **Parameters:**
        - `analysis` (dict): The analysis output to structure.
    '''


def _agent_evals_init() -> str:
    return '"""Evaluation suite."""\n'


def _agent_synthetic_data(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        """Synthetic test cases for the {name} agent."""
        from __future__ import annotations


        SYNTHETIC_CASES: list[dict[str, str]] = [
            {{
                "id": "{name}_basic_001",
                "input": "A short sample input for basic processing.",
                "expected_behaviour": "Should produce a structured result with high confidence.",
                "category": "basic",
            }},
            {{
                "id": "{name}_edge_empty_002",
                "input": "",
                "expected_behaviour": "Should raise a validation error for empty content.",
                "category": "edge_case",
            }},
            {{
                "id": "{name}_complex_003",
                "input": "A longer, more complex input that contains multiple topics, "
                "requires contextual understanding, and should exercise the full pipeline "
                "including skill detection and structured output generation.",
                "expected_behaviour": "Should identify relevant skills and produce detailed result.",
                "category": "complex",
            }},
        ]
    '''


def _agent_judge(name: str) -> str:
    Name = _to_pascal(name)
    return f'''\
        """LLM judge for evaluating {name} agent outputs."""
        from __future__ import annotations

        from dataclasses import dataclass


        @dataclass(frozen=True)
        class JudgeCriterion:
            """A single evaluation criterion."""

            name: str
            description: str
            weight: float = 1.0


        CRITERIA: list[JudgeCriterion] = [
            JudgeCriterion(
                name="relevance",
                description="The result directly addresses the input content.",
                weight=1.0,
            ),
            JudgeCriterion(
                name="completeness",
                description="The result covers all key aspects of the input.",
                weight=0.8,
            ),
            JudgeCriterion(
                name="consistency",
                description="The result is internally consistent and well-structured.",
                weight=0.6,
            ),
        ]


        class {Name}Judge:
            """Evaluates {name} agent outputs against defined criteria."""

            criteria: list[JudgeCriterion] = CRITERIA

            async def evaluate(
                self,
                *,
                input_content: str,
                output_result: str,
                expected_behaviour: str,
            ) -> dict[str, bool]:
                """Evaluate the agent output against all criteria.

                Args:
                    input_content: The original input to the agent.
                    output_result: The agent's produced result.
                    expected_behaviour: Description of expected behaviour.

                Returns:
                    Dict mapping criterion name to pass/fail boolean.
                """
                # TODO: Implement LLM-based evaluation
                return {{c.name: True for c in self.criteria}}
    '''


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def cmd_new_feature(args: argparse.Namespace) -> None:
    name = _validate_name(args.name)
    singular = _singular(name)
    Name = _to_pascal(name)
    feature_dir = BASE_DIR / "app" / name

    if feature_dir.exists():
        print(f"Error: Directory '{feature_dir}' already exists. Refusing to overwrite.")
        sys.exit(1)

    print(f"Scaffolding feature '{name}' ...")

    _write(feature_dir / "__init__.py", _feature_init(name))
    _write(feature_dir / "models.py", _feature_models(name))
    _write(feature_dir / "schemas.py", _feature_schemas(name))
    _write(feature_dir / "exceptions.py", _feature_exceptions(name))
    _write(feature_dir / "repository.py", _feature_repository(name))
    _write(feature_dir / "service.py", _feature_service(name))
    _write(feature_dir / "routes.py", _feature_routes(name))
    _write(feature_dir / "dependencies.py", _feature_dependencies(name))
    _write(feature_dir / "tests" / "__init__.py", _feature_test_init())
    _write(feature_dir / "tests" / "test_service.py", _feature_test_service(name))

    print()
    print(f"Created feature '{name}'.")
    print(f"Register in main.py:  from app.{name}.routes import router as {name}_router")


def cmd_new_agent(args: argparse.Namespace) -> None:
    name = _validate_name(args.name)
    Name = _to_pascal(name)
    agent_dir = BASE_DIR / "app" / "ai" / "agents" / name

    if agent_dir.exists():
        print(f"Error: Directory '{agent_dir}' already exists. Refusing to overwrite.")
        sys.exit(1)

    print(f"Scaffolding agent '{name}' ...")

    _write(agent_dir / "__init__.py", _agent_init(name))
    _write(agent_dir / "schemas.py", _agent_schemas(name))
    _write(agent_dir / "prompt.py", _agent_prompt(name))
    _write(agent_dir / "service.py", _agent_service(name))
    _write(agent_dir / "skills" / "SKILL.md", _agent_skill_md(name))
    _write(agent_dir / "evals" / "__init__.py", _agent_evals_init())
    _write(agent_dir / "evals" / "synthetic_data.py", _agent_synthetic_data(name))
    _write(agent_dir / "evals" / "judge.py", _agent_judge(name))

    print()
    print(f"Created agent '{name}'.")
    print("Add to blueprint or create routes.")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="cli",
        description="Scaffold CLI for generating vertical slices and AI agents.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    feat = subparsers.add_parser(
        "new-feature",
        help="Generate a complete feature vertical slice",
    )
    feat.add_argument("name", help="Feature name in snake_case (e.g. invoices)")
    feat.set_defaults(func=cmd_new_feature)

    agent = subparsers.add_parser(
        "new-agent",
        help="Generate a complete AI agent scaffold",
    )
    agent.add_argument("name", help="Agent name in snake_case (e.g. summariser)")
    agent.set_defaults(func=cmd_new_agent)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
