# Implementation Plan

Create a structured implementation plan for a feature or change.

## Steps

1. **Gather requirements.** If $ARGUMENTS is provided, use it as the feature description. Otherwise, ask the user:
   - What feature or change is needed?
   - What problem does it solve?
   - Any constraints or preferences?

2. **Research the codebase.** Before planning:
   - Identify which existing modules are affected
   - Check for similar patterns already in the codebase
   - Look for shared utilities or base classes to reuse
   - Identify potential conflicts with existing code

3. **Create the plan.** Structure it as:

```markdown
# Plan: {feature_name}

## Goal
{One-sentence summary of what this achieves}

## Context
{Why this is needed, what problem it solves}

## Affected Files
{List of files that will be created or modified, grouped by area}

### New Files
- `path/to/new/file.py` — purpose

### Modified Files
- `path/to/existing/file.py` — what changes and why

## Implementation Steps
{Numbered steps in dependency order}

1. **Step name** — description
   - Sub-tasks if needed
   - Files touched: `list`

## Risks and Dependencies
- {Risk or dependency and how to mitigate}

## Testing Strategy
- Unit tests: {what to test}
- Integration tests: {what to test}
- Manual verification: {what to check}

## Open Questions
- {Anything that needs clarification before starting}
```

4. **Write the plan** to `.agents/plans/{feature-slug}.md` (create the directory if needed).

5. **Confirm** with the user. Ask if anything should be adjusted before starting implementation.

## Rules

- Steps should be in dependency order — each step should be completable and testable on its own where possible.
- Be specific about file paths.
- Reference existing patterns in the codebase ("follow the same pattern as `app/projects/`").
- If the change is large, suggest breaking it into smaller PRs.
