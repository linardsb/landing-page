# Backend Execute — Implement from Plan

Execute a previously created implementation plan step by step.

## Input

$ARGUMENTS — Name of the plan file (without path or extension). Looks for `.agents/plans/{name}.md`. If empty, list available plans in `.agents/plans/` and ask the user which one to execute.

## Steps

1. **Load the plan.** Read `.agents/plans/{name}.md`. Confirm the plan has:
   - Implementation steps with file lists
   - Clear dependency order
   - Security checklist
   If the plan is incomplete, warn the user and suggest running `/be-planning` first.

2. **Execute each step in order.** For each implementation step:

   a. **Announce** what you are about to do: "Step {N}/{total}: {step name}"

   b. **Implement** the changes described in the step. Follow these conventions:
      - All functions have complete type annotations (params + return)
      - Use `get_logger` for logging with `domain.action_state` event names
      - Use `AppError` hierarchy for errors
      - Repository: DB operations only. Service: business logic. Routes: thin HTTP layer.
      - Follow the reference pattern identified in the plan

   c. **Lint and format** changed files after each step:
      ```
      cd backend && python -m ruff format {changed_files}
      cd backend && python -m ruff check --fix {changed_files}
      ```

   d. **Verify** the step: confirm imports resolve and there are no syntax errors by running:
      ```
      cd backend && python -c "import app.{module}"
      ```

   e. **Report** step status:
      ```
      Step {N}/{total}: {step name}
      Files changed: {list}
      Status: DONE / ISSUE (describe)
      ```

3. **Run full validation** after all steps complete:
   - `cd backend && python -m pytest tests/ -x -q` — tests pass
   - `cd backend && python -m mypy app/` — type checking passes
   If either fails, diagnose and fix before continuing.

4. **Security verification** on all files changed during execution:
   - [ ] Auth dependencies present on protected routes
   - [ ] Rate limiting on public endpoints
   - [ ] `AppError` hierarchy used (no bare `Exception`)
   - [ ] `escape_like()` on LIKE queries
   - [ ] Parameterized SQL queries
   - [ ] Structured logging (no `print()`)
   - [ ] No hardcoded secrets or config values
   Report any violations found and fix them.

5. **Final report:**

```
EXECUTION COMPLETE
==================
Plan: {name}
Steps: {completed}/{total}
Files Created: {list}
Files Modified: {list}
Tests: PASS/FAIL
Types: PASS/FAIL
Security: {issues found or "clean"}
```

## Rules

- Do not skip steps or reorder them unless a dependency makes it necessary.
- If a step fails, diagnose and fix before moving to the next step.
- If the plan references `@_shared/python-anti-patterns`, apply those checks during implementation.
- If you discover the plan is missing something, implement the missing piece and note it in the report.
- Do not make changes outside the scope of the plan without asking the user.
