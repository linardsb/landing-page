# Frontend Code Review Fix — Diagnose and Fix Issues

Diagnose a frontend issue (bug, review finding, type error, lint error, visual issue) and fix it with full verification.

## Input

$ARGUMENTS — Description of the issue to fix. Can be:
- A review finding (e.g., "using primitive Tailwind colors in ProjectCard")
- A type error (e.g., "tsc error in src/hooks/useProjects.ts line 28")
- A lint error (e.g., "next lint warns about missing Image alt text")
- A bug report (e.g., "form submits twice on double click")
- A visual issue (e.g., "sidebar overlaps content on mobile")

If empty, ask the user to describe the issue.

## Steps

1. **Classify the issue.** Determine which category:
   - **Bug** — incorrect runtime behavior
   - **Review finding** — code quality, security, or style concern
   - **Type error** — TypeScript compilation failure
   - **Lint error** — ESLint or Next.js lint warning/error
   - **Visual issue** — layout, styling, or responsive problem
   This affects the diagnosis and verification approach.

2. **Research.** Trace the issue across the codebase:
   - Use `grep` and `glob` to find relevant code — do not read entire files.
   - For bugs: trace the component tree, hooks, and data flow.
   - For type errors: read the specific file and line, plus imported types.
   - For visual issues: read the component's JSX and Tailwind classes.
   - For review findings: read the flagged code and its context.

3. **Root cause analysis.** Before writing any fix, state:
   - **What is happening** — the observed behavior or error
   - **Why it is happening** — the underlying cause
   - **Where the fix belongs** — which file(s) and which layer (component, hook, type, style)

4. **Implement the fix.**
   - Make the minimal change that addresses the root cause.
   - Do not introduce unrelated changes.
   - Follow project patterns (semantic tokens, authFetch, React 19 conventions).

5. **Verify.** Run checks appropriate to the issue type:

   a. **TypeScript** (always):
      ```
      cd frontend && npx tsc --noEmit
      ```

   b. **Lint** (for lint errors and review findings):
      ```
      cd frontend && npx next lint
      ```

   c. **Tests** (if they exist for the affected component):
      ```
      cd frontend && npx vitest run {test_file}
      ```

   d. **Visual check** (for visual issues): describe what to verify in the browser.

6. **Report:**

```
ISSUE FIXED
===========
Classification: {bug/review finding/type error/lint error/visual issue}
Root Cause: {one sentence}
Fix Applied: {what was changed and why}
Files Changed: {list}
Verification:
  TypeScript: PASS
  Lint: PASS/SKIPPED
  Tests: PASS/SKIPPED
Risk Assessment: {LOW/MEDIUM/HIGH — could this fix break something else?}
```

## Rules

- Always diagnose before fixing. Never guess-and-check.
- Minimal fixes only — do not refactor unrelated code.
- For visual issues, describe the expected visual result since you cannot render the UI.
- If the fix requires choosing between multiple valid approaches, present options to the user.
- When fixing Tailwind token violations, apply `@_shared/tailwind-token-map` for correct mappings.
