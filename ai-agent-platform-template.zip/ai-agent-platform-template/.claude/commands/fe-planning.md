# Frontend Planning — Create Implementation Plan

Research the codebase and create a detailed implementation plan for a frontend feature or change.

## Input

$ARGUMENTS — Description of the feature or change to plan. If empty, ask the user what they want to build.

## Steps

1. **Research the codebase.** Before writing any plan:
   - Use `grep` and `glob` to find related components, hooks, and types — do NOT read entire files during research.
   - Identify existing components that can be reused or extended.
   - Find similar patterns already implemented (pick the closest feature as a reference).
   - Check if backend API endpoints already exist or need to be created first.
   - Look for relevant type definitions in `frontend/src/types/`.

2. **Determine the scope.** Classify the change:
   - **New page/route** — needs route, page component, data fetching
   - **New feature component** — needs component, hooks, types, possibly API integration
   - **Extension** — adds to existing component or page
   - **Cross-cutting** — modifies shared components, hooks, or lib
   - **Refactor** — restructures without new behavior

3. **Write the plan** to `.agents/plans/{feature-slug}-fe.md`:

```markdown
# Plan: {Feature Name} (Frontend)

## Goal
{One sentence: what this achieves and why it matters}

## Context
{What exists today. Which components/hooks to reuse. Reference specific files.}

## API Dependencies
{List backend endpoints this feature needs. Note if they exist or need to be created.}
- `GET /api/v1/{resource}` — {exists/needs creation}
- `POST /api/v1/{resource}` — {exists/needs creation}

## Files to Create
- `frontend/src/app/{route}/page.tsx` — page component
- `frontend/src/components/{feature}/{Component}.tsx` — feature component
- `frontend/src/hooks/use-{feature}.ts` — data fetching hook
- `frontend/src/types/{feature}.ts` — type definitions
{Adjust list based on scope.}

## Files to Modify
- `frontend/src/app/layout.tsx` — add navigation link (if new route)
- `frontend/src/types/index.ts` — export new types
- {Other files with specific description of what changes}

## Implementation Steps
{Ordered by dependency. Types first, then hooks, then components, then pages.}

1. **{Step name}** — {description}
   - Files: {list}
   - Depends on: {previous step number, or "none"}

2. **{Step name}** — {description}
   - Files: {list}
   - Depends on: {previous step number}

{Continue for all steps}

## Security Checklist
- [ ] All API calls use `authFetch` (no raw fetch)
- [ ] No `as any` type assertions
- [ ] No `dangerouslySetInnerHTML` without DOMPurify
- [ ] No tokens stored in localStorage/sessionStorage
- [ ] No secrets in client bundle (no non-NEXT_PUBLIC_ env vars)
- [ ] Semantic Tailwind tokens only (no primitive colors)
- [ ] User input validated before submission
- [ ] URLs validated before use in href/src

## Verification
- TypeScript: `cd frontend && npx tsc --noEmit`
- Lint: `cd frontend && npx next lint`
- Tests: `cd frontend && npx vitest run` (if configured)
- Visual: {describe what to check in browser}

## Open Questions
- {Anything that needs user input before starting}
```

4. **Cross-reference security and styling rules.** Review the plan against:
   - `@_shared/frontend-security` — flag any steps that handle user input, auth, or HTML injection
   - `@_shared/tailwind-token-map` — flag any steps involving styling

5. **Present the plan** to the user. Ask if anything should be adjusted before execution.

## Rules

- Types and hooks before components. Components before pages.
- Be specific about file paths — use full paths from project root.
- Reference existing patterns: "follow the pattern in `src/components/{existing}/`".
- If backend APIs don't exist yet, note this as a blocker and suggest running `/be-planning` first.
- For data fetching, always plan for loading states, error states, and empty states.
