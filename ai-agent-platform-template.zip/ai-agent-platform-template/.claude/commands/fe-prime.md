# Frontend Prime — Load Full Frontend Context

Load and summarize the frontend project structure, conventions, and key patterns so subsequent commands have full context.

## Steps

1. **Read project conventions.** Read `CLAUDE.md` at the project root for frontend coding standards and conventions.

2. **Explore frontend structure.** List the top-level directory structure of `frontend/src/` to understand the organization.

3. **Understand App Router structure.** Explore `frontend/src/app/`:
   - List all route groups and pages
   - Identify layouts, loading states, error boundaries
   - Note any middleware or route handlers (`route.ts`)

4. **Understand component organization.** Explore `frontend/src/components/`:
   - Identify UI primitives (buttons, inputs, dialogs)
   - Identify feature-specific component directories
   - Note shared/reusable components vs page-specific ones

5. **Load hook patterns.** Explore `frontend/src/hooks/`:
   - List all custom hooks
   - Identify auth hooks (useAuth, useSession)
   - Identify data fetching hooks (SWR-based)
   - Identify UI state hooks

6. **Load lib patterns.** Explore `frontend/src/lib/`:
   - Find `authFetch` or equivalent authenticated fetch wrapper
   - Find SWR configuration and fetcher functions
   - Find `ApiError` or equivalent error handling
   - Note any utility functions

7. **Load type definitions.** Explore `frontend/src/types/`:
   - List all type definition files
   - Note shared types used across components

8. **Understand auth flow.** Trace the authentication chain:
   - Auth provider (NextAuth, custom, etc.)
   - How tokens are stored and refreshed
   - How `authFetch` attaches credentials
   - Role-based access control patterns

9. **Understand styling.** Check the Tailwind configuration:
   - Read `frontend/tailwind.config.*` or `frontend/src/app/globals.css` for custom tokens
   - Confirm semantic token usage pattern
   - Note any design system integration

10. **Output context summary:**

```
FRONTEND CONTEXT LOADED
========================
Routes: {list of top-level routes}
Components: {count} directories ({list of feature areas})
Hooks: {list with brief purpose}
Lib: {list of utilities}
Types: {list of type files}
Auth: {provider} -> {fetch wrapper} -> {API}
Styling: Tailwind v{version}, {token system description}
```

## Notes

- Do NOT read entire files when exploring. Use directory listings and targeted reads.
- This command is preparation — do not make any changes to the codebase.
- If expected patterns are missing (e.g., no authFetch found), note it as a gap.
