# Security Audit

Scan the codebase for common security issues.

## Checks

Run each check and report findings. Use Grep for pattern matching across the codebase.

### 1. Hardcoded Secrets
Search for patterns that suggest hardcoded secrets:
- `password\s*=\s*["']` (but ignore test fixtures and schema definitions)
- `api_key\s*=\s*["']`
- `secret\s*=\s*["']`
- `token\s*=\s*["'](?!{)` (ignore template variables)
- `sk-[a-zA-Z0-9]` (OpenAI-style keys)
- `Bearer [a-zA-Z0-9]` (hardcoded bearer tokens)
Report file and line for each finding. Exclude test files and example configs from critical findings.

### 2. Git-Tracked Secrets
- Check if `.env` is in `.gitignore`
- Check if any `.env*` files are tracked: `git ls-files '*.env*'`
- Check if `credentials.json`, `service-account.json`, or similar are tracked

### 3. SQL Injection
Search backend Python files for unsafe SQL patterns:
- `f".*SELECT.*{` or `f".*INSERT.*{` — f-strings in SQL
- `.format(` near SQL keywords
- `sa.text(` with f-string or `.format()` arguments
- Verify that any `LIKE`/`ILIKE` queries use `escape_like()`

### 4. Auth and Rate Limiting
- Check that auth endpoints exist and use rate limiting
- Check that `HTTPBearer` uses `auto_error=False`
- Check that password hashing uses bcrypt (not MD5/SHA)

### 5. CORS Configuration
- Find CORS middleware configuration
- Check that `allow_origins` is not set to `["*"]` in production config
- Check that `allow_credentials` is appropriate

### 6. Frontend XSS
Search frontend files for:
- `dangerouslySetInnerHTML` — must have DOMPurify sanitization
- `innerHTML` assignments
- Unsanitized URL construction from user input

### 7. Dependency Vulnerabilities
- If `pip-audit` is available: `cd backend && pip-audit --desc`
- If `npm audit` is available: `cd frontend && npm audit --omit=dev`
Skip if tools are not installed.

## Output

Report findings in three categories:
- **CRITICAL** — must fix before shipping (hardcoded secrets, SQL injection, missing auth)
- **WARNING** — should fix (missing rate limits, loose CORS, no sanitization)
- **INFO** — best practice recommendations

End with a summary count: `X critical, Y warnings, Z info`.
