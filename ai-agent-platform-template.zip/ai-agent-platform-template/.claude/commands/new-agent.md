# New Agent Scaffolding

Scaffold a new AI agent with prompt, schema, service, and judge.

## Steps

1. **Gather input.** If $ARGUMENTS is provided, parse it as the agent name. Otherwise, ask the user:
   - Agent name (snake_case, e.g. `summarizer`)
   - Agent purpose (one sentence describing what it does)
   - Input type (what does it receive?)
   - Output type (what does it produce?)

2. **Run the scaffolding CLI:**
   ```
   cd backend && python cli.py new-agent
   ```
   Provide the agent name when prompted.

3. **Verify generated files.** The scaffold should create under `backend/app/ai/agents/{agent_name}/`:
   - `__init__.py`
   - `prompt.py` — system prompt template
   - `schema.py` — structured output schema
   - `service.py` — agent execution service
   - List what was generated and flag anything missing.

4. **Customize the prompt.** Read the generated `prompt.py` and update the system prompt to reflect the agent's described purpose. Include:
   - Clear role definition
   - Input/output format expectations
   - Quality criteria
   - Edge case handling instructions

5. **Ask about blueprint integration.** Ask the user if this agent should be added to the blueprint state machine. If yes, identify where in the pipeline it fits and update the blueprint configuration.

6. **Run validation:**
   ```
   cd backend && python -m ruff check app/ai/agents/{agent_name}/ && python -m mypy app/ai/agents/{agent_name}/
   ```

7. **Report** what was created and suggest next steps (write tests, add eval cases, tune the prompt).
