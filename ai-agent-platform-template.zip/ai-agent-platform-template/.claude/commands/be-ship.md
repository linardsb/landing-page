# Backend Ship — Full Quality Pipeline

Run the complete backend quality pipeline. Fix any issues found. Gate on all checks passing.

## Steps

1. **Run `/be-validate`.** Execute the full backend validation pipeline:
   - Format check (`ruff format --check`)
   - Lint check (`ruff check`)
   - MyPy type check
   - Pyright type check
   - Unit tests
   Record which checks pass and which fail.

2. **Run `/review` on changed files.** Review all uncommitted or recently committed changes:
   - Run `git diff HEAD~1` (or appropriate diff) to identify changed files.
   - Apply the full code review checklist to each changed file.
   - Classify findings as CRITICAL (must fix), WARNING (should fix), or INFO (nice to have).

3. **Fix critical findings.** For each CRITICAL finding from the review:
   - Run `/be-code-review-fix` with the finding description.
   - Confirm the fix passes validation.

4. **Fix validation failures.** For each failing check from step 1:
   - Diagnose and fix the issue.
   - Re-run the specific check to confirm it passes.

5. **Final validation gate.** Run `/be-validate` again — all checks must pass:
   - Format: PASS
   - Lint: PASS
   - MyPy: PASS
   - Pyright: PASS
   - Tests: PASS
   If any check still fails, loop back to step 4 (max 2 iterations).

6. **Ship readiness report:**

```
BACKEND SHIP REPORT
====================
Format:      PASS/FAIL
Lint:        PASS/FAIL
MyPy:        PASS/FAIL
Pyright:     PASS/FAIL
Tests:       PASS/FAIL
Review:      {N} critical / {N} warnings / {N} info

Critical fixes applied: {list or "none"}
Warning fixes applied: {list or "none"}
Remaining warnings: {list or "none"}

Overall: READY TO SHIP / NOT READY
```

If not ready, list the remaining blockers in priority order.

## Rules

- All 5 validation checks must pass before declaring "ready to ship".
- Critical review findings are blockers — they must be fixed.
- Warnings are not blockers but should be noted for follow-up.
- Do not skip type checking even if tests pass — type safety is a hard requirement.
- If fixes create new issues (regression), flag this immediately.
