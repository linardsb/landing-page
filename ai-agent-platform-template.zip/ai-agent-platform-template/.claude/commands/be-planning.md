# Backend Planning — Create Implementation Plan

Research the codebase and create a detailed implementation plan for a backend feature or change.

## Input

$ARGUMENTS — Description of the feature or change to plan. If empty, ask the user what they want to build.

## Steps

1. **Research the codebase.** Before writing any plan:
   - Use `grep` and `glob` to find related code — do NOT read entire files during research.
   - Identify existing modules, services, and utilities that relate to this feature.
   - Find similar patterns already implemented (pick the closest feature slice as a reference).
   - Check `backend/app/core/config.py` for relevant feature flags.
   - Check for potential conflicts with existing routes, models, or service methods.

2. **Determine the scope.** Classify the change:
   - **New feature slice** — needs full vertical slice (schemas, models, repo, service, routes, tests)
   - **Extension** — adds to an existing feature slice
   - **Cross-cutting** — modifies shared/core modules
   - **AI agent** — follows BaseAgentService pattern
   - **Refactor** — restructures existing code without new behavior

3. **Write the plan** to `.agents/plans/{feature-slug}.md`:

```markdown
# Plan: {Feature Name}

## Goal
{One sentence: what this achieves and why it matters}

## Context
{What exists today. What patterns to follow. Reference specific files.}

## Files to Create
- `backend/app/{feature}/schemas.py` — request/response models
- `backend/app/{feature}/models.py` — ORM models
- `backend/app/{feature}/repository.py` — DB operations
- `backend/app/{feature}/service.py` — business logic
- `backend/app/{feature}/exceptions.py` — error classes
- `backend/app/{feature}/routes.py` — API endpoints
- `backend/app/{feature}/tests/test_{feature}_service.py` — unit tests
{Adjust list based on scope — not all changes need every file.}

## Files to Modify
- `backend/app/main.py` — register router (if new feature)
- `backend/app/core/config.py` — add feature flag (if needed)
- {Other files with specific description of what changes}

## Implementation Steps
{Ordered by dependency. Each step should be independently testable where possible.}

1. **{Step name}** — {description}
   - Files: {list}
   - Depends on: {previous step number, or "none"}

2. **{Step name}** — {description}
   - Files: {list}
   - Depends on: {previous step number}

{Continue for all steps}

## Security Checklist
- [ ] Auth dependency on all protected routes (`get_current_user` or role-specific)
- [ ] Rate limiting on public-facing endpoints
- [ ] Input validation via Pydantic schemas (not manual checks)
- [ ] `escape_like()` for any LIKE/ILIKE queries
- [ ] Parameterized SQL (no f-strings in queries)
- [ ] AppError subclasses for all error conditions (no bare Exception)
- [ ] Structured logging with `get_logger` (no print statements)
- [ ] No hardcoded secrets or config values

## Testing Strategy
- Unit tests: {what service/business logic to test}
- Edge cases: {boundary conditions, error paths}
- Integration tests: {if DB required, mark with @pytest.mark.integration}
- Verification commands: `make test`, `make types`

## Open Questions
- {Anything that needs user input before starting}
```

4. **Cross-reference anti-patterns.** Review the plan against `@_shared/python-anti-patterns` and flag any steps that risk violating those patterns.

5. **Present the plan** to the user. Ask if anything should be adjusted before execution.

## Rules

- Steps must be in dependency order.
- Be specific about file paths — use full paths from project root.
- Reference existing code patterns: "follow the pattern in `app/{existing_feature}/service.py`".
- If the change is large (>8 steps), suggest splitting into multiple PRs.
- For new AI agents, include the agent registration, prompt template, and judge criteria in the plan.
