# Frontend Validation

Run all frontend quality checks and report pass/fail for each.

## Steps

Run each check sequentially. Report pass/fail status after each step. Do not stop on first failure — run all checks and report a full summary.

1. **TypeScript type check** — `cd frontend && npx tsc --noEmit`
   - If this fails, show the type errors grouped by file.
2. **Lint check** — `cd frontend && npx next lint`
   - If this fails, show the lint errors.
3. **Unit tests** — Check if a test config exists (`vitest.config.ts` or similar), then run `cd frontend && npx vitest run`.
   - If no test config exists, note "No test runner configured" and skip.
   - If tests fail, show the failing test and its output.

## Summary

After all steps, output a summary table:

```
Step             Status
───────────────────────
TypeScript       PASS/FAIL
Lint             PASS/FAIL
Tests            PASS/FAIL/SKIPPED
```

If any step failed, provide a prioritized list of what to fix first.
