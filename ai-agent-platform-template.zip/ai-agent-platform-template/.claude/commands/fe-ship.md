# Frontend Ship — Full Quality Pipeline

Run the complete frontend quality pipeline. Fix any issues found. Gate on all checks passing.

## Steps

1. **Run `/fe-validate`.** Execute the full frontend validation pipeline:
   - TypeScript type check (`tsc --noEmit`)
   - Lint check (`next lint`)
   - Unit tests (if configured)
   Record which checks pass and which fail.

2. **Run `/review` on changed files.** Review all uncommitted or recently committed changes:
   - Run `git diff HEAD~1` (or appropriate diff) to identify changed frontend files.
   - Apply the full code review checklist to each changed file.
   - Classify findings as CRITICAL (must fix), WARNING (should fix), or INFO (nice to have).

3. **Fix critical findings.** For each CRITICAL finding:
   - Run `/fe-code-review-fix` with the finding description.
   - Confirm the fix passes validation.

4. **Fix validation failures.** For each failing check from step 1:
   - Diagnose and fix the issue.
   - Re-run the specific check to confirm it passes.

5. **Final validation gate.** Run `/fe-validate` again — all checks must pass:
   - TypeScript: PASS
   - Lint: PASS
   - Tests: PASS (or SKIPPED if not configured)
   If any check still fails, loop back to step 4 (max 2 iterations).

6. **Ship readiness report:**

```
FRONTEND SHIP REPORT
=====================
TypeScript:  PASS/FAIL
Lint:        PASS/FAIL
Tests:       PASS/FAIL/SKIPPED
Review:      {N} critical / {N} warnings / {N} info

Critical fixes applied: {list or "none"}
Warning fixes applied: {list or "none"}
Remaining warnings: {list or "none"}

Overall: READY TO SHIP / NOT READY
```

If not ready, list the remaining blockers in priority order.

## Rules

- All validation checks must pass before declaring "ready to ship".
- Critical review findings are blockers — they must be fixed.
- Warnings are not blockers but should be noted for follow-up.
- If fixes create new issues (regression), flag this immediately.
- Primitive Tailwind color usage is a CRITICAL finding — must be replaced with semantic tokens.
