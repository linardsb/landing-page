# Backend Validation

Run all backend quality checks and report pass/fail for each.

## Steps

Run each check sequentially. Report pass/fail status after each step. Do not stop on first failure — run all checks and report a full summary.

1. **Format check** — `cd backend && python -m ruff format --check .`
   - If this fails, show which files need formatting.
2. **Lint check** — `cd backend && python -m ruff check .`
   - If this fails, show the lint errors grouped by rule.
3. **MyPy type check** — `cd backend && python -m mypy app/`
   - If this fails, show the type errors.
4. **Pyright type check** — `cd backend && python -m pyright app/`
   - If this fails, show the type errors.
5. **Unit tests** — `cd backend && python -m pytest tests/ -x -q`
   - If this fails, show the failing test and its output.

## Summary

After all steps, output a summary table:

```
Step             Status
───────────────────────
Format           PASS/FAIL
Lint             PASS/FAIL
MyPy             PASS/FAIL
Pyright          PASS/FAIL
Tests            PASS/FAIL
```

If any step failed, provide a prioritized list of what to fix first (type errors before lint, tests before formatting).
