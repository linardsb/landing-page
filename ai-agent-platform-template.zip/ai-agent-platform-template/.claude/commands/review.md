# Code Review

Review changed files against the project's quality standards.

## Steps

1. Run `git diff` to see unstaged changes, and `git diff --staged` for staged changes. If a branch name is provided as $ARGUMENTS, diff against that branch instead.
2. For each changed file, check the following:

### Backend (Python files)
- [ ] All functions have complete type annotations (params + return)
- [ ] Error handling uses `AppError` hierarchy — no bare `Exception`
- [ ] Logging uses `get_logger` with `domain.action_state` event names
- [ ] No hardcoded secrets, API keys, or passwords
- [ ] SQL queries use parameterized queries (no f-strings or `.format()` in queries)
- [ ] Repository layer has no business logic (DB operations only)
- [ ] Service layer handles validation and business logic
- [ ] Routes are thin — delegate to service, handle HTTP concerns only
- [ ] New endpoints have rate limiting where appropriate

### Frontend (TypeScript/TSX files)
- [ ] Uses semantic Tailwind tokens, not primitive colors
- [ ] API calls use `authFetch`, data fetching uses SWR hooks
- [ ] No `setState` in `useEffect`
- [ ] No component definitions nested inside other components
- [ ] No `dangerouslySetInnerHTML` without sanitization

### Tests
- [ ] Happy path tested
- [ ] Error/edge cases tested
- [ ] Integration tests marked with `@pytest.mark.integration`
- [ ] Uses factory functions for test data
- [ ] Mocks use `AsyncMock` for async functions

### General
- [ ] No TODO/FIXME without a linked issue or explanation
- [ ] No debug prints or console.logs left in
- [ ] Imports are clean (no unused imports)

3. Output findings as a checklist with pass/fail status and specific file:line references for any issues found.
4. End with an overall assessment: APPROVE, REQUEST CHANGES, or COMMENT.
