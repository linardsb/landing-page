# Ship Checklist

Full quality pipeline before shipping. Run all checks and report readiness.

## Steps

1. **Backend validation.** Run the full backend validation pipeline:
   - `cd backend && python -m ruff format --check .`
   - `cd backend && python -m ruff check .`
   - `cd backend && python -m mypy app/`
   - `cd backend && python -m pyright app/`
   - `cd backend && python -m pytest tests/ -x -q`

2. **Frontend validation.** Run the full frontend validation pipeline:
   - `cd frontend && npx tsc --noEmit`
   - `cd frontend && npx next lint`
   - Check for and run tests if configured.

3. **Working tree check.** Run `git status` to check for:
   - Uncommitted changes (warn if any)
   - Untracked files that should be committed or gitignored

4. **Commit history check.** Run `git log --oneline -10` and verify:
   - Commits follow conventional commit format
   - No WIP or fixup commits that should be squashed

5. **Security quick check.** Grep for obvious issues:
   - Hardcoded API keys or tokens in code
   - `.env` files tracked by git
   - `console.log` or `print()` debug statements left in

6. **Summary.** Output a ship-readiness report:

```
Ship Readiness Report
=====================
Backend Format:     PASS/FAIL
Backend Lint:       PASS/FAIL
Backend Types:      PASS/FAIL
Backend Tests:      PASS/FAIL
Frontend Types:     PASS/FAIL
Frontend Lint:      PASS/FAIL
Frontend Tests:     PASS/FAIL/SKIP
Working Tree:       CLEAN/DIRTY
Commit History:     OK/NEEDS CLEANUP
Security:           OK/WARNINGS

Overall: READY TO SHIP / NOT READY
```

If not ready, list blockers in priority order.
