# Session Init — Index & Orient

Bootstrap context at the start of every new session. Fast orientation without reading entire files.

## Step 1: Project Structure

1. List top-level directories to understand layout
2. List `backend/app/` to identify all feature slices
3. List `backend/app/ai/agents/` to identify all agents
4. List `frontend/src/` to understand frontend structure
5. List `.claude/commands/` to know available slash commands

## Step 2: Load Key Context

1. Read `CLAUDE.md` — project conventions and rules
2. Read `backend/app/core/config.py` — all configuration groups and feature toggles
3. Read `backend/app/core/exceptions.py` — error hierarchy
4. Read `backend/app/main.py` — registered routers and enabled subsystems

## Step 3: Quick Orient

Using grep/glob (no full file reads):
1. Find all route files: `glob("backend/app/**/routes.py")`
2. Find all agent services: `glob("backend/app/ai/agents/*/service.py")`
3. Find all models: `glob("backend/app/**/models.py")`
4. Check git status for any in-progress work

## Step 4: Report

Print a brief summary:
- Feature slices found (list names)
- AI agents found (list names)
- Frontend routes found
- In-progress changes (from git status)
- Available slash commands
- Ready status

Do NOT read entire codebases. Just orient and report.
