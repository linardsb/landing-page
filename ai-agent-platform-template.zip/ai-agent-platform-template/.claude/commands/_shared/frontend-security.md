# Frontend Security Patterns

Apply these rules to all frontend code. Violations are blocking issues in code review.

## Authentication and API Calls

- **All API calls through `authFetch`** — Never use raw `fetch()` or `axios` for authenticated endpoints. `authFetch` handles token attachment, refresh, and error handling.
- **Tokens in memory only** — Never store auth tokens in `localStorage` or `sessionStorage`. Tokens live in memory (React state/context) and are refreshed via httpOnly cookies or server-side sessions.
- **No secrets in client bundle** — Only `NEXT_PUBLIC_` env vars are safe for the client. API keys, database URLs, and internal service URLs must stay server-side.

## HTML and Content Injection

- **DOMPurify on user-generated HTML** — Any use of `dangerouslySetInnerHTML` MUST sanitize with DOMPurify first. No exceptions.
- **Sandboxed iframes for previews** — User-provided HTML previews must render in iframes with `sandbox` attribute. Use `sandbox="allow-same-origin"` at most — never `allow-scripts` for user content.
- **Block event handler attributes** — Strip `on*` attributes (onclick, onerror, onload, etc.) from any user-provided content.

## CSS Safety

- **Sanitize CSS values** — Block `expression()`, `behavior:`, `javascript:`, `-moz-binding`, and `url()` with non-http schemes in any user-provided CSS.
- **No inline styles from user input** — If applying user-chosen styles, use a whitelist of allowed CSS properties.

## Input Handling

- **Validate inputs client-side AND server-side** — Client validation is for UX; server validation is for security. Never skip server validation because "the client already checks."
- **No `as any` type assertions** — These bypass TypeScript's type safety. Use proper type narrowing, generics, or type guards instead. If truly needed, add a comment explaining why.

## Data Handling

- **Encode output in templates** — React's JSX auto-escapes by default. Never bypass this with string concatenation or template literals injected into the DOM.
- **Validate URLs before navigation** — Check that URLs start with `https://` or `/` before using them in `href`, `src`, or `window.location`. Block `javascript:` and `data:` schemes.
