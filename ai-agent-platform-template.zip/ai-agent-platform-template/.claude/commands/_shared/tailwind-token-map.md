# Tailwind Semantic Token Map

NEVER use primitive Tailwind colors. ALWAYS use semantic tokens that respect the design system and dark mode.

## Color Token Rules

### Text Colors
| Primitive (WRONG)         | Semantic (CORRECT)        | Use Case                    |
|---------------------------|---------------------------|-----------------------------|
| `text-gray-900`           | `text-foreground`         | Primary text                |
| `text-gray-500`           | `text-muted-foreground`   | Secondary/helper text       |
| `text-gray-400`           | `text-muted-foreground`   | Placeholder text            |
| `text-blue-600`           | `text-primary`            | Links, active states        |
| `text-red-600`            | `text-destructive`        | Error messages              |
| `text-green-600`          | `text-success`            | Success messages            |
| `text-yellow-600`         | `text-warning`            | Warning messages            |

### Background Colors
| Primitive (WRONG)         | Semantic (CORRECT)        | Use Case                    |
|---------------------------|---------------------------|-----------------------------|
| `bg-white`                | `bg-background`           | Page background             |
| `bg-gray-50`              | `bg-muted`                | Subtle backgrounds          |
| `bg-gray-100`             | `bg-surface`              | Card/panel backgrounds      |
| `bg-blue-600`             | `bg-primary`              | Primary buttons/badges      |
| `bg-red-600`              | `bg-destructive`          | Destructive actions         |
| `bg-green-50`             | `bg-success/10`           | Success banners             |

### Border Colors
| Primitive (WRONG)         | Semantic (CORRECT)        | Use Case                    |
|---------------------------|---------------------------|-----------------------------|
| `border-gray-200`         | `border-border`           | Default borders             |
| `border-gray-300`         | `border-input`            | Input field borders         |
| `border-blue-500`         | `border-ring`             | Focus rings                 |

## Dark Mode

Dark mode is handled automatically via CSS custom properties. When you use `text-foreground`, it resolves to the correct color in both light and dark modes. Primitive colors like `text-gray-900` do NOT adapt.

## Ring and Focus

- Use `ring-ring` for focus rings, not `ring-blue-500`.
- Use `focus-visible:ring-ring` pattern for keyboard focus.

## Spacing and Typography

- Use consistent spacing scale (multiples of 0.5rem / 2 / 4).
- Use design system font tokens, not arbitrary font families.
- Named container sizes collapse in Tailwind v4 — use explicit rem values for max widths.
