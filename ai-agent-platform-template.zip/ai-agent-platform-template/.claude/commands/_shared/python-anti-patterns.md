# Python Anti-Patterns

When reviewing or writing Python code, watch for and avoid these patterns.

## Error Handling

- **Bare `except Exception`** — Always use the project's `AppError` hierarchy. Catch specific error types, not everything.
- **Catching and silencing errors** — Never `except: pass`. At minimum, log the error with structured logging before deciding how to handle it.
- **Raising bare `Exception`** — Define feature-specific error classes that inherit from `AppError`.

## SQL and Database

- **String formatting in SQL** — Never use f-strings, `.format()`, or `%` in SQL queries. Use parameterized queries with bind parameters.
- **LIKE without escaping** — Always use `escape_like()` for user input in LIKE/ILIKE patterns to prevent wildcard injection.
- **Business logic in repository layer** — Repository methods do database operations ONLY. Validation, transformations, and orchestration belong in the service layer.

## Architecture

- **HTTP concerns in service layer** — Services should not know about HTTP status codes, request objects, or response formatting. That belongs in routes.
- **`from x import *`** — Always use explicit imports. Star imports pollute the namespace and make dependencies unclear.
- **Mutable default arguments** — Never use `[]` or `{}` as default parameter values. Use `None` and create inside the function body.

## Configuration and Logging

- **Hardcoded config values** — Use the Settings/config system for anything environment-dependent. No magic strings for URLs, ports, feature flags.
- **`print()` instead of structured logging** — Always use `get_logger` with `domain.action_state` event naming (e.g., `projects.create_completed`).
- **Missing type annotations** — All function parameters and return types must be annotated. No exceptions.

## Testing

- **Testing implementation details** — Test behavior and contracts, not internal method calls.
- **Shared mutable state between tests** — Each test should set up and tear down its own state. Use factory functions for test data.
