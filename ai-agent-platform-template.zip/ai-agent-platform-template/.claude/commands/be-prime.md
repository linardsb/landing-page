# Backend Prime — Load Full Backend Context

Load and summarize the backend project structure, conventions, and key patterns so subsequent commands have full context.

## Steps

1. **Read project conventions.** Read `CLAUDE.md` at the project root for coding standards, architecture rules, and command reference.

2. **Explore backend structure.** List the top-level directory structure of `backend/app/` to identify all feature slices and shared modules.

3. **Identify feature slices.** List all directories under `backend/app/` and classify each as:
   - **Core module** (core/, shared/) — infrastructure, base classes, utilities
   - **Feature slice** — vertical slice with its own schemas/models/service/routes
   - **AI module** (ai/) — agents, blueprints, evals
   - **Other** — describe its role

4. **Load configuration.** Read `backend/app/core/config.py` to understand:
   - Settings structure (nested Pydantic settings)
   - Feature flags and their env var names
   - Database, Redis, AI provider configuration

5. **Load error hierarchy.** Read `backend/app/core/exceptions.py` to understand:
   - Base `AppError` class and its attributes
   - Standard error subclasses (NotFoundError, ValidationError, AuthError, etc.)
   - How HTTP status codes are mapped

6. **Understand vertical slice pattern.** Pick one well-implemented feature slice and read its file listing. Confirm the standard file order:
   - `schemas.py` — Pydantic request/response models
   - `models.py` — SQLAlchemy ORM models with mixins
   - `repository.py` — database operations only
   - `service.py` — business logic, validation, logging
   - `exceptions.py` — feature-specific AppError subclasses
   - `routes.py` — thin FastAPI router
   - `tests/` — unit and integration tests

7. **Understand AI agent pattern.** If an `ai/` module exists, explore its structure:
   - Base agent service class and its interface
   - Agent registry and routing
   - Blueprint/orchestration engine
   - How agents are configured and invoked

8. **Load shared patterns.** Search for these key utilities and note where they live:
   - `TimestampMixin`, `SoftDeleteMixin` — ORM mixins
   - `PaginationParams` — pagination schema
   - `escape_like` — SQL LIKE escaping
   - `get_logger` — structured logging factory
   - `get_db` — database session dependency
   - Auth dependencies and role checking

9. **Output context summary.** Print a structured summary:

```
BACKEND CONTEXT LOADED
======================
Feature Slices: {list}
Core Modules: {list}
Config: {settings class name}, {number of feature flags}
Error Hierarchy: {base class} -> {list of standard errors}
Shared Utilities: {list with import paths}
AI Agents: {list if present, or "none"}
Vertical Slice Pattern: confirmed/issues found
```

## Notes

- Do NOT read entire files when exploring. Use file listings and targeted reads.
- This command is preparation — do not make any changes to the codebase.
- If any expected pattern is missing, note it in the summary as a gap.
