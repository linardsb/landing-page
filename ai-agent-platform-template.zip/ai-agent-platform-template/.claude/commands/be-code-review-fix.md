# Backend Code Review Fix — Diagnose and Fix Issues

Diagnose a backend issue (bug, review finding, test failure, type error) and fix it with full verification.

## Input

$ARGUMENTS — Description of the issue to fix. Can be:
- A review finding (e.g., "missing auth on /api/v1/projects endpoint")
- A test failure (e.g., "test_create_project fails with ValidationError")
- A type error (e.g., "mypy error in app/projects/service.py line 42")
- A bug report (e.g., "duplicate entries created when concurrent requests hit POST /items")

If empty, ask the user to describe the issue.

## Steps

1. **Classify the issue.** Determine which category:
   - **Bug** — incorrect runtime behavior
   - **Review finding** — code quality or security concern
   - **Test failure** — a test is failing
   - **Type/lint error** — mypy, pyright, or ruff is reporting errors
   This affects the diagnosis and verification approach.

2. **Research.** Trace the issue across the codebase:
   - Use `grep` and `glob` to find relevant code — do not read entire files.
   - For bugs: trace the code path from route -> service -> repository.
   - For test failures: read the failing test AND the code it tests.
   - For type errors: read the specific file and line, plus any types it imports.
   - For review findings: read the flagged code and its surrounding context.

3. **Root cause analysis.** Before writing any fix, state:
   - **What is happening** — the observed behavior or error
   - **Why it is happening** — the underlying cause
   - **Where the fix belongs** — which file(s) and which layer

4. **Implement the fix.**
   - Make the minimal change that addresses the root cause.
   - Do not introduce unrelated changes.
   - Follow the project's patterns (AppError hierarchy, structured logging, type annotations).

5. **Verify with the validation pyramid.** Run checks from fastest to slowest, stopping to fix if any fail:

   a. **Format and lint:**
      ```
      cd backend && python -m ruff format --check {changed_files}
      cd backend && python -m ruff check {changed_files}
      ```
      If failures, fix them first.

   b. **Type checking on affected module:**
      ```
      cd backend && python -m mypy app/{affected_module}/
      ```
      If failures, fix them first.

   c. **Run affected tests:**
      ```
      cd backend && python -m pytest {test_file} -x -q
      ```
      If the original failing test now passes and no new failures, continue.

   d. **Run full test suite** (if the change is cross-cutting):
      ```
      cd backend && python -m pytest tests/ -x -q
      ```

6. **Report:**

```
ISSUE FIXED
===========
Classification: {bug/review finding/test failure/type error}
Root Cause: {one sentence}
Fix Applied: {what was changed and why}
Files Changed: {list}
Verification:
  Format/Lint: PASS
  Types: PASS
  Tests: PASS
Risk Assessment: {LOW/MEDIUM/HIGH — could this fix break something else?}
```

## Rules

- Always diagnose before fixing. Never guess-and-check.
- Minimal fixes only — do not refactor unrelated code.
- If the root cause is in a different layer than where the symptom appears, fix the root cause, not the symptom.
- If the fix requires a design decision, present options to the user before implementing.
