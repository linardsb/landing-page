# New Feature Scaffolding

Scaffold a new vertical slice feature with all required layers.

## Steps

1. **Gather input.** If $ARGUMENTS is provided, use it as the feature name. Otherwise, ask the user:
   - Feature name (snake_case, e.g. `notifications`)
   - Brief description of what this feature does

2. **Run the scaffolding CLI:**
   ```
   cd backend && python cli.py new-feature
   ```
   Provide the feature name when prompted.

3. **Verify generated files.** The scaffold should create under `backend/app/{feature_name}/`:
   - `__init__.py`
   - `schemas.py` — Pydantic request/response models
   - `models.py` — SQLAlchemy ORM models
   - `repository.py` — database operations
   - `service.py` — business logic
   - `exceptions.py` — feature-specific AppError subclasses
   - `routes.py` — FastAPI router
   - List what was generated and flag anything missing.

4. **Register the router.** Check `backend/app/main.py` for router registration. If the new feature's router is not included, add it:
   ```python
   from app.{feature_name}.routes import router as {feature_name}_router
   app.include_router({feature_name}_router, prefix="/api/v1/{feature_name}", tags=["{feature_name}"])
   ```

5. **Create initial migration:**
   ```
   cd backend && alembic revision --autogenerate -m "add {feature_name} tables"
   ```

6. **Run validation** to confirm everything compiles:
   ```
   cd backend && python -m ruff check app/{feature_name}/ && python -m mypy app/{feature_name}/
   ```

7. **Report** what was created and suggest next steps (define models, implement service methods, add tests).
