# Conventional Commit

Create a well-structured conventional commit for staged changes.

## Steps

1. Run `git status` to see the current working tree state.
2. Run `git diff --staged` to see what is staged. If nothing is staged, show the user what files are modified and ask which to stage.
3. Run `git log --oneline -10` to see recent commit style.
4. Analyze the staged diff and draft a commit message following **conventional commits**:
   - `feat:` — new feature
   - `fix:` — bug fix
   - `refactor:` — code restructuring (no behavior change)
   - `test:` — adding or updating tests
   - `docs:` — documentation only
   - `chore:` — build, CI, tooling, dependency updates
   - `perf:` — performance improvement
   - `style:` — formatting (no logic change)
   - Include scope when clear: `feat(auth):`, `fix(projects):`
   - Body should explain **why**, not what (the diff shows what)
5. Present the draft commit message to the user and ask for confirmation or edits.
6. Once confirmed, create the commit. Use a HEREDOC for the message to preserve formatting.
7. Run `git status` after to confirm the commit succeeded.

## Rules

- Never stage files that look like secrets (`.env`, credentials, API keys).
- If the diff is large, summarize by area rather than listing every change.
- Keep the subject line under 72 characters.
- Use imperative mood: "add feature" not "added feature".
