# Session Handoff

Write a HANDOFF.md file for seamless session continuation.

## Steps

1. **Gather context.** Collect information about the current session:
   - Run `git diff --stat` to see what files were modified
   - Run `git log --oneline -5` to see recent commits
   - Run `git status` to see uncommitted work
   - Check for any failing tests: `cd backend && python -m pytest tests/ -x -q --tb=no 2>&1 | tail -5`

2. **Write HANDOFF.md** at the project root with this structure:

```markdown
# Session Handoff — {date}

## Current Task
{What was being worked on and its current status: in progress / blocked / complete}

## Modified Files
{List of files changed in this session, grouped by feature area}

## Recent Commits
{Last 3-5 commits from this session}

## Uncommitted Changes
{Summary of any unstaged/uncommitted work}

## Test Status
{Which tests pass, which fail, any skipped}

## Key Decisions
{Important architectural or implementation decisions made during this session}

## Known Issues
{Any bugs, edge cases, or tech debt introduced}

## Next Steps
{Prioritized list of what to do next}
```

3. **Confirm** with the user that the handoff captures everything important. Adjust if needed.

## Rules

- Be specific about file paths (absolute paths).
- For "Key Decisions", include the reasoning, not just the decision.
- For "Next Steps", be actionable — someone should be able to pick this up cold.
- Do NOT commit the HANDOFF.md unless the user asks.
