# Frontend Execute — Implement from Plan

Execute a previously created frontend implementation plan step by step.

## Input

$ARGUMENTS — Name of the plan file (without path or extension). Looks for `.agents/plans/{name}.md` or `.agents/plans/{name}-fe.md`. If empty, list available plans in `.agents/plans/` and ask the user which one to execute.

## Steps

1. **Load the plan.** Read the plan file. Confirm it has:
   - Implementation steps with file lists
   - Clear dependency order (types -> hooks -> components -> pages)
   - Security checklist
   If the plan is incomplete, warn the user and suggest running `/fe-planning` first.

2. **Check API dependencies.** If the plan lists backend endpoints:
   - Verify they exist (check `backend/app/*/routes.py` or equivalent)
   - If endpoints are missing, warn the user — frontend work can proceed with mock data but will need backend support.

3. **Execute each step in order.** For each implementation step:

   a. **Announce** what you are about to do: "Step {N}/{total}: {step name}"

   b. **Implement** the changes described in the step. Follow these conventions:
      - React 19 patterns: no `setState` in `useEffect`, no component definitions inside components
      - `authFetch` for all API calls, SWR hooks for data fetching
      - Semantic Tailwind tokens only (reference `@_shared/tailwind-token-map`)
      - Proper TypeScript types — no `any`, no type assertions without justification
      - Loading, error, and empty states for all data-driven components
      - Follow the reference pattern identified in the plan

   c. **Verify TypeScript** compiles after each step:
      ```
      cd frontend && npx tsc --noEmit
      ```
      If there are type errors, fix them before moving on.

   d. **Report** step status:
      ```
      Step {N}/{total}: {step name}
      Files changed: {list}
      TypeScript: PASS/FAIL
      Status: DONE / ISSUE (describe)
      ```

4. **Run full validation** after all steps complete:
   ```
   cd frontend && npx tsc --noEmit
   cd frontend && npx next lint
   ```
   If tests are configured: `cd frontend && npx vitest run`
   If any check fails, diagnose and fix before continuing.

5. **Security verification** on all files changed during execution:
   - [ ] No `as any` type assertions
   - [ ] No `dangerouslySetInnerHTML` without DOMPurify
   - [ ] All API calls use `authFetch`
   - [ ] No tokens in localStorage/sessionStorage
   - [ ] Semantic Tailwind tokens only — grep changed files for primitive color patterns (`text-gray-`, `bg-blue-`, `border-red-`, etc.)
   - [ ] No `NEXT_PUBLIC_` env vars containing secrets
   Report any violations and fix them.

6. **Final report:**

```
EXECUTION COMPLETE
==================
Plan: {name}
Steps: {completed}/{total}
Files Created: {list}
Files Modified: {list}
TypeScript: PASS/FAIL
Lint: PASS/FAIL
Tests: PASS/FAIL/SKIPPED
Security: {issues found or "clean"}
```

## Rules

- Do not skip steps or reorder them unless a dependency makes it necessary.
- If a step fails, diagnose and fix before moving to the next step.
- If you discover the plan is missing something (e.g., a type definition), implement it and note it in the report.
- Do not make changes outside the scope of the plan without asking the user.
- If the plan references `@_shared/tailwind-token-map` or `@_shared/frontend-security`, apply those rules during implementation.
