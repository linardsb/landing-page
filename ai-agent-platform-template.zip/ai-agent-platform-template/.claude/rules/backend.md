# Backend Rules

## Type Annotations
- All functions MUST have complete type annotations (parameters and return type)
- Use `from __future__ import annotations` for forward references
- Prefer `list[str]` over `List[str]` (Python 3.12+)
- Use `X | None` over `Optional[X]`

## Structured Logging
- Use `from app.core.logging import get_logger` — never `import logging`
- Log events follow `domain.action_state` pattern:
  - `projects.create_completed`
  - `auth.login_failed`
  - `agents.run_started`
- Include relevant context as structured fields: `logger.info("projects.create_completed", project_id=project.id)`

## Error Handling
- Use `AppError` hierarchy from `app.core.exceptions` — never raise bare `Exception`
- Define feature-specific errors in the feature's `exceptions.py`
- Use `NotFoundError`, `ValidationError`, `AuthorizationError` from core for common cases
- Generic error messages for auth failures ("Invalid email or password")

## Layered Architecture
- **Repository** — database operations ONLY. No business logic, no logging of business events. Returns ORM models.
- **Service** — business logic, validation, authorization checks, structured logging. Calls repository. Returns schemas.
- **Routes** — thin HTTP layer. Parse request, call service, return response. Handle HTTP status codes.

## Database
- Use `get_db` dependency for async database sessions
- Use `escape_like()` from `app.shared.utils` for LIKE/ILIKE queries
- Always use parameterized queries — never f-strings or `.format()` in SQL
- Use `TimestampMixin` from `app.shared.models` for created_at/updated_at

## Config
- Nested Pydantic settings with `env_nested_delimiter="__"`
- Access: `settings.database.url`, `settings.auth.jwt_secret_key`
- Feature flags: `settings.feature.enabled` pattern
