# Frontend Rules

## Styling
- Use semantic Tailwind tokens — NEVER primitive colors (`text-gray-500`, `bg-blue-600`)
- Use design system tokens: `text-foreground`, `bg-background`, `text-muted-foreground`, `bg-primary`
- Named container sizes collapse in Tailwind v4 — use explicit rem values

## Data Fetching
- Use `authFetch` for all API calls (handles auth headers and token refresh)
- Use SWR hooks for data fetching and caching
- Never fetch data inside `useEffect` — use SWR's declarative pattern

## React 19 Patterns
- No `setState` inside `useEffect` — use derived state or server components
- No component definitions nested inside other components — extract to module level
- Use `use()` for promises and context where appropriate

## Components
- Dialog for detail views (not Sheet). Widths: detail=28rem, forms=32rem
- Keep components focused — one responsibility per component
- Extract hooks for complex state logic

## Security
- Never use `dangerouslySetInnerHTML` without DOMPurify sanitization
- Sanitize user input before rendering
- Do not construct URLs from unsanitized user input
