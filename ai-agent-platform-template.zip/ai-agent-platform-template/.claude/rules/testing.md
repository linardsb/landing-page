# Testing Rules

## Test Organization
- Unit tests go in `backend/tests/` mirroring the `app/` structure
- Integration tests are marked with `@pytest.mark.integration`
- Frontend tests co-locate with components or in `__tests__/` directories

## Backend Testing
- Use `AsyncMock` for mocking async database sessions
- Use factory functions (`make_item`, `make_user`, `make_project`) for test data — never raw dict construction
- Save and restore `app.dependency_overrides` in fixtures to avoid test pollution
- Clear auth cache between tests (`clear_user_cache()` if applicable)
- Disable rate limiter in route tests (`limiter.enabled = False`)

## Test Coverage
- Every service method: happy path + at least one error case
- Every route: success response + auth failure + validation error
- Repository methods: basic CRUD + edge cases (not found, duplicate)
- Agent services: mock the LLM call, test pre/post processing

## Assertions
- Use specific assertions (`assert result.name == "expected"`) over generic (`assert result is not None`)
- For error cases, assert the specific exception type and message
- For API routes, assert status code AND response body structure

## Fixtures
- Use `@pytest.fixture` for reusable test data and dependencies
- Scope fixtures appropriately: `session` for expensive setup, `function` for isolated tests
- Use `conftest.py` at the appropriate level for shared fixtures
