# Security Rules

## Secrets
- NEVER hardcode secrets, API keys, or passwords in source code
- NEVER commit `.env` files or credential files
- All secrets come from environment variables via Pydantic settings
- Use `.env.example` with placeholder values for documentation

## Authentication
- HTTPBearer with `auto_error=False` for auth dependencies
- Generic error messages for auth failures ("Invalid email or password")
- Use bcrypt for password hashing — never MD5 or SHA
- Tokens: short-lived access tokens + refresh tokens

## SQL Safety
- Always use parameterized queries — never f-strings or `.format()` in SQL
- Use `escape_like()` from `app.shared.utils` for LIKE/ILIKE patterns
- Use SQLAlchemy ORM methods or `sa.text()` with bound parameters

## Rate Limiting
- Rate limit all public endpoints (login, registration, password reset)
- Rate limit API endpoints to prevent abuse
- Use the rate limiter middleware, not custom logic

## Input Validation
- Validate all user input with Pydantic schemas
- Sanitize HTML input with allowlist-based sanitizer
- Validate file uploads (type, size, content)
- Validate and sanitize URL parameters

## Frontend Security
- Never use `dangerouslySetInnerHTML` without DOMPurify
- Never construct URLs from unsanitized user input
- Use CSP headers in production
- CORS: never use `allow_origins=["*"]` in production

## Dependency Security
- Run `pip-audit` and `npm audit` periodically
- Keep dependencies updated, especially security-related packages
- Pin dependency versions in production
