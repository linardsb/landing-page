# AI Agent Platform Template

A copier template for scaffolding AI agent platforms with FastAPI, Next.js, and vertical slice architecture.

## Prerequisites

- Python 3.12+
- [Copier](https://copier.readthedocs.io/) 9.0+

## Quick Start

Install copier:

```bash
pip install copier
```

Generate a new project from a local clone:

```bash
copier copy /path/to/ai-agent-platform-template my-new-project
```

Or directly from a Git repository:

```bash
copier copy gh:username/ai-agent-platform-template my-new-project
```

Copier will prompt you for configuration values (project name, database type, AI provider, optional features, etc.). Defaults are provided for every question.

## Updating an Existing Project

When the template evolves, pull updates into your generated project:

```bash
cd my-new-project
copier update
```

Copier merges template changes while preserving your local modifications.

## Scaffold CLI

After generating a project, use the built-in CLI to add features and agents:

```bash
cd my-new-project/backend

# Generate a complete vertical slice (models, schemas, repository, service, routes, tests)
python cli.py new-feature invoices

# Generate a complete AI agent (schemas, prompt, service, skills, evals)
python cli.py new-agent summariser
```

## Template Options

| Option | Type | Default | Description |
|---|---|---|---|
| `project_name` | str | My AI Platform | Human-readable project name |
| `project_slug` | str | (auto) | URL-safe slug derived from project_name |
| `description` | str | An AI agent platform... | Short project description |
| `author_name` | str | | Author's full name |
| `author_email` | str | | Author's email address |
| `python_version` | choice | 3.12 | Python version (3.12 or 3.13) |
| `database_type` | choice | postgresql | Primary database (postgresql or sqlite) |
| `use_redis` | bool | true | Include Redis for caching and queues |
| `ai_provider` | choice | openai | Default LLM provider (openai, anthropic, ollama) |
| `include_plugins` | bool | false | Plugin system with sandbox execution |
| `include_workflows` | bool | false | Workflow orchestration support |
| `include_collaboration` | bool | false | Real-time collaboration (WebSocket, CRDT) |
| `include_frontend` | bool | true | Next.js frontend application |

## Project Structure

The generated project follows vertical slice architecture:

```
my-new-project/
  backend/
    app/
      core/           # Shared infrastructure (config, database, logging, exceptions)
      shared/          # Shared models, mixins, utilities
      auth/            # Authentication feature slice
      ai/
        agents/        # AI agent implementations
          base.py      # Base agent service and schemas
          <agent>/     # Per-agent vertical slice
      <feature>/       # Feature vertical slices
    cli.py             # Scaffold CLI
    alembic/           # Database migrations
  frontend/            # Next.js application (if include_frontend)
  docker-compose.yml
  Makefile
```

Each feature slice contains: models, schemas, exceptions, repository, service, routes, dependencies, and tests.

Each agent contains: schemas, prompt builder, service, skills, and evaluation suite.
