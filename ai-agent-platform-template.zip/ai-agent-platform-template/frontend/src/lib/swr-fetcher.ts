import { authFetch } from "./auth-fetch";

export async function fetcher<T>(url: string): Promise<T> {
  return authFetch<T>(url);
}

export async function mutationFetcher<T>(
  url: string,
  { arg }: { arg: unknown }
): Promise<T> {
  return authFetch<T>(url, {
    method: "POST",
    body: JSON.stringify(arg),
  });
}

export async function longMutationFetcher<T>(
  url: string,
  { arg }: { arg: unknown }
): Promise<T> {
  return authFetch<T>(url, {
    method: "POST",
    body: JSON.stringify(arg),
    timeoutMs: 120_000,
  });
}
