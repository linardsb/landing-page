export class ApiError extends Error {
  readonly status: number;
  readonly type: string;

  constructor(status: number, message: string, type: string = "api_error") {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.type = type;
  }

  get isUnauthorized(): boolean {
    return this.status === 401;
  }

  get isNotFound(): boolean {
    return this.status === 404;
  }

  get isValidation(): boolean {
    return this.status === 422;
  }
}
