import { ApiError } from "./api-error";

let _token: string | null = null;

export function setToken(token: string | null): void {
  _token = token;
}

export function getToken(): string | null {
  return _token;
}

const DEFAULT_TIMEOUT_MS = 30_000;

export async function authFetch<T = unknown>(
  url: string,
  options: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const { timeoutMs = DEFAULT_TIMEOUT_MS, ...fetchOptions } = options;

  const headers = new Headers(fetchOptions.headers);
  if (!headers.has("Content-Type") && fetchOptions.body) {
    headers.set("Content-Type", "application/json");
  }
  if (_token && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${_token}`);
  }

  const timeoutController = new AbortController();
  const timeoutId = setTimeout(() => timeoutController.abort(), timeoutMs);

  const signals = [timeoutController.signal];
  if (fetchOptions.signal) {
    signals.push(fetchOptions.signal);
  }

  try {
    const response = await fetch(url, {
      ...fetchOptions,
      headers,
      signal: AbortSignal.any(signals),
    });

    if (!response.ok) {
      let message = `Request failed (${response.status})`;
      let type = "api_error";

      try {
        const body = await response.json();
        if (body.detail) {
          message = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
        }
        if (body.type) {
          type = body.type;
        }
      } catch {
        // Response body not JSON — use default message
      }

      throw new ApiError(response.status, message, type);
    }

    if (response.status === 204) {
      return undefined as T;
    }

    return (await response.json()) as T;
  } finally {
    clearTimeout(timeoutId);
  }
}
