"use client";

import { useState } from "react";
import { toast } from "sonner";
import { useProjects, useCreateProject } from "@/hooks/use-projects";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { Project } from "@/types/api";

export default function DashboardPage() {
  const { data: projects, isLoading, error } = useProjects();
  const { trigger: createProject, isMutating } = useCreateProject();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [name, setName] = useState("");

  async function handleCreate() {
    if (!name.trim()) return;
    try {
      await createProject({ name: name.trim() });
      toast.success("Project created");
      setName("");
      setDialogOpen(false);
    } catch {
      toast.error("Failed to create project");
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage your projects and agents.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>Create Project</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogTitle>New Project</DialogTitle>
            <DialogDescription>
              Give your project a name to get started.
            </DialogDescription>
            <div className="mt-4 flex flex-col gap-4">
              <Input
                label="Project Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="My Project"
              />
              <Button onClick={handleCreate} disabled={isMutating || !name.trim()}>
                {isMutating ? "Creating..." : "Create"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isLoading && (
          <p className="text-sm text-muted-foreground">Loading projects...</p>
        )}
        {error && (
          <p className="text-sm text-destructive">Failed to load projects.</p>
        )}
        {projects?.map((project: Project) => (
          <Card key={project.id}>
            <CardHeader>
              <CardTitle>{project.name}</CardTitle>
              <CardDescription>
                Created {new Date(project.created_at).toLocaleDateString()}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {project.description || "No description"}
              </p>
            </CardContent>
          </Card>
        ))}
        {projects && projects.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No projects yet. Create one to get started.
          </p>
        )}
      </div>
    </div>
  );
}
