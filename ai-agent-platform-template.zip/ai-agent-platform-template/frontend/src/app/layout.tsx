"use client";

import { SWRConfig } from "swr";
import { Toaster } from "sonner";
import "./globals.css";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <SWRConfig
          value={{
            revalidateOnFocus: false,
            dedupingInterval: 5000,
          }}
        >
          {children}
          <Toaster position="bottom-right" richColors />
        </SWRConfig>
      </body>
    </html>
  );
}
