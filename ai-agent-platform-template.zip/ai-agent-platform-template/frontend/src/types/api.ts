export interface Project {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
}

export interface ErrorResponse {
  detail: string;
  type?: string;
}

export interface AgentResponse {
  id: string;
  name: string;
  description: string | null;
  status: "idle" | "running" | "completed" | "failed";
  created_at: string;
  updated_at: string;
}

export interface BlueprintRunResponse {
  id: string;
  blueprint_id: string;
  status: "pending" | "running" | "completed" | "failed";
  result: Record<string, unknown> | null;
  error: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}
