"use client";

import { useCallback, useSyncExternalStore } from "react";
import { authFetch, setToken, getToken } from "@/lib/auth-fetch";

type AuthState = {
  token: string | null;
};

let state: AuthState = { token: null };
const listeners = new Set<() => void>();

function getSnapshot(): AuthState {
  return state;
}

function getServerSnapshot(): AuthState {
  return { token: null };
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit(newState: AuthState): void {
  state = newState;
  setToken(newState.token);
  listeners.forEach((l) => l());
}

interface LoginResponse {
  access_token: string;
}

export function useAuth() {
  const current = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const login = useCallback(async (email: string, password: string) => {
    const data = await authFetch<LoginResponse>("/api/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    emit({ token: data.access_token });
  }, []);

  const logout = useCallback(() => {
    emit({ token: null });
  }, []);

  return {
    token: current.token,
    isAuthenticated: current.token !== null,
    login,
    logout,
    getToken,
  };
}
