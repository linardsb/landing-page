"use client";

import useSWR from "swr";
import useSWRMutation from "swr/mutation";
import { fetcher, mutationFetcher } from "@/lib/swr-fetcher";
import { authFetch } from "@/lib/auth-fetch";
import type { Project } from "@/types/api";

const PROJECTS_KEY = "/api/v1/projects";

export function useProjects() {
  return useSWR<Project[]>(PROJECTS_KEY, fetcher<Project[]>);
}

export function useProject(id: string | undefined) {
  return useSWR<Project>(
    id ? `${PROJECTS_KEY}/${id}` : null,
    id ? () => fetcher<Project>(`${PROJECTS_KEY}/${id}`) : null
  );
}

export function useCreateProject() {
  return useSWRMutation<Project, Error, string, { name: string; description?: string }>(
    PROJECTS_KEY,
    mutationFetcher<Project>
  );
}

export function useDeleteProject() {
  return useSWRMutation<void, Error, string, { id: string }>(
    PROJECTS_KEY,
    async (_url: string, { arg }: { arg: { id: string } }) => {
      await authFetch<void>(`${PROJECTS_KEY}/${arg.id}`, { method: "DELETE" });
    }
  );
}
