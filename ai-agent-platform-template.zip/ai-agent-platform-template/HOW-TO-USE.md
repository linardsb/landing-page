# How to Use This Template

A step-by-step guide to going from this template to a running AI agent platform.

---

## Option A: Use Directly (Clone & Build)

### 1. Prerequisites

- Python 3.12+
- Node.js 20+
- Docker & Docker Compose (for Postgres + Redis)
- An LLM API key (OpenAI, Anthropic, or local Ollama)

### 2. Setup

```bash
# Copy the template
cp -r ai-agent-platform-template my-project
cd my-project

# Create your env file
cp .env.example .env
# Edit .env — set your AI__API_KEY and change AUTH__JWT_SECRET_KEY
```

### 3. Start Infrastructure

```bash
make docker-up          # Starts Postgres + Redis in Docker
```

### 4. Install Dependencies

```bash
# Backend
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"

# Frontend
cd ../frontend
npm install
```

### 5. Run Migrations & Start

```bash
# From project root
make db-migrate         # Create database tables
make dev                # Backend on :8891, Frontend on :3000
```

Open http://localhost:3000 — you should see the landing page.

### 6. Test the API

```bash
# Health check
curl http://localhost:8891/health

# List projects (empty)
curl http://localhost:8891/api/v1/projects

# Create a project
curl -X POST http://localhost:8891/api/v1/projects \
  -H "Content-Type: application/json" \
  -d '{"name": "My First Project", "description": "Testing the platform"}'

# Run the blueprint pipeline (requires AI__API_KEY set)
curl -X POST http://localhost:8891/api/v1/ai/blueprints/run \
  -H "Content-Type: application/json" \
  -d '{"brief": "Check this for quality", "content": "Some content to analyze"}'
```

---

## Option B: Use with Copier (Generate a Customized Project)

```bash
pip install copier
copier copy /path/to/ai-agent-platform-template my-project
```

Copier prompts you to choose:
- Project name & description
- Python version (3.12 or 3.13)
- Database (PostgreSQL or SQLite)
- AI provider (OpenAI, Anthropic, Ollama)
- Optional features: plugins, workflows, collaboration, frontend

Then follow the same setup steps (install deps, docker-up, db-migrate, dev).

---

## Adding Your Own Features

### Scaffold a Feature (Vertical Slice)

```bash
cd backend
python cli.py new-feature invoices
```

This generates 10 files:

```
app/invoices/
├── __init__.py
├── models.py          # SQLAlchemy model with id, name, timestamps, soft delete
├── schemas.py         # Pydantic Create/Update/Response schemas
├── exceptions.py      # InvoiceNotFoundError, InvoiceAccessDeniedError, etc.
├── repository.py      # Async CRUD (get, list, count, create, update, delete)
├── service.py         # Business logic composing the repository
├── routes.py          # FastAPI router with CRUD endpoints
├── dependencies.py    # DI factory: get_invoice_service()
└── tests/
    ├── __init__.py
    └── test_service.py   # Async tests with factory helpers
```

**Then register it in `app/main.py`:**

```python
from app.invoices.routes import router as invoices_router
app.include_router(invoices_router, prefix="/api/v1")
```

**Create a migration:**

```bash
make db-revision       # Prompted for message: "add invoices table"
make db-migrate        # Apply it
```

### Scaffold an AI Agent

```bash
cd backend
python cli.py new-agent summarizer
```

This generates 8 files:

```
app/ai/agents/summarizer/
├── __init__.py
├── schemas.py         # SummarizerRequest, SummarizerResponse
├── prompt.py          # build_system_prompt(), detect_relevant_skills()
├── service.py         # SummarizerService(BaseAgentService) with all hooks
├── skills/
│   └── SKILL.md       # Base skill file with front matter
└── evals/
    ├── __init__.py
    ├── synthetic_data.py   # 3 starter test cases
    └── judge.py            # Judge with 3 criteria
```

**Customize the agent:**

1. Edit `prompt.py` — write the system prompt for your agent's purpose
2. Edit `skills/SKILL.md` — add domain knowledge
3. Add more skill files (e.g., `skills/advanced_techniques.md`) with front matter:
   ```markdown
   ---
   token_cost: 400
   priority: 2
   ---
   # Advanced Summarization Techniques
   ...
   ```
4. Edit `evals/synthetic_data.py` — add 10+ test cases across dimensions
5. Edit `evals/judge.py` — define 5 pass/fail criteria

**Wire it into a blueprint** (optional):

```python
# In app/ai/blueprints/nodes/summarizer_node.py
from app.ai.blueprints.engine import BlueprintNode, NodeContext, NodeResult

class SummarizerNode:
    name = "summarizer"
    node_type = "agentic"

    async def execute(self, context: NodeContext) -> NodeResult:
        service = SummarizerService()
        response = await service.process(SummarizerRequest(content=context.output))
        return NodeResult(status="success", output=response.content)
```

---

## Using Claude Code with This Project

The template includes 10 slash commands and 4 rule files that work with Claude Code.

### Slash Commands (24 total)

**Workflow Track (Backend):**

| Command | What it does |
|---------|-------------|
| `/be-prime` | Load full backend context (structure, config, patterns, agents) |
| `/be-planning` | Research codebase + write implementation plan to `.agents/plans/` |
| `/be-execute` | Execute plan step-by-step with per-step linting + verification |
| `/be-code-review-fix` | Diagnose + root-cause + fix issues with validation pyramid |
| `/be-validate` | Run all backend checks (format, lint, mypy, pyright, tests) |
| `/be-ship` | Full pipeline: validate → review → fix criticals → re-validate |

**Workflow Track (Frontend):**

| Command | What it does |
|---------|-------------|
| `/fe-prime` | Load full frontend context (routes, components, hooks, types, auth) |
| `/fe-planning` | Research + write frontend implementation plan |
| `/fe-execute` | Execute plan step-by-step with per-step tsc verification |
| `/fe-code-review-fix` | Diagnose + fix frontend issues (type errors, lint, visual) |
| `/fe-validate` | Run all frontend checks (tsc, lint, tests) |
| `/fe-ship` | Full frontend pipeline: validate → review → fix → re-validate |

**General Commands:**

| Command | What it does |
|---------|-------------|
| `/session-init` | Orient at session start (index structure, list features/agents, git status) |
| `/commit` | Analyze staged changes, draft conventional commit message |
| `/review` | Code review against quality standards (types, errors, logging, security) |
| `/ship` | Full-stack quality pipeline (backend + frontend) |
| `/new-feature` | Interactive feature scaffolding + router registration + migration |
| `/new-agent` | Interactive agent scaffolding + prompt customization |
| `/plan` | Create structured implementation plan |
| `/handoff` | Generate HANDOFF.md for session continuation |
| `/security-audit` | Scan for secrets, SQL injection, auth issues, XSS |

**Typical workflow:**
```
/session-init          # Orient
/be-prime              # Load backend context
/be-planning           # Plan the feature
/be-execute            # Build it
/be-validate           # Check quality
/be-ship               # Ship it
```

### Shared Includes (referenced by commands)

| File | Used by |
|------|---------|
| `_shared/python-anti-patterns.md` | Backend planning + execution |
| `_shared/tailwind-token-map.md` | Frontend planning + execution |
| `_shared/frontend-security.md` | Frontend planning + execution |

### Rules (Auto-Loaded)

| Rule | Enforces |
|------|----------|
| `.claude/rules/backend.md` | Type annotations, logging conventions, layered architecture |
| `.claude/rules/frontend.md` | Semantic Tailwind tokens, SWR patterns, React 19 rules |
| `.claude/rules/testing.md` | pytest patterns, AsyncMock, factory functions |
| `.claude/rules/security.md` | No secrets, parameterized SQL, bcrypt, rate limiting |

---

## Building a Blueprint Pipeline

Blueprints are directed graphs where nodes are agents or deterministic steps.

### 1. Define Nodes

```python
# Agentic node (calls LLM)
class MyGeneratorNode:
    name = "generator"
    node_type = "agentic"

    async def execute(self, context: NodeContext) -> NodeResult:
        service = MyAgentService()
        response = await service.process(request)
        return NodeResult(
            status="success",
            output=response.content,
            handoff=AgentHandoff(
                status="ok",
                agent_name="generator",
                artifact=response.content,
                confidence=response.confidence,
            ),
        )

# Deterministic node (no LLM)
class MyQAGateNode:
    name = "qa_gate"
    node_type = "deterministic"

    async def execute(self, context: NodeContext) -> NodeResult:
        issues = run_checks(context.output)
        if issues:
            return NodeResult(status="failed", structured_failures=tuple(issues))
        return NodeResult(status="success", output=context.output)
```

### 2. Wire the Graph

```python
from app.ai.blueprints.engine import BlueprintDefinition, Edge, BlueprintEngine

pipeline = BlueprintDefinition(
    name="my_pipeline",
    entry_node="generator",
    nodes={
        "generator": MyGeneratorNode(),
        "qa_gate": MyQAGateNode(),
        "fixer": MyFixerNode(),
    },
    edges=[
        Edge("generator", "qa_gate", "always"),
        Edge("qa_gate", "done", "success"),         # QA passes → done
        Edge("qa_gate", "fixer", "qa_fail"),         # QA fails → fix
        Edge("fixer", "qa_gate", "always"),           # Fix → re-check (max 2 rounds)
    ],
)
```

### 3. Run It

```python
engine = BlueprintEngine()
run = await engine.run(pipeline, brief="Generate a report")
# run.status: "completed" | "failed" | "needs_review"
# run.output: final artifact
# run.step_log: every node execution
# run.handoff_history: agent decisions chain
```

### Safety Bounds

- **MAX_SELF_CORRECTION_ROUNDS = 2** — fixer retries before giving up
- **MAX_TOTAL_STEPS = 25** — hard brake on runaway pipelines
- **CONFIDENCE_REVIEW_THRESHOLD = 0.5** — low confidence → "needs_review" status

---

## Adding an LLM Provider

Register a new provider in `app/ai/registry.py`:

```python
from app.ai.protocols import LLMProvider, CompletionResponse, Message

class MyCustomProvider:
    async def complete(self, messages: list[Message], **kwargs) -> CompletionResponse:
        # Call your LLM API here
        return CompletionResponse(content="...", model="my-model")

    async def stream(self, messages: list[Message], **kwargs):
        yield "streamed chunk"

# Register it
registry = get_registry()
registry.register_llm("my_provider", MyCustomProvider)
```

Then set `AI__PROVIDER=my_provider` in `.env`.

---

## Project Structure Reference

```
my-project/
├── .claude/
│   ├── commands/              # 10 slash commands for Claude Code
│   └── rules/                 # 4 rule files (backend, frontend, testing, security)
├── .agents/plans/             # Implementation plans (generated by /plan)
├── backend/
│   ├── app/
│   │   ├── core/              # Config, database, exceptions, logging, middleware, redis, health
│   │   ├── shared/            # Models (mixins), schemas (pagination), utils
│   │   ├── projects/          # Example feature slice (full CRUD)
│   │   ├── ai/
│   │   │   ├── agents/
│   │   │   │   ├── base/      # BaseAgentService (the pipeline all agents inherit)
│   │   │   │   ├── analyzer/  # Example agent with skills + evals
│   │   │   │   ├── fixer/     # Example fixer agent
│   │   │   │   ├── evals/     # Eval framework (judges, regression, golden tests)
│   │   │   │   └── skills/    # Skill loader (budget-aware, priority-sorted)
│   │   │   ├── blueprints/
│   │   │   │   ├── engine.py  # State machine engine
│   │   │   │   ├── nodes/     # 4 node types (analyzer, fixer, QA gate, repair)
│   │   │   │   ├── pipelines/ # Example analysis pipeline
│   │   │   │   └── routes.py  # Blueprint API endpoints
│   │   │   ├── protocols.py   # LLM/Embedding/Reranker protocols
│   │   │   ├── registry.py    # Provider registry + circuit breaker
│   │   │   ├── routing.py     # Tier resolution + fallback chains
│   │   │   └── cost_governor.py
│   │   ├── plugins/           # Plugin manifest + sandbox
│   │   └── main.py            # App factory + lifespan + router registration
│   ├── alembic/               # Database migrations
│   ├── cli.py                 # Scaffold CLI (new-feature, new-agent)
│   ├── pyproject.toml
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── app/               # Next.js App Router (landing, login, dashboard, API proxy)
│   │   ├── components/ui/     # Button, Card, Input, Dialog
│   │   ├── hooks/             # useAuth, useProjects
│   │   ├── lib/               # authFetch, SWR fetchers, ApiError
│   │   └── types/             # API types
│   ├── package.json
│   └── tsconfig.json
├── docs/                      # 9 architecture deep-dive documents
├── docker-compose.yml         # Postgres + Redis + Backend + Frontend
├── Makefile                   # dev, check, test, lint, types, docker, scaffold
├── copier.yml                 # Copier template config
├── CLAUDE.md                  # Claude Code project instructions
├── .env.example               # All config vars with defaults
└── .gitignore
```

---

## Make Commands Reference

| Command | What it does |
|---------|-------------|
| `make dev` | Run backend (:8891) + frontend (:3000) in parallel |
| `make dev-be` | Backend only |
| `make dev-fe` | Frontend only |
| `make check` | All quality checks (lint + types + tests) |
| `make test` | Backend pytest |
| `make lint` | Ruff format + lint with auto-fix |
| `make types` | MyPy + Pyright |
| `make check-fe` | Frontend TypeScript + lint + tests |
| `make db-migrate` | Run pending Alembic migrations |
| `make db-revision` | Create new auto-generated migration |
| `make docker-up` | Start Postgres + Redis containers |
| `make docker-down` | Stop containers |
| `make scaffold-feature` | Generate a feature vertical slice |
| `make scaffold-agent` | Generate an AI agent |
| `make help` | Show all available commands |
